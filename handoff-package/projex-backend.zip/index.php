<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Projex — TimeGlobal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    // Preflight off — Tailwind adds utility classes only, Bootstrap keeps handling resets/layout.
    // visibility off — Tailwind's ".collapse" (visibility:collapse) utility has the exact same
    // class name as Bootstrap's ".collapse" component (used for expand/collapse panels) and was
    // overriding it, so those panels closed instantly instead of staying open.
    tailwind.config = { corePlugins: { preflight: false, visibility: false } };
  </script>
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- LOGIN SCREEN -->
  <div id="login-screen" class="d-flex align-items-center justify-content-center vh-100" style="background: var(--bg-page);">
    <div class="stat-card" style="width:100%; max-width:420px; padding:2rem;">

      <div class="text-center mb-4">
        <div class="brand-icon mx-auto mb-3" style="width:48px;height:48px;font-size:24px; background:var(--bg-page); padding:8px;">
          <img src="images/tg-logo.png" alt="Time Global" style="width:100%; height:100%; object-fit:contain;">
        </div>
        <h4 class="fw-bold mb-0">Projex</h4>
      </div>

      <!-- Tabs -->
      <div class="d-flex mb-4 p-1" style="background:#f1f5f9;border-radius:10px;">
        <button id="tab-btn-admin" onclick="switchLoginTab('admin')"
          class="btn btn-sm w-50 fw-semibold"
          style="border-radius:8px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);border:none;font-size:13px;">
          <i class="bi bi-shield-lock me-1"></i>Admin
        </button>
        <button id="tab-btn-user" onclick="switchLoginTab('user')"
          class="btn btn-sm w-50 fw-semibold"
          style="border-radius:8px;background:transparent;border:none;font-size:13px;color:#94a3b8;">
          <i class="bi bi-person me-1"></i>User
        </button>
      </div>

      <!-- Admin Login -->
      <div id="panel-admin">
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" id="login-email" class="form-control" placeholder="admin@example.com" autocomplete="off">
        </div>
        <div class="mb-4">
          <label class="form-label">Password</label>
          <input type="password" id="login-password" class="form-control" placeholder="••••••••" autocomplete="new-password">
        </div>
        <button class="btn btn-primary w-100 py-2" onclick="handleLogin()">
          <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
        </button>
        <div id="login-error" class="text-danger small mt-2 text-center" style="display:none;"></div>
      </div>

      <!-- User Panel -->
      <div id="panel-user" style="display:none;">

        <!-- User Login -->
        <div id="user-login-panel">
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" id="u-email" class="form-control" placeholder="you@example.com" autocomplete="off">
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" id="u-pass" class="form-control" placeholder="••••••••" autocomplete="new-password">
          </div>
          <button class="btn btn-primary w-100 py-2 mb-3" onclick="handleUserLogin()">
            <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
          </button>
          <p class="text-center mb-0" style="font-size:13px;color:#64748b;">
            No account?
            <a href="#" onclick="showUserSignup()" style="color:var(--purple);font-weight:600;text-decoration:none;">Sign Up</a>
          </p>
          <div id="u-login-err" class="text-danger small mt-2 text-center" style="display:none;"></div>
        </div>

        <!-- User Signup -->
        <div id="user-signup-panel" style="display:none;">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" id="u-name" class="form-control" placeholder="John Doe" autocomplete="off">
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" id="u-signup-email" class="form-control" placeholder="you@example.com" autocomplete="off">
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" id="u-signup-pass" class="form-control" placeholder="Min. 6 characters" autocomplete="new-password">
          </div>
          <button class="btn btn-success w-100 py-2 mb-3" onclick="handleUserSignup()">
            <i class="bi bi-person-plus me-2"></i>Create Account
          </button>
          <p class="text-center mb-0" style="font-size:13px;color:#64748b;">
            Already have account?
            <a href="#" onclick="showUserLogin()" style="color:var(--purple);font-weight:600;text-decoration:none;">Sign In</a>
          </p>
          <div id="u-signup-err" class="text-danger small mt-2 text-center" style="display:none;"></div>
          <div id="u-signup-ok" class="text-success small mt-2 text-center" style="display:none;"></div>
        </div>

      </div>
    </div>
  </div>

  <?php
  // Data-driven sidebar — one array, one render loop, so adding/reordering
  // items never means touching markup in three places. Items with 'soon'
  // set render disabled with a "SOON" badge instead of a working link;
  // everything else calls the existing switchPage() router unchanged.
  // 'subs' => [ [label, tabKey], ... ] renders a nested sub-menu; clicking a
  // sub-item both navigates to the parent page and activates that tab via
  // switchPage(page, tab). Tabs with no sub-page built yet carry 'soon'.
  $sidebarSections = [
    'Menu' => [
      ['icon' => 'bi-speedometer2',  'label' => 'Dashboard',    'page' => 'dashboard',  'active' => true],
      ['icon' => 'bi-grid-fill',     'label' => 'Projects',     'page' => 'projects',   'badge' => 'proj-count', 'subs' => [
        ['All Projects', null], ['Kanban', 'kanban'], ['New Project', null],
      ]],
      ['icon' => 'bi-file-earmark-text', 'label' => 'Estimations', 'page' => 'estimations', 'subs' => [
        ['New Inquiry', 'new_inquiry'], ['Queue', 'queue'], ['Pipeline', 'pipeline'],
      ]],
      ['icon' => 'bi-speedometer',   'label' => 'Capacity',     'page' => 'capacity', 'subs' => [
        ['Organisational Capacity', 'org'], ['Manager Review', 'manager'], ['Accountant Billing', 'accountant'],
      ]],
      ['icon' => 'bi-mortarboard',   'label' => 'Interns',      'page' => 'interns', 'subs' => [
        ['Pipeline', 'pipeline'], ['New Task', 'newtask'],
      ]],
      ['icon' => 'bi-list-check',    'label' => 'Tasks',        'page' => 'tasks'],
      ['icon' => 'bi-clipboard-check', 'label' => 'My Tasks',   'soon' => true],
      ['icon' => 'bi-kanban',        'label' => 'Boards',       'soon' => true],
      ['icon' => 'bi-calendar3',     'label' => 'Calendar',     'soon' => true],
    ],
    'Team' => [
      ['icon' => 'bi-person-badge',  'label' => 'People',       'page' => 'people', 'subs' => [
        ['Users', 'users'], ['Clients', 'clients'], ['Roles & Permissions', 'roles'], ['Audit Log', 'audit'],
      ]],
      ['icon' => 'bi-clock-history', 'label' => 'Time & Cost',  'page' => 'timecost', 'subs' => [
        ['Time Log', 'timelog'], ['Approvals', 'approvals'], ['Project Cost', 'projectcost'], ['Organisation Cost Report', 'orgcost'],
      ]],
      ['icon' => 'bi-bar-chart-steps', 'label' => 'Skills',     'page' => 'skills', 'subs' => [
        ['Matrix', 'matrix'], ['Library', 'library'], ['Gap Analysis', 'gaps'],
      ]],
      ['icon' => 'bi-tools',         'label' => 'Services Catalogue', 'page' => 'services'],
    ],
    'Communication' => [
      ['icon' => 'bi-chat-dots',     'label' => 'Messages',     'soon' => true],
      ['icon' => 'bi-paperclip',     'label' => 'Files',        'soon' => true],
      ['icon' => 'bi-file-earmark-text', 'label' => 'Documents', 'soon' => true],
      ['icon' => 'bi-activity',      'label' => 'Activity',     'soon' => true],
    ],
    'Insights' => [
      ['icon' => 'bi-diagram-3',     'label' => 'Lifecycle',    'page' => 'lifecycle', 'subs' => [
        ['Project Lifecycle', 'lifecycle'], ['Project Closure', 'closure'], ['Case Study Generator', 'casestudy'],
      ]],
      ['icon' => 'bi-flask',         'label' => 'R&D',          'page' => 'rnd', 'subs' => [
        ['Log', 'log'], ['Knowledge Base', 'kb'],
      ]],
      ['icon' => 'bi-robot',         'label' => 'AI Agents',    'soon' => true],
      ['icon' => 'bi-receipt',       'label' => 'Billing',      'page' => 'billing', 'subs' => [
        ['Dashboard', 'dashboard'], ['Invoices', 'invoices'], ['Pipeline', null, true], ['Refunds', null, true],
        ['FOC Report', null, true], ['POC Conversions', null, true],
      ]],
      ['icon' => 'bi-bar-chart',     'label' => 'Reports',      'page' => 'reports', 'subs' => [
        ['All Reports', 'all'],
      ]],
      ['icon' => 'bi-graph-up',      'label' => 'Analytics',    'soon' => true],
      ['icon' => 'bi-box-arrow-up-right', 'label' => 'Client Portal', 'page' => 'clientportal'],
    ],
    'Account' => [
      ['icon' => 'bi-git',           'label' => 'VS Code',      'page' => 'developers'],
      ['icon' => 'bi-gear',          'label' => 'Settings',     'page' => 'settings'],
      ['icon' => 'bi-person-circle', 'label' => 'Profile',      'soon' => true],
    ],
  ];
  ?>

  <div class="d-flex" id="app-shell" style="display: none !important;">

    <!-- SIDEBAR -->
    <nav id="sidebar">
      <div class="sidebar-brand">
        <div class="brand-icon" style="background:var(--bg-page); padding:5px;"><img src="images/tg-logo.png" alt="Time Global" style="width:100%; height:100%; object-fit:contain;"></div>
        <span class="brand-name">Projex</span>
      </div>

      <?php foreach ($sidebarSections as $sectionLabel => $items): ?>
        <div class="nav-section-label"><?= htmlspecialchars($sectionLabel) ?></div>
        <ul class="nav flex-column px-2">
          <?php foreach ($items as $item): $hasSubs = !empty($item['subs']); ?>
            <li class="nav-item<?= $hasSubs ? ' has-subs' : '' ?>" data-page="<?= htmlspecialchars($item['page'] ?? '') ?>">
              <?php if (!empty($item['soon'])): ?>
                <a class="nav-link disabled" href="#" onclick="showToast('<?= htmlspecialchars($item['label'], ENT_QUOTES) ?> — coming soon'); return false;" title="Coming soon">
                  <i class="bi <?= htmlspecialchars($item['icon']) ?>"></i> <?= htmlspecialchars($item['label']) ?>
                  <span class="badge nav-badge nav-badge-soon ms-auto">Soon</span>
                </a>
              <?php else: ?>
                <a class="nav-link<?= !empty($item['active']) ? ' active' : '' ?>" href="#"
                   onclick="<?= $hasSubs ? "toggleNavSubs(this); " : '' ?>switchPage('<?= htmlspecialchars($item['page'], ENT_QUOTES) ?>')">
                  <i class="bi <?= htmlspecialchars($item['icon']) ?>"></i> <?= htmlspecialchars($item['label']) ?>
                  <?php if (!empty($item['badge'])): ?>
                    <span class="badge nav-badge ms-auto" id="<?= htmlspecialchars($item['badge']) ?>">0</span>
                  <?php endif; ?>
                  <?php if ($hasSubs): ?><i class="bi bi-chevron-down nav-sub-caret ms-auto"></i><?php endif; ?>
                </a>
                <?php if ($hasSubs): ?>
                  <ul class="nav-sub">
                    <?php foreach ($item['subs'] as $sub): $subLabel = $sub[0]; $subTab = $sub[1]; $subSoon = $sub[2] ?? false; ?>
                      <li>
                        <?php if ($subSoon): ?>
                          <a href="#" class="disabled" onclick="showToast('<?= htmlspecialchars($subLabel, ENT_QUOTES) ?> — coming soon'); return false;"><?= htmlspecialchars($subLabel) ?></a>
                        <?php else: ?>
                          <a href="#" onclick="switchPage('<?= htmlspecialchars($item['page'], ENT_QUOTES) ?>', null, '', '<?= htmlspecialchars($subTab ?? '', ENT_QUOTES) ?>'); return false;"><?= htmlspecialchars($subLabel) ?></a>
                        <?php endif; ?>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
        <?php if ($sectionLabel !== array_key_last($sidebarSections)): ?><hr class="sidebar-divider"><?php endif; ?>
      <?php endforeach; ?>
    </nav>

    <!-- MAIN -->
    <div class="main-area d-flex flex-column flex-grow-1">

      <!-- TOPBAR -->
      <div class="topbar d-flex align-items-center px-4">
        <div>
          <div class="topbar-title" id="page-title">Projects</div>
          <div class="topbar-sub" id="page-sub">All your workspace projects</div>
        </div>

        <div class="ms-auto me-3 d-none d-md-block" style="position:relative; width:280px;">
          <i class="bi bi-search" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:13px; color:var(--text-hint);"></i>
          <input type="text" id="topbar-search" class="form-control form-control-sm"
                 placeholder="Search projects…" autocomplete="off"
                 oninput="filterDashboardProjects(this.value)"
                 style="padding-left:32px; padding-right:44px; background:var(--bg-page); border-color:var(--card-border); font-size:13px;">
          <kbd style="position:absolute; right:8px; top:50%; transform:translateY(-50%); font-size:10px; color:var(--text-hint); background:var(--bg-white); border:1px solid var(--card-border); border-radius:4px; padding:1px 5px;">⌘K</kbd>
        </div>

        <div class="dropdown me-2">
          <button class="btn btn-outline-secondary btn-sm position-relative" data-bs-toggle="dropdown" onclick="loadNotificationBell()">
            <i class="bi bi-bell"></i>
            <span class="badge rounded-pill position-absolute top-0 start-100 translate-middle" style="background:var(--status-red); font-size:9px; display:none;" id="notif-badge">0</span>
          </button>
          <div class="dropdown-menu dropdown-menu-end p-2" style="width:340px; max-height:400px; overflow-y:auto;" id="notif-dropdown">
            <div class="text-muted p-2" style="font-size:13px;">Loading…</div>
          </div>
        </div>
        <button class="btn btn-primary btn-sm" onclick="switchPage('new')">
          <i class="bi bi-plus-lg me-1"></i> New project
        </button>
        <div class="dash-avatar ms-2" id="topbar-avatar" style="width:32px;height:32px;font-size:12px;background:var(--accent);" title="">?</div>
        <button class="btn btn-outline-danger btn-sm ms-2" onclick="handleLogout()" title="Logout">
          <i class="bi bi-box-arrow-right"></i>
        </button>
      </div>

      <!-- CONTENT -->
      <div class="content-area flex-grow-1 p-4">

        <!-- DASHBOARD PAGE -->
        <div class="page active" id="page-dashboard">
          <div class="row g-3 mb-3" id="dash-overall-stats">
            <div class="col-md-4 col-lg">
              <div class="stat-card">
                <div class="stat-label"><span class="dash-stat-dot" style="background:#3B82F6;"></span> Total Projects</div>
                <div class="stat-value" id="dash-stat-projects">0</div>
                <div class="stat-meta" id="dash-stat-projects-meta">—</div>
              </div>
            </div>
            <div class="col-md-4 col-lg">
              <div class="stat-card">
                <div class="stat-label"><span class="dash-stat-dot" style="background:#15803D;"></span> Active Projects</div>
                <div class="stat-value" id="dash-stat-active-projects">0</div>
                <div class="stat-meta">in progress now</div>
              </div>
            </div>
            <div class="col-md-4 col-lg">
              <div class="stat-card">
                <div class="stat-label"><span class="dash-stat-dot" style="background:#B45309;"></span> Total Tasks</div>
                <div class="stat-value" id="dash-stat-tasks">0</div>
                <div class="stat-meta" id="dash-stat-tasks-meta">—</div>
              </div>
            </div>
            <div class="col-md-4 col-lg">
              <div class="stat-card">
                <div class="stat-label"><span class="dash-stat-dot" style="background:#6D28D9;"></span> Developers</div>
                <div class="stat-value" id="dash-stat-developers">0</div>
                <div class="stat-meta">connected via API key</div>
              </div>
            </div>
            <div class="col-md-4 col-lg">
              <div class="stat-card">
                <div class="stat-label"><span class="dash-stat-dot" style="background:#4F46E5;"></span> Commits</div>
                <div class="stat-value" id="dash-stat-commits">0</div>
                <div class="stat-meta" id="dash-stat-commits-meta">—</div>
              </div>
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-lg-8">
              <div class="form-card p-0 overflow-hidden">
                <div class="d-flex justify-content-between align-items-center p-3 pb-2">
                  <div class="dash-heading">Active Projects</div>
                  <a href="#" class="small fw-semibold text-decoration-none" style="color:var(--accent);" onclick="switchPage('projects'); return false;">View all &rarr;</a>
                </div>
                <div class="table-responsive">
                  <table class="table align-middle mb-0" style="font-size:13px;">
                    <thead>
                      <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                        <th class="ps-3">Project</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Origin</th>
                        <th>Created</th>
                        <th class="pe-3">By</th>
                      </tr>
                    </thead>
                    <tbody id="dash-active-projects-body">
                      <tr><td colspan="6" class="text-muted text-center py-4">Loading…</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="form-card mb-3 p-3" id="dash-project-overview">
                <div class="text-muted p-2" style="font-size:13px;">Loading…</div>
              </div>
              <div class="form-card p-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <div class="dash-heading">My Tasks</div>
                  <span class="dash-pill dash-pill-status" id="dash-today-count">0</span>
                </div>
                <div id="dash-today-tasks"></div>
              </div>
            </div>
          </div>

          <div class="row g-3">
            <div class="col-md-7">
              <div class="form-card h-100 p-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <div class="dash-heading">Task Progress</div>
                  <div class="btn-group" id="dash-period-switcher" role="group">
                    <button type="button" class="dash-period-btn" data-period="day" onclick="switchDashboardPeriod('day')">Day</button>
                    <button type="button" class="dash-period-btn" data-period="week" onclick="switchDashboardPeriod('week')">Week</button>
                    <button type="button" class="dash-period-btn" data-period="month" onclick="switchDashboardPeriod('month')">Month</button>
                    <button type="button" class="dash-period-btn" data-period="year" onclick="switchDashboardPeriod('year')">Year</button>
                  </div>
                </div>
                <div style="height:210px;"><canvas id="taskProgressChart"></canvas></div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="form-card h-100 p-3 d-flex flex-column align-items-center justify-content-center">
                <div class="dash-heading align-self-start mb-2">Project Statistic</div>
                <div style="height:140px; width:140px; position:relative;">
                  <canvas id="taskStatChart"></canvas>
                  <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; flex-direction:column;">
                    <div class="fw-bold" style="font-size:24px; color:#0F172A;" id="dash-completion-pct">0%</div>
                  </div>
                </div>
                <div class="text-muted mt-2" style="font-size:10.5px; text-transform:uppercase; letter-spacing:.06em;">Activity Record</div>
                <div class="d-flex gap-4 mt-3 w-100 justify-content-center" id="dash-status-legend"></div>
              </div>
            </div>

            <div class="col-12">
              <div class="form-card mt-1 p-3">
                <div class="mb-3">
                  <div class="dash-heading">Task Summary</div>
                  <div class="dash-subheading">You can edit all the stuff as you wish</div>
                </div>
                <div class="row g-2" id="dash-task-summary"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- PROJECTS PAGE -->
        <div class="page" id="page-projects">
          <div class="row g-3 mb-4">
            <div class="col-4">
              <div class="stat-card">
                <div class="stat-label"><i class="bi bi-folder"></i> Total</div>
                <div class="stat-value" id="stat-total">0</div>
                <div class="stat-meta">projects</div>
              </div>
            </div>
            <div class="col-4">
              <div class="stat-card">
                <div class="stat-label"><i class="bi bi-check-circle"></i> Active</div>
                <div class="stat-value" id="stat-active">0</div>
                <div class="stat-meta">in progress</div>
              </div>
            </div>
            <div class="col-4">
              <div class="stat-card">
                <div class="stat-label"><i class="bi bi-paperclip"></i> Files</div>
                <div class="stat-value" id="stat-files">0</div>
                <div class="stat-meta">uploaded</div>
              </div>
            </div>
          </div>
          <div class="section-header d-flex align-items-center mb-3">
            <span class="section-title">Recent projects</span>
          </div>
          <div id="project-list"></div>
        </div>

        <!-- ADD PROJECT PAGE -->
        <div class="page" id="page-new">
          <div class="form-card">
            <div class="mb-3">
              <label class="form-label">Project name</label>
              <input type="text" class="form-control" id="proj-name" placeholder="e.g. Website Redesign Q3">
            </div>
            <div class="row g-3 mb-3">
              <div class="col-4">
                <label class="form-label">Project type</label>
                <select class="form-select" id="proj-type">
                  <option value="">Select type…</option>
                  <option value="web development">Strategic Partnership </option>
                  <option value="mobile development">Strategic Research </option>
                  <option value="design">Quick Cash </option>
                  <option value="design">Inter.N Commercial </option>
                  <option value="design">Local Commercial </option>

                  <option value="design">Volunteer  </option>

                  <option value="design">Demo  </option>
                  <option value="design">Free Demo </option>
                  <option value="design">Internal Internship </option>
                  <option value="design">Internal Commercial </option>
                  <option value="design">Internship Research  </option>
                  <option value="design">Internship Commercial  </option>


                </select>
              </div>
              <div class="col-4">
                <label class="form-label">Main services</label>
                <select class="form-select" id="proj-service">
                  <option value="">Select service…</option>
                  <option value="web-development">Website</option>
                  <option value="mobile-development">Mobile App  </option>
                  <option value="ui-ux">Social Media </option>
                  <option value="marketing">Graphics </option>
                  <option value="marketing">Research </option>
                </select>
              </div>
              <div class="col-4">
                <label class="form-label">Status</label>
                <select class="form-select" id="proj-status">
                  <option value="active">In Progress</option>
                  <option value="on-hold">On hold</option>
                  <option value="draft">Waiting for Internal Approval</option>
                  <option value="draft">Waiting Client Approva</option>
                  <option value="draft">Waiting for Client Payment</option>
                  <option value="draft">Waiting for Budget Allocation</option>
                  <option value="draft">Waiting in Queue</option>
                  <option value="draft">Unable to Understand</option>
                </select>
              </div>
            </div>
            
            <div class="row g-3 mb-3">
              <div class="col-4">
                <label class="form-label d-block mb-2">Payment Type</label>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="paymentType" id="payPaid" value="paid" checked>
                  <label class="form-check-label" style="font-size: 14px; color: var(--text-main);" for="payPaid">Paid work</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="paymentType" id="payUnpaid" value="unpaid">
                  <label class="form-check-label" style="font-size: 14px; color: var(--text-main);" for="payUnpaid">Unpaid work</label>
                </div>
              </div>
              <div class="col-4">
                <label class="form-label d-block mb-2">Project Origin</label>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="projectOrigin" id="originClient" value="client" checked>
                  <label class="form-check-label" style="font-size: 14px; color: var(--text-main);" for="originClient">Client project</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="projectOrigin" id="originInternal" value="internal">
                  <label class="form-check-label" style="font-size: 14px; color: var(--text-main);" for="originInternal">Internal project</label>
                </div>
              </div>
              <div class="col-4">
                <label class="form-label mb-2">Country</label>
                <select class="form-select" id="proj-country">
                  <option value="">Select country…</option>
                  <option value="Saudi Arabia">Saudi Arabia</option>
                  <option value="Canada">Canada</option>
                  <option value="Australia">Australia</option>
                  <option value="UAE">UAE</option>
                  <option value="Pakistan">Pakistan</option>
                  <option value="USA">USA</option>
                  <option value="Portugal">Portugal</option>
                </select>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Client Email <span class="text-muted" style="font-weight:400;">(optional)</span></label>
              <input type="email" class="form-control" id="proj-client-email" placeholder="client@example.com">
              <div class="form-text">If set, the client also receives the automatic final-summary report by email when this project is marked complete.</div>
            </div>
            <div class="mb-3">
              <label class="form-label">Description</label>
              <textarea class="form-control" id="proj-desc" rows="3" placeholder="Brief description…"></textarea>
            </div>
            <div class="mb-3">
              <label class="form-label">Upload files</label>
              <div class="drop-zone" id="drop-zone"
                onclick="document.getElementById('file-input').click()"
                ondragover="onDragOver(event)"
                ondragleave="onDragLeave(event)"
                ondrop="onDrop(event)">
                <i class="bi bi-cloud-upload fs-3 d-block mb-2"></i>
                <p class="mb-1">Drop files or folders here or click to browse</p>
                <span>Any file type · multiple files supported</span>
              </div>
              <div class="d-flex gap-2 mt-2 justify-content-center">
                <button class="btn btn-outline-secondary btn-sm" onclick="document.getElementById('file-input').click()">
                  <i class="bi bi-files me-1"></i> Upload Files
                </button>
                <button class="btn btn-outline-secondary btn-sm" onclick="document.getElementById('folder-input').click()">
                  <i class="bi bi-folder-plus me-1"></i> Upload Folder
                </button>
              </div>
              <input type="file" id="file-input" multiple style="display:none" onchange="handleFiles(this.files)">
              <input type="file" id="folder-input" webkitdirectory style="display:none" onchange="handleFiles(this.files)">
              <div id="upload-summary" class="mt-3 text-center fw-medium" style="font-size: 12px; color: var(--text-muted); display: none;"></div>
              <div id="file-error" class="mt-1 text-danger text-center" style="font-size: 12px; display: none;"></div>
              <div id="file-list" class="mt-2"></div>
              <div id="upload-overall" class="mt-2 text-center" style="font-size: 13px; color: var(--purple); font-weight: 500; display: none;"></div>
            </div>
            <div class="d-flex gap-2 pt-3 border-top">
              <button class="btn btn-primary" onclick="submitProject()">
                <i class="bi bi-check-lg me-1"></i> Save project
              </button>
              <button class="btn btn-outline-secondary" onclick="resetForm()">Clear</button>
            </div>
          </div>
        </div>

        <!-- SETTINGS PAGE -->
        <div class="page" id="page-settings">
          <div class="form-card mb-4">
            <label class="form-label fw-semibold">Project name</label>
            <div class="tag-wrap mb-2" id="type-tags"></div>
            <div class="d-flex gap-2">
              <input type="text" class="form-control form-control-sm" id="new-type-input"
                placeholder="Add a project…" onkeydown="if(event.key==='Enter')addType()">
              <button class="btn btn-outline-primary btn-sm" onclick="addType()">
                <i class="bi bi-plus-lg me-1"></i>Add
              </button>
            </div>
            <div class="form-text">Jo bhi yahan add karoge, woh "Assign New Task" ke Project dropdown mein turant aa jayega.</div>
          </div>

          <div class="form-card">
            <label class="form-label fw-semibold">Team — Developer API Keys</label>
            <div class="form-text mb-3">PM Connect (VS Code extension) mein connect karne ke liye har developer ko yeh key deni hai.</div>
            <div id="api-key-list"></div>
          </div>

          <div class="form-card mt-4">
            <label class="form-label fw-semibold">PM Connect Activity Feed</label>
            <div class="form-text mb-3">VS Code se har action (task create, status change, timer start/stop, progress push) yahan live dikhta hai.</div>
            <div id="activity-list" style="max-height:400px; overflow-y:auto;"></div>
          </div>
        </div>

        <!-- DEVELOPERS PAGE -->
        <div class="page" id="page-developers">
          <div id="dev-breadcrumb" class="d-flex align-items-center gap-2 mb-3" style="display:none !important;">
            <button class="btn btn-outline-secondary btn-sm" onclick="devGoBack()">
              <i class="bi bi-arrow-left me-1"></i> Back
            </button>
            <span id="dev-breadcrumb-text" class="text-muted" style="font-size:13px;"></span>
          </div>
          <div id="dev-content"></div>
        </div>

        <!-- PEOPLE PAGE -->
        <div class="page" id="page-people">
          <div class="subtab-strip" data-page="people">
            <button class="subtab-btn active" data-tab="users" onclick="switchPage('people', null, '', 'users')">Users</button>
            <button class="subtab-btn" data-tab="clients" onclick="switchPage('people', null, '', 'clients')">Clients</button>
            <button class="subtab-btn" data-tab="roles" onclick="switchPage('people', null, '', 'roles')">Roles &amp; Permissions</button>
            <button class="subtab-btn" data-tab="audit" onclick="switchPage('people', null, '', 'audit')">Audit Log</button>
          </div>

          <div class="subtab-pane active" data-page="people" data-tab="users">
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13.5px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Employee ID</th>
                      <th class="pe-3">PM Connect</th>
                    </tr>
                  </thead>
                  <tbody id="people-table-body">
                    <tr><td colspan="5" class="text-muted text-center py-4">Loading…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="people" data-tab="clients">
            <p class="text-muted mb-3" style="font-size:13px;">Derived from real invoices raised in Billing — not a separate client list to maintain.</p>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13.5px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Client</th><th>Invoices</th><th class="pe-3">Total billed</th>
                    </tr>
                  </thead>
                  <tbody id="clients-table-body"><tr><td colspan="3" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="people" data-tab="roles">
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13.5px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Name</th><th class="pe-3">Role</th>
                    </tr>
                  </thead>
                  <tbody id="roles-table-body"><tr><td colspan="2" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="people" data-tab="audit">
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive" style="max-height:520px; overflow-y:auto;">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">When</th><th>Employee</th><th>Action</th><th class="pe-3">Detail</th>
                    </tr>
                  </thead>
                  <tbody id="audit-table-body"><tr><td colspan="4" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- SKILLS MATRIX PAGE -->
        <div class="page" id="page-skills">
          <div class="subtab-strip" data-page="skills">
            <button class="subtab-btn active" data-tab="matrix" onclick="switchPage('skills', null, '', 'matrix')">Matrix</button>
            <button class="subtab-btn" data-tab="library" onclick="switchPage('skills', null, '', 'library')">Library</button>
            <button class="subtab-btn" data-tab="gaps" onclick="switchPage('skills', null, '', 'gaps')">Gap Analysis</button>
          </div>

          <div class="subtab-pane active" data-page="skills" data-tab="matrix">
            <div class="form-card mb-3 p-3">
              <div class="d-flex align-items-end gap-2 flex-wrap">
                <div>
                  <label class="form-label">Add a skill</label>
                  <input type="text" class="form-control form-control-sm" id="new-skill-name" placeholder="e.g. React" style="width:220px;">
                </div>
                <button class="btn btn-primary btn-sm" onclick="addSkill()"><i class="bi bi-plus-lg me-1"></i>Add skill</button>
              </div>
            </div>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;" id="skills-matrix-table">
                  <thead><tr><th class="ps-3 text-muted" style="font-size:10.5px; text-transform:uppercase;">Member</th></tr></thead>
                  <tbody id="skills-matrix-body">
                    <tr><td class="text-muted text-center py-4">Loading…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="skills" data-tab="library">
            <div class="row g-3" id="skills-library-grid"></div>
          </div>

          <div class="subtab-pane" data-page="skills" data-tab="gaps">
            <p class="text-muted mb-3" style="font-size:13px;">Skills nobody on the team has past "beginner" level — computed from the real Matrix, not guessed.</p>
            <div class="row g-3" id="skills-gaps-grid"></div>
          </div>
        </div>

        <!-- R&D LOG PAGE -->
        <div class="page" id="page-rnd">
          <div class="subtab-strip" data-page="rnd">
            <button class="subtab-btn active" data-tab="log" onclick="switchPage('rnd', null, '', 'log')">Log</button>
            <button class="subtab-btn" data-tab="kb" onclick="switchPage('rnd', null, '', 'kb')">Knowledge Base</button>
          </div>

          <div class="subtab-pane active" data-page="rnd" data-tab="log">
            <div class="d-flex justify-content-end mb-3">
              <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#rndModal"><i class="bi bi-plus-lg me-1"></i>New entry</button>
            </div>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Research question</th>
                      <th>Project</th>
                      <th>Category</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th>Owner</th>
                      <th class="pe-3">Created</th>
                    </tr>
                  </thead>
                  <tbody id="rnd-table-body">
                    <tr><td colspan="7" class="text-muted text-center py-4">Loading…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="rnd" data-tab="kb">
            <div class="form-card mb-3 p-3">
              <div class="mb-2"><label class="form-label">Title</label><input type="text" class="form-control form-control-sm" id="kb-title"></div>
              <div class="mb-2"><label class="form-label">Content</label><textarea class="form-control form-control-sm" id="kb-content" rows="3"></textarea></div>
              <div class="mb-2"><label class="form-label">Tags (comma separated)</label><input type="text" class="form-control form-control-sm" id="kb-tags"></div>
              <button class="btn btn-primary btn-sm" onclick="addKbArticle()"><i class="bi bi-plus-lg me-1"></i>Add article</button>
            </div>
            <div id="kb-list"></div>
          </div>
        </div>

        <!-- R&D new-entry modal -->
        <div class="modal fade" id="rndModal" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header"><h5 class="modal-title">New R&D entry</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
              <div class="modal-body">
                <div class="mb-3"><label class="form-label">Research question</label><textarea class="form-control" id="rnd-question" rows="2"></textarea></div>
                <div class="row g-2">
                  <div class="col-6">
                    <label class="form-label">Project</label>
                    <select class="form-select" id="rnd-project"><option value="">None</option></select>
                  </div>
                  <div class="col-6">
                    <label class="form-label">Category</label>
                    <select class="form-select" id="rnd-category">
                      <option>Technical</option><option>Legal</option><option>Market</option><option>Other</option>
                    </select>
                  </div>
                  <div class="col-6">
                    <label class="form-label">Priority</label>
                    <select class="form-select" id="rnd-priority"><option value="low">Low</option><option value="medium" selected>Medium</option><option value="high">High</option></select>
                  </div>
                  <div class="col-6">
                    <label class="form-label">Owner</label>
                    <input type="text" class="form-control" id="rnd-owner" placeholder="Name">
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary btn-sm" onclick="createRndEntry()">Save entry</button>
              </div>
            </div>
          </div>
        </div>

        <!-- BILLING PAGE -->
        <div class="page" id="page-billing">
          <div class="subtab-strip" data-page="billing">
            <button class="subtab-btn active" data-tab="dashboard" onclick="switchPage('billing', null, '', 'dashboard')">Dashboard</button>
            <button class="subtab-btn" data-tab="invoices" onclick="switchPage('billing', null, '', 'invoices')">Invoices</button>
          </div>

          <div class="subtab-pane active" data-page="billing" data-tab="dashboard">
            <div class="row g-3 mb-3">
              <div class="col-md-4">
                <div class="stat-card">
                  <div class="stat-label"><span class="dash-stat-dot" style="background:#B45309;"></span> Outstanding</div>
                  <div class="stat-value" id="bill-stat-outstanding">$0</div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="stat-card">
                  <div class="stat-label"><span class="dash-stat-dot" style="background:#B91C1C;"></span> Overdue</div>
                  <div class="stat-value" id="bill-stat-overdue">$0</div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="stat-card">
                  <div class="stat-label"><span class="dash-stat-dot" style="background:#15803D;"></span> Invoiced this month</div>
                  <div class="stat-value" id="bill-stat-month">$0</div>
                </div>
              </div>
            </div>
            <p class="text-muted" style="font-size:13px;">See the <strong>Invoices</strong> tab for the full per-project billing list.</p>
          </div>

          <div class="subtab-pane" data-page="billing" data-tab="invoices">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <div class="dash-heading">Billing status by project</div>
              <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#invoiceModal"><i class="bi bi-plus-lg me-1"></i>New invoice</button>
            </div>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Project</th>
                      <th>Client</th>
                      <th>Milestone</th>
                      <th>Amount</th>
                      <th>Due</th>
                      <th class="pe-3">Status</th>
                    </tr>
                  </thead>
                  <tbody id="billing-table-body">
                    <tr><td colspan="6" class="text-muted text-center py-4">Loading…</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- New invoice modal -->
        <div class="modal fade" id="invoiceModal" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header"><h5 class="modal-title">New invoice</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
              <div class="modal-body">
                <div class="mb-3">
                  <label class="form-label">Project</label>
                  <select class="form-select" id="inv-project"><option value="">Select a project…</option></select>
                </div>
                <div class="row g-2">
                  <div class="col-6"><label class="form-label">Client</label><input type="text" class="form-control" id="inv-client"></div>
                  <div class="col-6"><label class="form-label">Amount ($)</label><input type="number" min="0" step="0.01" class="form-control" id="inv-amount"></div>
                  <div class="col-6"><label class="form-label">Milestone</label><input type="text" class="form-control" id="inv-milestone"></div>
                  <div class="col-6"><label class="form-label">Due date</label><input type="date" class="form-control" id="inv-due"></div>
                </div>
              </div>
              <div class="modal-footer">
                <button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary btn-sm" onclick="createInvoice()">Raise invoice</button>
              </div>
            </div>
          </div>
        </div>

        <!-- ESTIMATIONS PAGE -->
        <div class="page" id="page-estimations">
          <div class="row g-3 mb-3" id="est-stats"></div>
          <div class="d-flex justify-content-between align-items-center">
            <div class="subtab-strip" data-page="estimations">
              <button class="subtab-btn active" data-tab="new_inquiry" onclick="switchPage('estimations', null, '', 'new_inquiry')">New Inquiry</button>
              <button class="subtab-btn" data-tab="queue" onclick="switchPage('estimations', null, '', 'queue')">Queue</button>
              <button class="subtab-btn" data-tab="pipeline" onclick="switchPage('estimations', null, '', 'pipeline')">Pipeline</button>
            </div>
            <button class="btn btn-primary btn-sm mb-3" data-bs-toggle="modal" data-bs-target="#estModal"><i class="bi bi-plus-lg me-1"></i>New inquiry</button>
          </div>
          <div class="form-card p-0 overflow-hidden">
            <div class="table-responsive">
              <table class="table align-middle mb-0" style="font-size:13px;">
                <thead>
                  <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                    <th class="ps-3">Title</th><th>Client</th><th>Est. Value</th><th class="pe-3">Status</th>
                  </tr>
                </thead>
                <tbody id="est-table-body"><tr><td colspan="4" class="text-muted text-center py-4">Loading…</td></tr></tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="modal fade" id="estModal" tabindex="-1">
          <div class="modal-dialog"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">New estimation inquiry</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Title</label><input type="text" class="form-control" id="est-title"></div>
              <div class="row g-2">
                <div class="col-6"><label class="form-label">Client</label><input type="text" class="form-control" id="est-client"></div>
                <div class="col-6"><label class="form-label">Estimated value ($)</label><input type="number" min="0" step="0.01" class="form-control" id="est-value"></div>
              </div>
              <div class="mb-0 mt-2"><label class="form-label">Notes</label><textarea class="form-control" id="est-notes" rows="2"></textarea></div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
              <button class="btn btn-primary btn-sm" onclick="createEstimation()">Save</button>
            </div>
          </div></div>
        </div>

        <!-- CAPACITY PAGE -->
        <div class="page" id="page-capacity">
          <div class="subtab-strip" data-page="capacity">
            <button class="subtab-btn active" data-tab="org" onclick="switchPage('capacity', null, '', 'org')">Organisational Capacity</button>
            <button class="subtab-btn" data-tab="manager" onclick="switchPage('capacity', null, '', 'manager')">Manager Review</button>
            <button class="subtab-btn" data-tab="accountant" onclick="switchPage('capacity', null, '', 'accountant')">Accountant Billing</button>
          </div>
          <p class="text-muted mb-3" style="font-size:13px;" id="capacity-tab-desc">Real active-task load across the whole team.</p>
          <div class="form-card p-0 overflow-hidden">
            <div class="table-responsive">
              <table class="table align-middle mb-0" style="font-size:13px;">
                <thead>
                  <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                    <th class="ps-3">Member</th><th>Weekly capacity</th><th>Active tasks now</th><th class="pe-3">Load</th>
                  </tr>
                </thead>
                <tbody id="capacity-table-body"><tr><td colspan="4" class="text-muted text-center py-4">Loading…</td></tr></tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- INTERNS PAGE -->
        <div class="page" id="page-interns">
          <div class="subtab-strip" data-page="interns">
            <button class="subtab-btn active" data-tab="pipeline" onclick="switchPage('interns', null, '', 'pipeline')">Pipeline</button>
            <button class="subtab-btn" data-tab="newtask" onclick="switchPage('interns', null, '', 'newtask')">New Task</button>
          </div>

          <div class="subtab-pane active" data-page="interns" data-tab="pipeline">
            <div class="row g-3 mb-3" id="intern-stats"></div>
            <div class="row g-3">
              <div class="col-lg-8">
                <div class="form-card p-0 overflow-hidden">
                  <div class="px-3 pt-3 dash-heading">Work Queue</div>
                  <div class="table-responsive">
                    <table class="table align-middle mb-0" style="font-size:13px;">
                      <thead>
                        <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                          <th class="ps-3">Task</th><th>Project</th><th>Priority</th><th>Due</th><th class="pe-3">Assignee</th>
                        </tr>
                      </thead>
                      <tbody id="intern-queue-body"><tr><td colspan="5" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="form-card p-3">
                  <div class="dash-heading mb-3">Interns</div>
                  <div id="intern-cards"></div>
                  <hr class="sidebar-divider">
                  <div class="small text-muted mb-2">Mark someone as an intern from People, or here:</div>
                  <select class="form-select form-select-sm mb-2" id="intern-user-select"></select>
                  <button class="btn btn-outline-primary btn-sm w-100" onclick="markAsIntern()">Add to interns</button>
                </div>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="interns" data-tab="newtask">
            <div class="form-card" style="max-width:520px;">
              <div class="mb-3">
                <label class="form-label">Project</label>
                <select class="form-select" id="intern-newtask-project"><option value="">Select a project…</option></select>
              </div>
              <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" class="form-control" id="intern-newtask-title">
              </div>
              <div class="mb-3">
                <label class="form-label">Assign to intern</label>
                <select class="form-select" id="intern-newtask-assignee"></select>
              </div>
              <button class="btn btn-primary btn-sm" onclick="createInternTask()">Create task</button>
            </div>
          </div>
        </div>

        <!-- TIME & COST PAGE -->
        <div class="page" id="page-timecost">
          <div class="subtab-strip" data-page="timecost">
            <button class="subtab-btn active" data-tab="timelog" onclick="switchPage('timecost', null, '', 'timelog')">Time Log</button>
            <button class="subtab-btn" data-tab="approvals" onclick="switchPage('timecost', null, '', 'approvals')">Approvals</button>
            <button class="subtab-btn" data-tab="projectcost" onclick="switchPage('timecost', null, '', 'projectcost')">Project Cost</button>
            <button class="subtab-btn" data-tab="orgcost" onclick="switchPage('timecost', null, '', 'orgcost')">Organisation Cost Report</button>
          </div>

          <div class="subtab-pane active" data-page="timecost" data-tab="timelog">
            <div class="dash-heading mb-2">Tracked coding time (from VS Code / PM Connect)</div>
            <div class="form-card p-0 overflow-hidden mb-3">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Project</th><th>Active time</th><th class="pe-3">Commits</th>
                    </tr>
                  </thead>
                  <tbody id="timecost-tracked-body"><tr><td colspan="3" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>

            <div class="dash-heading mb-2">Manually logged time</div>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Employee</th><th>Task</th><th>Project</th><th class="pe-3">Minutes</th>
                    </tr>
                  </thead>
                  <tbody id="timecost-manual-body"><tr><td colspan="4" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="timecost" data-tab="approvals">
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Employee</th><th>Task</th><th>Project</th><th>Minutes</th><th>Logged</th><th class="pe-3">Status</th>
                    </tr>
                  </thead>
                  <tbody id="approvals-table-body"><tr><td colspan="6" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="timecost" data-tab="projectcost">
            <p class="text-muted mb-3" style="font-size:13px;">Real tracked time per project — same source as Time Log, grouped for cost review.</p>
            <div class="form-card p-0 overflow-hidden">
              <div class="table-responsive">
                <table class="table align-middle mb-0" style="font-size:13px;">
                  <thead>
                    <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                      <th class="ps-3">Project</th><th class="pe-3">Total tracked time</th>
                    </tr>
                  </thead>
                  <tbody id="projectcost-table-body"><tr><td colspan="2" class="text-muted text-center py-4">Loading…</td></tr></tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="subtab-pane" data-page="timecost" data-tab="orgcost">
            <div class="row g-3" id="orgcost-stats"></div>
          </div>
        </div>

        <!-- SERVICES PAGE -->
        <div class="page" id="page-services">
          <div class="form-card mb-3 p-3">
            <div class="d-flex align-items-end gap-2 flex-wrap">
              <div><label class="form-label">Name</label><input type="text" class="form-control form-control-sm" id="svc-name" style="width:200px;"></div>
              <div><label class="form-label">Price ($)</label><input type="number" min="0" step="0.01" class="form-control form-control-sm" id="svc-price" style="width:140px;"></div>
              <div class="flex-grow-1"><label class="form-label">Description</label><input type="text" class="form-control form-control-sm" id="svc-desc"></div>
              <button class="btn btn-primary btn-sm" onclick="addService()"><i class="bi bi-plus-lg me-1"></i>Add</button>
            </div>
          </div>
          <div class="row g-3" id="services-grid"></div>
        </div>

        <!-- LIFECYCLE PAGE -->
        <div class="page" id="page-lifecycle">
          <div class="subtab-strip" data-page="lifecycle">
            <button class="subtab-btn active" data-tab="lifecycle" onclick="switchPage('lifecycle', null, '', 'lifecycle')">Project Lifecycle</button>
            <button class="subtab-btn" data-tab="closure" onclick="switchPage('lifecycle', null, '', 'closure')">Project Closure</button>
            <button class="subtab-btn" data-tab="casestudy" onclick="switchPage('lifecycle', null, '', 'casestudy')">Case Study Generator</button>
          </div>

          <div class="d-flex justify-content-end mb-3">
            <select class="form-select form-select-sm" id="lifecycle-project-select" style="width:260px;" onchange="onLifecycleProjectChange(this.value)"></select>
          </div>

          <div class="subtab-pane active" data-page="lifecycle" data-tab="lifecycle">
            <div class="form-card" id="lifecycle-body">
              <div class="text-muted text-center py-4">Select a project above.</div>
            </div>
          </div>

          <div class="subtab-pane" data-page="lifecycle" data-tab="closure">
            <div class="form-card">
              <label class="form-label">Closure notes</label>
              <textarea class="form-control mb-3" id="closure-notes" rows="6" placeholder="What was delivered, sign-off details, handoff notes…"></textarea>
              <button class="btn btn-primary btn-sm" onclick="saveClosureNotes()">Save</button>
            </div>
          </div>

          <div class="subtab-pane" data-page="lifecycle" data-tab="casestudy">
            <div class="form-card">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label mb-0">Case study draft</label>
                <button class="btn btn-outline-primary btn-sm" onclick="generateCaseStudyDraft()"><i class="bi bi-magic me-1"></i>Generate from real project data</button>
              </div>
              <p class="text-muted" style="font-size:12px;">Fills a draft from this project's real name, description, task completion and commit counts — not AI-written. Edit freely before saving.</p>
              <textarea class="form-control mb-3" id="case-study-text" rows="8"></textarea>
              <button class="btn btn-primary btn-sm" onclick="saveCaseStudy()">Save</button>
            </div>
          </div>
        </div>

        <!-- REPORTS PAGE -->
        <div class="page" id="page-reports">
          <div class="row g-3">
            <div class="col-lg-6">
              <div class="form-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <div class="dash-heading">Project Status Summary</div>
                  <button class="btn btn-outline-secondary btn-sm" onclick="exportProjectsCsv()"><i class="bi bi-download me-1"></i>CSV</button>
                </div>
                <div id="report-projects-summary" class="small"></div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <div class="dash-heading">Billing Summary</div>
                  <button class="btn btn-outline-secondary btn-sm" onclick="exportInvoicesCsv()"><i class="bi bi-download me-1"></i>CSV</button>
                </div>
                <div id="report-billing-summary" class="small"></div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-card">
                <div class="dash-heading mb-3">Task Status</div>
                <div id="report-task-summary" class="small"></div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-card">
                <div class="dash-heading mb-3">R&D Summary</div>
                <div id="report-rnd-summary" class="small"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- CLIENT PORTAL (admin: manage share links) -->
        <div class="page" id="page-clientportal">
          <p class="text-muted mb-3" style="font-size:13px;">Generate a read-only link for a client to view a project's status, phase and task list — no login required for them.</p>
          <div class="form-card p-0 overflow-hidden">
            <div class="table-responsive">
              <table class="table align-middle mb-0" style="font-size:13px;">
                <thead>
                  <tr style="font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--text-hint);">
                    <th class="ps-3">Project</th><th class="pe-3">Client link</th>
                  </tr>
                </thead>
                <tbody id="clientportal-table-body"><tr><td colspan="2" class="text-muted text-center py-4">Loading…</td></tr></tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- TASKS PAGE -->
        <div class="page" id="page-tasks">
          <div class="d-flex align-items-center mb-4">
            <button class="btn btn-outline-secondary btn-sm me-3" onclick="switchPage('projects')">
              <i class="bi bi-arrow-left me-1"></i> Back
            </button>
            <h4 class="m-0" id="detail-project-name" style="font-weight:700;">Project Tasks</h4>
          </div>

          <div class="row g-4">
            <!-- Assign Task Form -->
            <div class="col-md-4">
              <div class="form-card h-100">
                <h5 class="mb-4" style="font-weight:600;">Assign New Task</h5>
                <div class="mb-3">
                  <label class="form-label">Project</label>
                  <select class="form-select" id="tasks-project-select" onchange="onTasksProjectChange()">
                    <option value="">Select a project…</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label">Task Title</label>
                  <input type="text" class="form-control" id="task-title" placeholder="e.g. Design Homepage">
                </div>
                <div class="mb-3">
                  <label class="form-label">Assign To</label>
                  <select class="form-select" id="task-assignee">
                    <option value="">Select a person…</option>
                  </select>
                  <button type="button" class="btn btn-link btn-sm p-0 mt-1" data-bs-toggle="collapse" data-bs-target="#new-dev-form">
                    + Add new developer
                  </button>
                  <div class="collapse mt-2" id="new-dev-form">
                    <div class="border rounded p-2">
                      <input type="text" class="form-control form-control-sm mb-2" id="new-dev-name" placeholder="Name">
                      <input type="email" class="form-control form-control-sm mb-2" id="new-dev-email" placeholder="Email">
                      <button class="btn btn-sm btn-primary w-100" onclick="addDeveloper()">Create + Generate API Key</button>
                    </div>
                  </div>
                </div>
                <div class="row g-2 mb-3">
                  <div class="col-6">
                    <label class="form-label">Due Date</label>
                    <input type="date" class="form-control" id="task-due-date">
                  </div>
                  <div class="col-6">
                    <label class="form-label">Priority</label>
                    <select class="form-select" id="task-priority">
                      <option value="low">Low</option>
                      <option value="medium" selected>Medium</option>
                      <option value="high">High</option>
                      <option value="urgent">Urgent</option>
                    </select>
                  </div>
                </div>
                <div class="mb-4">
                  <label class="form-label">Description</label>
                  <textarea class="form-control" id="task-desc" rows="3" placeholder="Task details..."></textarea>
                </div>
                <button class="btn btn-primary w-100" onclick="submitTask()">Assign Task</button>
              </div>
            </div>

            <!-- Kanban Board -->
            <div class="col-md-8">
              <div class="row g-3">
                <div class="col-md-4">
                  <div class="form-card h-100 p-3 kanban-col" data-status="todo" ondragover="kanbanDragOver(event)" ondrop="kanbanDrop(event, 'todo')">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                      <h6 class="m-0" style="font-weight:600; color: #475569;">To Do</h6>
                      <span class="badge rounded-pill" style="background:#EBECF0; color:#44546F;" id="task-count-todo">0</span>
                    </div>
                    <div id="task-list-todo" class="d-flex flex-column gap-2"></div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-card h-100 p-3 kanban-col" data-status="in_progress" ondragover="kanbanDragOver(event)" ondrop="kanbanDrop(event, 'in_progress')">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                      <h6 class="m-0" style="font-weight:600; color: #475569;">In Progress</h6>
                      <span class="badge rounded-pill" style="background:var(--status-yellow-bg); color:var(--status-yellow);" id="task-count-in_progress">0</span>
                    </div>
                    <div id="task-list-in_progress" class="d-flex flex-column gap-2"></div>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-card h-100 p-3 kanban-col" data-status="done" ondragover="kanbanDragOver(event)" ondrop="kanbanDrop(event, 'done')">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                      <h6 class="m-0" style="font-weight:600; color: #475569;">Done</h6>
                      <span class="badge rounded-pill" style="background:var(--status-green-bg); color:var(--status-green);" id="task-count-done">0</span>
                    </div>
                    <div id="task-list-done" class="d-flex flex-column gap-2"></div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        <!-- Task Detail Modal -->
        <div class="modal fade" id="taskDetailModal" tabindex="-1">
          <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="td-title">Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body" id="td-body">
                <!-- injected via JS -->
              </div>
            </div>
          </div>
        </div>

        <!-- Edit Project Modal -->
        <div class="modal fade" id="editProjectModal" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Edit Project</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" id="edit-project-id">
                <div class="mb-3">
                  <label class="form-label">Project Name</label>
                  <input type="text" class="form-control" id="edit-project-name">
                </div>
                <div class="row g-2 mb-3">
                  <div class="col-6">
                    <label class="form-label">Type</label>
                    <input type="text" class="form-control" id="edit-project-type">
                  </div>
                  <div class="col-6">
                    <label class="form-label">Status</label>
                    <select class="form-select" id="edit-project-status">
                      <option value="active">Active</option>
                      <option value="on-hold">On Hold</option>
                      <option value="draft">Draft</option>
                    </select>
                  </div>
                </div>
                <div class="row g-2 mb-3">
                  <div class="col-6">
                    <label class="form-label">Payment</label>
                    <select class="form-select" id="edit-project-payment">
                      <option value="paid">Paid</option>
                      <option value="unpaid">Unpaid</option>
                    </select>
                  </div>
                  <div class="col-6">
                    <label class="form-label">Origin</label>
                    <select class="form-select" id="edit-project-origin">
                      <option value="client">Client</option>
                      <option value="internal">Internal</option>
                    </select>
                  </div>
                </div>
                <div class="mb-3">
                  <label class="form-label">Country</label>
                  <input type="text" class="form-control" id="edit-project-country">
                </div>
                <div class="mb-3">
                  <label class="form-label">Client Email <span class="text-muted" style="font-weight:400;">(optional)</span></label>
                  <input type="email" class="form-control" id="edit-project-client-email" placeholder="client@example.com">
                  <div class="form-text">If set, the client also receives the automatic final-summary report by email when this project is marked complete.</div>
                </div>
                <div class="mb-3">
                  <label class="form-label">Description</label>
                  <textarea class="form-control" id="edit-project-desc" rows="3"></textarea>
                </div>
              </div>
              <div class="modal-footer">
                <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" onclick="saveEditProject()">Save Changes</button>
              </div>
            </div>
          </div>
        </div>

        <!-- PROJECT DETAIL PAGE -->
        <div class="page" id="page-detail">
          <div class="d-flex align-items-center mb-4">
            <button class="btn btn-outline-secondary btn-sm me-3" onclick="switchPage('projects')">
              <i class="bi bi-arrow-left me-1"></i> Back
            </button>
            <h4 class="m-0" id="detail-page-title" style="font-weight:700;">Project Detail</h4>
          </div>

          <!-- PM Connect automatic tracking summary -->
          <div class="form-card mb-4">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
              <div id="pm-tracking-summary" style="font-size:13px; color:#64748b;">Loading tracking data…</div>
              <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-secondary" id="pm-report-link" onclick="openProjectReport()">
                  <i class="bi bi-file-earmark-pdf me-1"></i>Report
                </button>
                <button class="btn btn-sm btn-success" id="pm-complete-btn" onclick="toggleProjectComplete()">
                  <i class="bi bi-check-circle me-1"></i>Mark Complete
                </button>
              </div>
            </div>
            <!-- Daily activity log table -->
            <div id="pm-activity-table-container" style="display:none; border-top: 1px solid #e2e8f0; padding-top: 15px;">
              <h6 class="mb-3" style="font-size:14px; font-weight:600; color:#334155;">
                <i class="bi bi-activity text-primary me-1"></i> Last 30 Days Activity Log
              </h6>
              <div class="table-responsive">
                <table class="table table-sm table-hover align-middle" style="font-size:12px; margin-bottom:0;">
                  <thead class="table-light">
                    <tr>
                      <th>Date</th>
                      <th>Commits</th>
                      <th>Active Time</th>
                    </tr>
                  </thead>
                  <tbody id="pm-activity-table-body">
                    <!-- Dynamic content will go here -->
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Description + Documents -->
          <div class="row g-4 mb-4">
            <!-- Description -->
            <div class="col-md-6">
              <div class="form-card h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h6 class="m-0" style="font-weight:600; color:#334155;"><i class="bi bi-card-text me-2 text-primary"></i>Description</h6>
                  <button class="btn btn-sm btn-outline-secondary" style="font-size:11px;" onclick="toggleDescEdit()">
                    <i class="bi bi-pencil"></i> Edit
                  </button>
                </div>
                <div id="detail-description" style="font-size:14px; line-height:1.7; color:#64748b;">
                  <span class="fst-italic">No description provided.</span>
                </div>
                <div id="desc-edit-mode" style="display:none;">
                  <textarea class="form-control mb-2" id="desc-textarea" rows="4" placeholder="Add description..."></textarea>
                  <div class="d-flex gap-2">
                    <button class="btn btn-primary btn-sm" onclick="saveDescription()"><i class="bi bi-check-lg me-1"></i>Save</button>
                    <button class="btn btn-outline-secondary btn-sm" onclick="toggleDescEdit()">Cancel</button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Documents -->
            <div class="col-md-6">
              <div class="form-card h-100 d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h6 class="m-0" style="font-weight:600; color:#334155;"><i class="bi bi-paperclip me-2 text-primary"></i>Documents</h6>
                  <div class="d-flex gap-1">
                    <label class="btn btn-sm btn-outline-secondary" style="font-size:11px; cursor:pointer; margin:0;" title="Upload Files">
                      <i class="bi bi-files me-1"></i> Files
                      <input type="file" id="detail-file-input" multiple style="display:none;" onchange="uploadDetailFiles(this.files)">
                    </label>
                    <label class="btn btn-sm btn-outline-secondary" style="font-size:11px; cursor:pointer; margin:0;" title="Upload Folder">
                      <i class="bi bi-folder-plus me-1"></i> Folder
                      <input type="file" id="detail-folder-input" webkitdirectory style="display:none;" onchange="uploadDetailFiles(this.files)">
                    </label>
                  </div>
                </div>
                <div id="detail-files" style="overflow-y:auto; max-height:220px; flex:1;">
                  <div class="text-center text-muted" style="font-size:13px; padding:20px 0;">
                    <i class="bi bi-folder2-open d-block mb-2 fs-4"></i>No documents uploaded
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Tasks Section: 3 tabs -->
          <div class="row g-4">

            <!-- Tab 1: Task (Add new task form) -->
            <div class="col-md-4">
              <div class="form-card h-100 p-0" style="overflow:hidden;">
                <div style="background:#f8fafc; border-bottom:1px solid #e2e8f0; padding:10px 16px;">
                  <span style="display:inline-flex; align-items:center; gap:6px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:5px 14px; font-size:13px; font-weight:600; color:#334155;">
                    <i class="bi bi-plus-circle text-primary"></i> Task
                  </span>
                </div>
                <div class="p-4">
                  <div class="d-flex gap-2">
                    <input type="text" class="form-control" id="detail-task-title" placeholder="Task title…" onkeydown="if(event.key==='Enter') submitDetailTask()">
                    <button class="btn btn-primary" onclick="submitDetailTask()" style="white-space:nowrap;">
                      <i class="bi bi-plus-lg"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tab 2: Update (Pending tasks with inline edit) -->
            <div class="col-md-4">
              <div class="form-card h-100 p-0" style="overflow:hidden;">
                <div style="background:#f8fafc; border-bottom:1px solid #e2e8f0; padding:10px 16px;">
                  <span style="display:inline-flex; align-items:center; gap:6px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:5px 14px; font-size:13px; font-weight:600; color:#334155;">
                    <i class="bi bi-arrow-repeat text-warning"></i> Update
                    <span class="badge bg-warning text-dark rounded-pill ms-1" id="detail-count-pending">0</span>
                  </span>
                </div>
                <div class="p-3 d-flex flex-column gap-3" id="detail-list-pending">
                  <div class="text-center text-muted p-3" style="font-size:13px;">No pending tasks</div>
                </div>
              </div>
            </div>

            <!-- Tab 3: Links -->
            <div class="col-md-4">
              <div class="form-card h-100 p-0" style="overflow:hidden;">
                <div style="background:#f8fafc; border-bottom:1px solid #e2e8f0; padding:10px 16px;">
                  <span style="display:inline-flex; align-items:center; gap:6px; background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:5px 14px; font-size:13px; font-weight:600; color:#334155;">
                    <i class="bi bi-link-45deg text-primary"></i> Links
                  </span>
                </div>
                <div class="p-3">
                  <div class="d-flex gap-2 mb-3">
                    <input type="text" class="form-control form-control-sm" id="link-title" placeholder="Title">
                    <input type="url" class="form-control form-control-sm" id="link-url" placeholder="https://...">
                    <button class="btn btn-primary btn-sm" onclick="addDetailLink()" style="white-space:nowrap; padding:4px 10px;">
                      <i class="bi bi-plus-lg"></i>
                    </button>
                  </div>
                  <div id="detail-links-list" class="d-flex flex-column gap-2">
                    <div class="text-center text-muted p-3" style="font-size:13px;">No links added</div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>


      </div>
    </div>
  </div>

  <!-- TOAST -->
  <div class="toast-box" id="toast"></div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
  <script src="js/app.js?v=<?= filemtime(__DIR__ . '/js/app.js') ?>"></script>
</body>

</html>