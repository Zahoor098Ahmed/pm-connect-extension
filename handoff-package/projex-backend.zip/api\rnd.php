<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query("
        SELECT r.id, r.question, r.category, r.priority, r.status, r.owner,
               DATE_FORMAT(r.created_at, '%d %b %Y') AS created_at,
               p.name AS project_name
        FROM research_log r
        LEFT JOIN projects p ON p.id = r.project_id
        ORDER BY r.created_at DESC
    ")->fetchAll();

    jsonResponse(['success' => true, 'entries' => $rows]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $question   = trim($_POST['question'] ?? '');
        $projectId  = intval($_POST['project_id'] ?? 0) ?: null;
        $category   = $_POST['category'] ?? 'Technical';
        $priority   = $_POST['priority'] ?? 'medium';
        $owner      = trim($_POST['owner'] ?? '');

        if (!$question) jsonResponse(['success' => false, 'error' => 'Research question is required'], 400);
        if (!in_array($category, ['Technical', 'Legal', 'Market', 'Other'], true)) $category = 'Other';
        if (!in_array($priority, ['low', 'medium', 'high'], true)) $priority = 'medium';

        $stmt = $pdo->prepare("INSERT INTO research_log (question, project_id, category, priority, owner) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$question, $projectId, $category, $priority, $owner ?: null]);

        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'updateStatus') {
        $id     = intval($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if (!$id || !in_array($status, ['open', 'in_progress', 'resolved'], true)) {
            jsonResponse(['success' => false, 'error' => 'Valid id and status required'], 400);
        }
        $pdo->prepare("UPDATE research_log SET status = ? WHERE id = ?")->execute([$status, $id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
