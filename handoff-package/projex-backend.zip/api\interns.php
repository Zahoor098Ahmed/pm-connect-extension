<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Real people flagged is_intern=1, with their real open/in-progress task
    // counts — same honesty rule as Capacity: no fabricated status buckets.
    $interns = $pdo->query("
        SELECT u.id, u.name, u.email,
               COUNT(t.id) AS active_tasks,
               SUM(CASE WHEN t.status = 'todo' THEN 1 ELSE 0 END) AS awaiting,
               SUM(CASE WHEN t.status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress
        FROM users u
        LEFT JOIN tasks t ON t.assignee COLLATE utf8mb4_general_ci = u.name AND t.status IN ('todo','in_progress') AND t.parent_task_id IS NULL
        WHERE u.is_intern = 1
        GROUP BY u.id
        ORDER BY u.name
    ")->fetchAll();

    $queue = $pdo->query("
        SELECT t.id, t.title, t.priority, t.due_date, t.status, t.assignee, p.name AS project_name
        FROM tasks t
        JOIN projects p ON p.id = t.project_id
        JOIN users u ON u.name = t.assignee COLLATE utf8mb4_general_ci AND u.is_intern = 1
        WHERE t.parent_task_id IS NULL AND t.status != 'done'
        ORDER BY t.due_date IS NULL, t.due_date ASC
        LIMIT 20
    ")->fetchAll();

    jsonResponse(['success' => true, 'interns' => $interns, 'queue' => $queue]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'setIntern') {
        $id = intval($_POST['id'] ?? 0);
        $isIntern = intval($_POST['is_intern'] ?? 0) ? 1 : 0;
        if (!$id) jsonResponse(['success' => false, 'error' => 'id required'], 400);

        $pdo->prepare("UPDATE users SET is_intern = ? WHERE id = ?")->execute([$isIntern, $id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
