<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'matrix';

    if ($action === 'matrix') {
        $users  = $pdo->query("SELECT id, name FROM users ORDER BY name")->fetchAll();
        $skills = $pdo->query("SELECT id, name FROM skills ORDER BY name")->fetchAll();
        $levels = $pdo->query("SELECT user_id, skill_id, level FROM user_skills")->fetchAll();

        $levelMap = [];
        foreach ($levels as $l) {
            $levelMap[$l['user_id']][$l['skill_id']] = $l['level'];
        }

        jsonResponse(['success' => true, 'users' => $users, 'skills' => $skills, 'levels' => $levelMap]);
    }

    if ($action === 'library') {
        // How many people have each skill at what level — real counts only.
        $rows = $pdo->query("
            SELECT s.id, s.name,
                   COUNT(us.id) AS people_count,
                   SUM(CASE WHEN us.level = 'expert' THEN 1 ELSE 0 END) AS experts
            FROM skills s
            LEFT JOIN user_skills us ON us.skill_id = s.id AND us.level != 'none'
            GROUP BY s.id
            ORDER BY s.name
        ")->fetchAll();
        jsonResponse(['success' => true, 'skills' => $rows]);
    }

    if ($action === 'gaps') {
        // A "gap" = a skill nobody has past beginner level. Purely derived
        // from real user_skills rows, no invented skill demand data.
        $rows = $pdo->query("
            SELECT s.id, s.name,
                   COUNT(CASE WHEN us.level IN ('advanced','expert') THEN 1 END) AS strong_count,
                   COUNT(CASE WHEN us.level = 'beginner' THEN 1 END) AS beginner_count
            FROM skills s
            LEFT JOIN user_skills us ON us.skill_id = s.id
            GROUP BY s.id
            HAVING strong_count = 0
            ORDER BY s.name
        ")->fetchAll();
        jsonResponse(['success' => true, 'gaps' => $rows]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'addSkill') {
        $name = trim($_POST['name'] ?? '');
        if (!$name) jsonResponse(['success' => false, 'error' => 'Skill name required'], 400);

        $stmt = $pdo->prepare("INSERT IGNORE INTO skills (name) VALUES (?)");
        $stmt->execute([$name]);
        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'setLevel') {
        $userId  = intval($_POST['user_id'] ?? 0);
        $skillId = intval($_POST['skill_id'] ?? 0);
        $level   = $_POST['level'] ?? 'none';
        $allowed = ['none', 'beginner', 'intermediate', 'advanced', 'expert'];

        if (!$userId || !$skillId || !in_array($level, $allowed, true)) {
            jsonResponse(['success' => false, 'error' => 'Valid user_id, skill_id and level required'], 400);
        }

        $stmt = $pdo->prepare("
            INSERT INTO user_skills (user_id, skill_id, level) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE level = VALUES(level)
        ");
        $stmt->execute([$userId, $skillId, $level]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
