-- Run this once against projex_db to add what PM Connect needs.
-- Safe to run on the existing database — only adds new columns/tables.

ALTER TABLE `users` ADD COLUMN `api_key` VARCHAR(64) NULL UNIQUE;

ALTER TABLE `tasks`
  ADD COLUMN `progress` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN `total_minutes` INT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN `last_commit_message` VARCHAR(255) NULL;

CREATE TABLE IF NOT EXISTS `task_time_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_id` INT NOT NULL,
  `employee` VARCHAR(255) NOT NULL,
  `minutes` INT UNSIGNED NOT NULL,
  `note` VARCHAR(500) NULL,
  `logged_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_time_logs_task` FOREIGN KEY (`task_id`) REFERENCES `tasks`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Give the existing user (ali@gmail.com, id 1) a PM Connect API key so you can
-- test immediately. Change this to something less guessable before real use.
UPDATE `users` SET `api_key` = 'test-key-123' WHERE `id` = 1;
