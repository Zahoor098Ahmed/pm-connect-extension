<?php
require_once __DIR__ . '/api/config.php';
$db = getDB();

$token = trim($_GET['token'] ?? '');
$project = null;

if ($token) {
    $stmt = $db->prepare("SELECT id, name, description, status, phase, started_at, completed_at FROM projects WHERE share_token = ?");
    $stmt->execute([$token]);
    $project = $stmt->fetch();
}

$tasks = [];
if ($project) {
    $stmt = $db->prepare("
        SELECT title, status, priority, due_date
        FROM tasks
        WHERE project_id = ? AND parent_task_id IS NULL
        ORDER BY status = 'done', due_date IS NULL, due_date ASC
    ");
    $stmt->execute([$project['id']]);
    $tasks = $stmt->fetchAll();
}

$phaseLabels = [
    'initiation' => 'Initiation', 'planning' => 'Planning', 'execution' => 'Execution',
    'review' => 'Review', 'closure' => 'Closure', 'post_sale' => 'Post-Sale',
];
$phaseOrder = array_keys($phaseLabels);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $project ? htmlspecialchars($project['name']) . ' — ' : '' ?>Client Portal</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
<body>
  <div class="container py-5" style="max-width:760px;">
    <div class="d-flex align-items-center gap-2 mb-4">
      <div class="brand-icon"><i class="bi bi-shield-check"></i></div>
      <span class="brand-name">Client Portal</span>
    </div>

    <?php if (!$project): ?>
      <div class="empty-state">
        <i class="bi bi-link-45deg"></i>
        <p>This link is invalid or has expired. Please ask your project contact for a new one.</p>
      </div>
    <?php else: ?>
      <div class="form-card mb-4">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <h4 class="fw-bold mb-0"><?= htmlspecialchars($project['name']) ?></h4>
          <span class="status-pill <?= $project['status'] === 'active' ? 's-active' : ($project['status'] === 'draft' ? 's-draft' : 's-on-hold') ?>"><?= htmlspecialchars($project['status']) ?></span>
        </div>
        <p class="text-muted" style="font-size:13.5px;"><?= htmlspecialchars($project['description'] ?: 'No description provided.') ?></p>

        <div class="d-flex flex-wrap gap-2 mt-3">
          <?php foreach ($phaseOrder as $p): $reached = array_search($p, $phaseOrder) <= array_search($project['phase'], $phaseOrder); ?>
            <span class="dash-pill <?= $p === $project['phase'] ? 'dash-fidelity-badge is-med' : ($reached ? 'dash-pill-status is-done' : 'dash-pill-status') ?>">
              <?= $phaseLabels[$p] ?>
            </span>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="form-card">
        <div class="dash-heading mb-3">Milestones &amp; Tasks</div>
        <?php if (!$tasks): ?>
          <div class="text-muted" style="font-size:13px;">No tasks published yet.</div>
        <?php else: foreach ($tasks as $t): ?>
          <div class="d-flex align-items-center justify-content-between py-2 border-bottom">
            <div style="font-size:13.5px; <?= $t['status'] === 'done' ? 'text-decoration:line-through; color:#94A3B8;' : '' ?>">
              <?= htmlspecialchars($t['title']) ?>
            </div>
            <span class="status-pill <?= $t['status'] === 'done' ? 's-active' : 's-draft' ?>"><?= str_replace('_', ' ', $t['status']) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
