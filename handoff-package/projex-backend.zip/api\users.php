<?php
session_start();
require_once __DIR__ . '/config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];

/* ── PUBLIC: self signup ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'signup') {
    $name     = trim($_POST['name']     ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$name || !$email || !$password) {
        jsonResponse(['success' => false, 'error' => 'All fields are required'], 400);
    }
    if (strlen($password) < 6) {
        jsonResponse(['success' => false, 'error' => 'Password must be at least 6 characters'], 400);
    }
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(['success' => false, 'error' => 'Email already registered'], 400);
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO users (name, email, password, employee_id) VALUES (?, ?, ?, ?)")
        ->execute([$name, $email, $hash, nextEmployeeId($db)]);
    jsonResponse(['success' => true]);
}

/* ── Distinct clients — derived from real invoice data, no separate client table ── */
if ($method === 'GET' && ($_GET['action'] ?? '') === 'clients') {
    $rows = $db->query("
        SELECT client AS name, COUNT(*) AS invoice_count, COALESCE(SUM(amount), 0) AS total_billed
        FROM invoices
        WHERE client IS NOT NULL AND client != ''
        GROUP BY client
        ORDER BY total_billed DESC
    ")->fetchAll();
    jsonResponse(['success' => true, 'clients' => $rows]);
}

/* ── List users, with their PM Connect API key + Employee ID (for admin) ── */
if ($method === 'GET') {
    $rows = $db->query("SELECT id, name, email, role, api_key, employee_id FROM users ORDER BY name")->fetchAll();
    jsonResponse(['success' => true, 'users' => $rows]);
}

/**
 * Employee ID is display-only (e.g. EMP004) — it identifies a person on the
 * website/admin panel. It is NOT what's used to connect in VS Code; that's
 * still the api_key. Generated from the next free numeric id.
 */
function nextEmployeeId(PDO $db): string {
    $max = (int) $db->query("SELECT COALESCE(MAX(id), 0) FROM users")->fetchColumn();
    return 'EMP' . str_pad((string) ($max + 1), 3, '0', STR_PAD_LEFT);
}

/* ── Admin: create a new developer + immediately give them an API key ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'admin_create') {
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if (!$name || !$email) {
        jsonResponse(['success' => false, 'error' => 'Name and email are required'], 400);
    }
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(['success' => false, 'error' => 'Email already registered'], 400);
    }

    $password = password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT); // random, unused for now
    $apiKey = bin2hex(random_bytes(20));
    $employeeId = nextEmployeeId($db);
    $db->prepare("INSERT INTO users (name, email, password, api_key, employee_id) VALUES (?, ?, ?, ?, ?)")
        ->execute([$name, $email, $password, $apiKey, $employeeId]);

    jsonResponse(['success' => true, 'id' => $db->lastInsertId(), 'api_key' => $apiKey, 'employee_id' => $employeeId]);
}

/* ── Generate/regenerate a developer's PM Connect API key ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'generate_key') {
    $id = intval($_POST['id'] ?? 0);
    if (!$id) jsonResponse(['success' => false, 'error' => 'User ID required'], 400);

    $key = bin2hex(random_bytes(20)); // 40 hex chars, plenty unique
    $db->prepare("UPDATE users SET api_key = ? WHERE id = ?")->execute([$key, $id]);
    jsonResponse(['success' => true, 'api_key' => $key]);
}

/* ── Admin: change a user's role ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'setRole') {
    $id   = intval($_POST['id'] ?? 0);
    $role = $_POST['role'] ?? '';
    if (!$id || !in_array($role, ['admin', 'manager', 'developer'], true)) {
        jsonResponse(['success' => false, 'error' => 'Valid id and role required'], 400);
    }
    $db->prepare("UPDATE users SET role = ? WHERE id = ?")->execute([$role, $id]);
    jsonResponse(['success' => true]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
