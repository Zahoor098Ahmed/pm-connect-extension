const API = 'api/';
const TYPE_COLORS = ['#534AB7', '#1D9E75', '#D85A30', '#185FA5', '#BA7517', '#D4537E'];
const PAGE_META = {
  dashboard: ['Dashboard', 'Real-time overview across every project'],
  projects: ['Projects', 'All your workspace projects'],
  new: ['Add project', 'Fill in details and upload files'],
  tasks: ['Task Assignment', 'Manage and assign tasks'],
  detail: ['Project Detail', 'Tasks, documents & description'],
  settings: ['Settings', 'Manage project types'],
  developers: ['Developers', 'Real PM Connect activity — no dummy data'],
  people: ['People', 'Everyone in your workspace'],
  skills: ['Skills Matrix', 'Proficiency across the team'],
  rnd: ['R&D Log', 'Open questions, in-flight research and resolved findings'],
  billing: ['Billing', 'Invoices raised against your projects'],
  estimations: ['Estimations', 'Inquiries, quotes and pipeline'],
  capacity: ['Capacity', 'Real active-task load vs. stated weekly capacity'],
  interns: ['Interns', 'Intern work queue and assignment status'],
  timecost: ['Time & Cost', 'Real tracked coding time and manual logs'],
  services: ['Services', 'Your service catalog'],
  lifecycle: ['Project Lifecycle', 'Track a project from initiation to closure'],
  reports: ['Reports', 'Real data pulled from every module, exportable as CSV'],
  clientportal: ['Client Portal', 'Read-only links you can share with clients']
};

const CAPACITY_TAB_DESC = {
  org: 'Real active-task load across the whole team.',
  manager: 'Same real data, sorted for a manager checking who is overloaded right now.',
  accountant: 'Same real data — cross-reference with Time & Cost → Organisation Cost Report for billed hours.',
};

const subTabLoaders = {
  'estimations:new_inquiry': () => renderEstimationsTable('new_inquiry'),
  'estimations:queue': () => renderEstimationsTable('queue'),
  'estimations:pipeline': () => renderEstimationsTable('pipeline'),
  'capacity:org': () => { document.getElementById('capacity-tab-desc').textContent = CAPACITY_TAB_DESC.org; },
  'capacity:manager': () => { document.getElementById('capacity-tab-desc').textContent = CAPACITY_TAB_DESC.manager; },
  'capacity:accountant': () => { document.getElementById('capacity-tab-desc').textContent = CAPACITY_TAB_DESC.accountant; },
  'interns:newtask': () => populateInternNewTaskForm(),
  'people:clients': () => loadClientsTab(),
  'people:roles': () => loadRolesTab(),
  'people:audit': () => loadAuditTab(),
  'timecost:approvals': () => loadApprovalsTab(),
  'timecost:projectcost': () => loadProjectCostTab(),
  'timecost:orgcost': () => loadOrgCostTab(),
  'skills:library': () => loadSkillsLibraryTab(),
  'skills:gaps': () => loadSkillsGapsTab(),
  'rnd:kb': () => loadKnowledgeBaseTab(),
}; // more entries registered further down, per "page:tab" key

async function loadKnowledgeBaseTab() {
  const list = document.getElementById('kb-list');
  const res = await fetch(API + 'knowledge.php');
  const data = await res.json();
  const articles = data.articles || [];
  list.innerHTML = articles.length ? articles.map(a => `
    <div class="form-card mb-2 p-3">
      <div class="d-flex justify-content-between align-items-start">
        <div class="fw-bold" style="font-size:14.5px;">${esc(a.title)}</div>
        <button class="btn btn-sm btn-outline-danger" style="padding:2px 8px; font-size:11px;" onclick="deleteKbArticle(${a.id})"><i class="bi bi-trash"></i></button>
      </div>
      <div class="text-muted mb-2" style="font-size:13px; white-space:pre-wrap;">${esc(a.content)}</div>
      ${a.tags ? a.tags.split(',').map(t => `<span class="type-badge me-1">${esc(t.trim())}</span>`).join('') : ''}
    </div>`).join('') : '<div class="empty-state"><i class="bi bi-journal-text"></i><p>No articles yet — add one above.</p></div>';
}

async function addKbArticle() {
  const title = document.getElementById('kb-title').value.trim();
  const content = document.getElementById('kb-content').value.trim();
  if (!title || !content) { showToast('Title and content are required'); return; }
  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('title', title);
  fd.append('content', content);
  fd.append('tags', document.getElementById('kb-tags').value.trim());
  const res = await fetch(API + 'knowledge.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    ['kb-title', 'kb-content', 'kb-tags'].forEach(id => document.getElementById(id).value = '');
    showToast('Article added');
    loadKnowledgeBaseTab();
  } else {
    showToast(data.error || 'Failed to add article');
  }
}

async function deleteKbArticle(id) {
  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id', id);
  const res = await fetch(API + 'knowledge.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Article removed'); loadKnowledgeBaseTab(); } else showToast(data.error || 'Failed');
}

async function loadSkillsLibraryTab() {
  const grid = document.getElementById('skills-library-grid');
  const res = await fetch(API + 'skills.php?action=library');
  const data = await res.json();
  const skills = data.skills || [];
  grid.innerHTML = skills.length ? skills.map(s => `
    <div class="col-md-4">
      <div class="form-card h-100 p-3">
        <div class="fw-bold mb-1" style="font-size:15px;">${esc(s.name)}</div>
        <div class="text-muted" style="font-size:12.5px;">${s.people_count} ${s.people_count == 1 ? 'person has' : 'people have'} this skill</div>
        ${s.experts > 0 ? `<span class="status-pill s-active mt-2 d-inline-block">${s.experts} expert${s.experts == 1 ? '' : 's'}</span>` : ''}
      </div>
    </div>`).join('') : '<div class="col-12"><div class="empty-state"><i class="bi bi-bar-chart-steps"></i><p>No skills yet — add one from the Matrix tab.</p></div></div>';
}

async function loadSkillsGapsTab() {
  const grid = document.getElementById('skills-gaps-grid');
  const res = await fetch(API + 'skills.php?action=gaps');
  const data = await res.json();
  const gaps = data.gaps || [];
  grid.innerHTML = gaps.length ? gaps.map(s => `
    <div class="col-md-4">
      <div class="form-card h-100 p-3">
        <div class="fw-bold mb-1" style="font-size:15px;">${esc(s.name)}</div>
        <span class="status-pill s-on-hold">No advanced/expert coverage</span>
        ${s.beginner_count > 0 ? `<div class="text-muted mt-2" style="font-size:12px;">${s.beginner_count} at beginner level</div>` : ''}
      </div>
    </div>`).join('') : '<div class="col-12"><div class="empty-state"><i class="bi bi-check-circle"></i><p>No coverage gaps — every skill has at least one advanced/expert person.</p></div></div>';
}

async function loadApprovalsTab() {
  const body = document.getElementById('approvals-table-body');
  const res = await fetch(API + 'timecost.php?action=approvals');
  const data = await res.json();
  const logs = data.logs || [];
  body.innerHTML = logs.length ? logs.map(l => `
    <tr>
      <td class="ps-3">${esc(l.employee)}</td>
      <td>${esc(l.task_title)}</td>
      <td class="text-muted">${esc(l.project_name)}</td>
      <td>${l.minutes}m</td>
      <td class="text-muted">${esc(l.logged_at)}</td>
      <td class="pe-3">
        ${Number(l.approved)
          ? '<span class="status-pill s-active">Approved</span>'
          : `<button class="btn btn-sm btn-outline-primary" style="padding:2px 10px; font-size:11px;" onclick="approveTimeLog(${l.id})">Approve</button>`}
      </td>
    </tr>`).join('') : '<tr><td colspan="6" class="text-muted text-center py-4">No time logs yet.</td></tr>';
}

async function approveTimeLog(id) {
  const fd = new FormData();
  fd.append('action', 'approve');
  fd.append('id', id);
  const res = await fetch(API + 'timecost.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Approved'); loadApprovalsTab(); } else showToast(data.error || 'Failed');
}

async function loadProjectCostTab() {
  const body = document.getElementById('projectcost-table-body');
  const res = await fetch(API + 'timecost.php');
  const data = await res.json();
  const tracked = data.tracked || [];
  body.innerHTML = tracked.length ? tracked.map(t => `
    <tr>
      <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(t.project_name)}</td>
      <td class="pe-3">${formatSeconds(t.active_seconds)}</td>
    </tr>`).join('') : '<tr><td colspan="2" class="text-muted text-center py-4">No tracked time yet.</td></tr>';
}

async function loadOrgCostTab() {
  const el = document.getElementById('orgcost-stats');
  const res = await fetch(API + 'timecost.php?action=orgCost');
  const data = await res.json();
  el.innerHTML = `
    <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#4F46E5;"></span> Tracked coding time</div><div class="stat-value">${formatSeconds(data.totalActiveSeconds)}</div></div></div>
    <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#B45309;"></span> Manual time logged</div><div class="stat-value">${data.totalManualMinutes}m</div></div></div>
    <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#15803D;"></span> Total invoiced</div><div class="stat-value">${formatMoney(data.totalInvoiced)}</div></div></div>
  `;
}

async function loadClientsTab() {
  const body = document.getElementById('clients-table-body');
  const res = await fetch(API + 'users.php?action=clients');
  const data = await res.json();
  const clients = data.clients || [];
  body.innerHTML = clients.length ? clients.map(c => `
    <tr>
      <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(c.name)}</td>
      <td>${c.invoice_count}</td>
      <td class="pe-3 fw-semibold">${formatMoney(c.total_billed)}</td>
    </tr>`).join('') : '<tr><td colspan="3" class="text-muted text-center py-4">No clients yet — raise an invoice in Billing.</td></tr>';
}

const ROLE_OPTIONS = ['admin', 'manager', 'developer'];

async function loadRolesTab() {
  const body = document.getElementById('roles-table-body');
  const res = await fetch(API + 'users.php');
  const data = await res.json();
  const users = data.users || [];
  body.innerHTML = users.length ? users.map(u => `
    <tr>
      <td class="ps-3 d-flex align-items-center gap-2 py-2">${avatarHtml(u.name, 24)}<span>${esc(u.name)}</span></td>
      <td class="pe-3">
        <select class="form-select form-select-sm" style="width:150px;" onchange="setUserRole(${u.id}, this.value)">
          ${ROLE_OPTIONS.map(r => `<option value="${r}" ${r === u.role ? 'selected' : ''}>${r}</option>`).join('')}
        </select>
      </td>
    </tr>`).join('') : '<tr><td colspan="2" class="text-muted text-center py-4">No people yet.</td></tr>';
}

async function setUserRole(id, role) {
  const fd = new FormData();
  fd.append('action', 'setRole');
  fd.append('id', id);
  fd.append('role', role);
  const res = await fetch(API + 'users.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) showToast('Role updated'); else showToast(data.error || 'Failed to update role');
}

async function loadAuditTab() {
  const body = document.getElementById('audit-table-body');
  const res = await fetch(API + 'audit.php');
  const data = await res.json();
  const entries = data.entries || [];
  body.innerHTML = entries.length ? entries.map(a => `
    <tr>
      <td class="ps-3 text-muted">${esc(a.created_at)}</td>
      <td class="fw-semibold" style="color:var(--text-main);">${esc(a.employee)}</td>
      <td><span class="type-badge">${esc(a.action)}</span></td>
      <td class="pe-3 text-muted">${esc(a.task_title || a.detail || '—')}</td>
    </tr>`).join('') : '<tr><td colspan="4" class="text-muted text-center py-4">No activity recorded yet.</td></tr>';
}

async function populateInternNewTaskForm() {
  const projSel = document.getElementById('intern-newtask-project');
  const assigneeSel = document.getElementById('intern-newtask-assignee');
  if (projSel.dataset.filled) return;
  projSel.dataset.filled = '1';

  const [projRes, internRes] = await Promise.all([
    fetch(API + 'projects.php').then(r => r.json()),
    fetch(API + 'interns.php').then(r => r.json()),
  ]);
  (projRes.projects || []).forEach(p => projSel.insertAdjacentHTML('beforeend', `<option value="${p.id}">${esc(p.name)}</option>`));
  assigneeSel.innerHTML = (internRes.interns || []).map(i => `<option value="${esc(i.name)}">${esc(i.name)}</option>`).join('')
    || '<option value="">No interns yet — add one from People</option>';
}

async function createInternTask() {
  const projectId = document.getElementById('intern-newtask-project').value;
  const title = document.getElementById('intern-newtask-title').value.trim();
  const assignee = document.getElementById('intern-newtask-assignee').value;
  if (!projectId || !title) { showToast('Project and title are required'); return; }

  const fd = new FormData();
  fd.append('project_id', projectId);
  fd.append('title', title);
  fd.append('assignee', assignee);
  const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    document.getElementById('intern-newtask-title').value = '';
    showToast('Task created');
    loadInterns();
  } else {
    showToast(data.error || 'Failed to create task');
  }
}

let pendingFiles = [];
let currentProjectId = null;
let currentProjectName = '';
let currentProject = null;
let allProjects = [];
/* ── AUTHENTICATION ── */
function switchLoginTab(tab) {
  const isAdmin = tab === 'admin';
  document.getElementById('panel-admin').style.display = isAdmin ? 'block' : 'none';
  document.getElementById('panel-user').style.display  = isAdmin ? 'none'  : 'block';
  document.getElementById('tab-btn-admin').style.cssText = isAdmin
    ? 'border-radius:8px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);border:none;font-size:13px;'
    : 'border-radius:8px;background:transparent;border:none;font-size:13px;color:#94a3b8;';
  document.getElementById('tab-btn-user').style.cssText = isAdmin
    ? 'border-radius:8px;background:transparent;border:none;font-size:13px;color:#94a3b8;'
    : 'border-radius:8px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);border:none;font-size:13px;';
}

function showUserLogin()  {
  document.getElementById('user-login-panel').style.display  = 'block';
  document.getElementById('user-signup-panel').style.display = 'none';
}
function showUserSignup() {
  document.getElementById('user-login-panel').style.display  = 'none';
  document.getElementById('user-signup-panel').style.display = 'block';
}

async function handleUserLogin() {
  const email = document.getElementById('u-email').value.trim();
  const pass  = document.getElementById('u-pass').value;
  const err   = document.getElementById('u-login-err');
  err.style.display = 'none';
  const fd = new FormData();
  fd.append('action', 'login');
  fd.append('email', email);
  fd.append('password', pass);
  const res  = await fetch(API + 'auth.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success && data.role === 'user') {
    showApp();
  } else if (data.success && data.role === 'admin') {
    err.textContent = 'Use Admin tab to login as admin.';
    err.style.display = 'block';
  } else {
    err.textContent = data.error || 'Invalid credentials';
    err.style.display = 'block';
  }
}

async function handleUserSignup() {
  const name  = document.getElementById('u-name').value.trim();
  const email = document.getElementById('u-signup-email').value.trim();
  const pass  = document.getElementById('u-signup-pass').value.trim();
  const err   = document.getElementById('u-signup-err');
  const ok    = document.getElementById('u-signup-ok');
  err.style.display = 'none';
  ok.style.display  = 'none';
  const fd = new FormData();
  fd.append('action', 'signup');
  fd.append('name', name);
  fd.append('email', email);
  fd.append('password', pass);
  const res  = await fetch(API + 'users.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    ok.textContent = 'Account created! You can now sign in.';
    ok.style.display = 'block';
    document.getElementById('u-name').value = '';
    document.getElementById('u-signup-email').value = '';
    document.getElementById('u-signup-pass').value  = '';
    setTimeout(() => showUserLogin(), 1800);
  } else {
    err.textContent = data.error || 'Signup failed';
    err.style.display = 'block';
  }
}

async function checkAuth() {
  const res = await fetch(API + 'auth.php');
  const data = await res.json();
  if (data.authenticated) {
    renderTopbarUser(data.name || data.email || '?');
    showApp();
  } else {
    showLogin();
  }
}

function renderTopbarUser(nameOrEmail) {
  const el = document.getElementById('topbar-avatar');
  if (!el) return;
  const initials = nameOrEmail.split(/[\s@.]+/).filter(Boolean).slice(0, 2).map(s => s[0].toUpperCase()).join('') || '?';
  el.textContent = initials;
  el.title = nameOrEmail;
  el.style.background = avatarColorFor(nameOrEmail);
}

async function handleLogin() {
  const e = document.getElementById('login-email').value;
  const p = document.getElementById('login-password').value;
  const err = document.getElementById('login-error');

  const fd = new FormData();
  fd.append('action', 'login');
  fd.append('email', e);
  fd.append('password', p);

  const res = await fetch(API + 'auth.php', { method: 'POST', body: fd });
  const data = await res.json();

  if (data.success) {
    showApp();
  } else {
    err.textContent = data.error || 'Login failed';
    err.style.display = 'block';
  }
}

async function handleLogout() {
  const fd = new FormData();
  fd.append('action', 'logout');
  await fetch(API + 'auth.php', { method: 'POST', body: fd });
  showLogin();
}

function showApp() {
  document.getElementById('login-screen').style.setProperty('display', 'none', 'important');
  document.getElementById('app-shell').style.setProperty('display', 'flex', 'important');
  loadProjects().then(openDeepLinkedTask);
  loadAssignees();
  loadDashboard();
}

/* Handles links like ?project=9&task=17#tasks — what PM Connect's "My Tasks"
   sidebar in VS Code opens when you click a task, so it lands you straight
   on that task on the website instead of just the homepage. */
function openDeepLinkedTask() {
  const params = new URLSearchParams(window.location.search);
  const projectId = params.get('project');
  const taskId = params.get('task');
  if (!projectId) return;

  currentProjectId = projectId;
  const project = allProjects.find(p => p.id == projectId);
  currentProjectName = project ? project.name : '';
  switchPage('tasks');

  if (taskId) {
    setTimeout(() => {
      const el = document.getElementById('task-card-' + taskId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('highlight-task');
        setTimeout(() => el.classList.remove('highlight-task'), 2500);
      }
    }, 400);
  }
}

/* Populates the "Assign To" dropdown with real registered users, so tasks
   are always assigned to a name that exactly matches a PM Connect API key
   holder — no typos, no mismatches between the website and VS Code. */
async function loadAssignees() {
  try {
    const res = await fetch(API + 'users.php');
    const data = await res.json();
    const select = document.getElementById('task-assignee');
    if (!select || !data.success) return;
    select.innerHTML = '<option value="">Select a person…</option>' +
      data.users.map(u => `<option value="${esc(u.name)}">${esc(u.name)}</option>`).join('');
  } catch (e) {
    console.error("Failed to load assignees", e);
  }
}

/* Lets an admin add a brand-new developer right from the Assign Task form,
   and immediately hands back their PM Connect API key so it can be copied
   and sent to them — no need to go to Settings separately. */
async function addDeveloper() {
  const nameInp = document.getElementById('new-dev-name');
  const emailInp = document.getElementById('new-dev-email');
  const name = nameInp.value.trim();
  const email = emailInp.value.trim();
  if (!name || !email) { showToast('Name and email required'); return; }

  const fd = new FormData();
  fd.append('action', 'admin_create');
  fd.append('name', name);
  fd.append('email', email);
  const res = await fetch(API + 'users.php', { method: 'POST', body: fd });
  const data = await res.json();

  if (data.success) {
    nameInp.value = '';
    emailInp.value = '';
    loadAssignees();
    if (document.getElementById('api-key-list')) loadApiKeys();
    navigator.clipboard.writeText(data.api_key).catch(() => {});
    alert(`Developer "${name}" created.\n\nAPI Key (copied to clipboard):\n${data.api_key}\n\nGive this to them to connect PM Connect in VS Code.`);
  } else {
    showToast(data.error || 'Failed to create developer');
  }
}

function showLogin() {
  document.getElementById('login-screen').style.setProperty('display', 'flex', 'important');
  document.getElementById('app-shell').style.setProperty('display', 'none', 'important');
}

/* ── NAVIGATION ── */
function switchPage(name, projectId = null, projectName = '', tab = null) {
  if (projectId) {
    currentProjectId = projectId;
    currentProjectName = projectName;
    document.getElementById('detail-project-name').textContent = projectName + ' Tasks';
  }

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#sidebar .nav-link').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('#sidebar .nav-sub li a').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  const navLink = document.querySelector(`[onclick^="toggleNavSubs(this); switchPage('${name}')"], [onclick="switchPage('${name}')"]`);
  if (navLink) navLink.classList.add('active');

  // Expand this item's sidebar submenu (if any) and collapse the others.
  document.querySelectorAll('#sidebar .nav-item.has-subs').forEach(li => {
    li.classList.toggle('expanded', li.dataset.page === name);
  });

  document.getElementById('page-title').textContent = PAGE_META[name][0];
  document.getElementById('page-sub').textContent = PAGE_META[name][1];
  if (name === 'dashboard') loadDashboard();
  if (name === 'projects') loadProjects();
  if (name === 'new') loadTypesIntoSelect();
  if (name === 'tasks') {
    populateTasksProjectSelect();
    if (currentProjectId) {
      loadTasks();
    } else {
      for (const key of ['todo', 'in_progress', 'done']) {
        document.getElementById(`task-list-${key}`).innerHTML = '<div class="text-center text-muted p-3" style="font-size:12px;">Select a project first</div>';
        document.getElementById(`task-count-${key}`).textContent = '0';
      }
    }
  }
  if (name === 'detail') loadProjectDetail();
  if (name === 'settings') loadSettings();
  if (name === 'developers') loadDeveloperDirectory();
  if (name === 'people') loadPeople();
  if (name === 'skills') loadSkillsMatrix();
  if (name === 'rnd') loadRnd();
  if (name === 'billing') loadBilling();
  if (name === 'estimations') loadEstimations();
  if (name === 'capacity') loadCapacity();
  if (name === 'interns') loadInterns();
  if (name === 'timecost') loadTimeCost();
  if (name === 'services') loadServices();
  if (name === 'lifecycle') loadLifecycleProjectSelect();
  if (name === 'reports') loadReports();
  if (name === 'clientportal') loadClientPortal();

  if (tab) requestAnimationFrame(() => showSubTab(name, tab));
}

/* ── SIDEBAR SUBMENU + IN-PAGE SUB-TABS ── */
function toggleNavSubs(linkEl) {
  linkEl.closest('.nav-item').classList.toggle('expanded');
}

// Generic tab strip controller — each page with sub-tabs has
// <div class="subtab-strip" data-page="X"> buttons and matching
// <div class="subtab-pane" data-page="X" data-tab="Y"> content panes.
function showSubTab(page, tab) {
  const strip = document.querySelector(`.subtab-strip[data-page="${page}"]`);
  if (!strip) return; // page has no sub-tabs (e.g. Services, VS Code)

  strip.querySelectorAll('.subtab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll(`.subtab-pane[data-page="${page}"]`).forEach(p => p.classList.toggle('active', p.dataset.tab === tab));

  document.querySelectorAll(`#sidebar .nav-item[data-page="${page}"] .nav-sub li a`).forEach(a => {
    a.classList.toggle('active', a.getAttribute('onclick')?.includes(`'${tab}'`));
  });

  subTabLoaders[`${page}:${tab}`]?.();
}

/* ── PROJECTS ── */
async function loadProjects() {
  const res = await fetch(API + 'projects.php');
  const data = await res.json();
  const projects = data.projects || [];

  document.getElementById('stat-total').textContent = projects.length;
  document.getElementById('stat-active').textContent = projects.filter(p => p.status === 'active').length;
  document.getElementById('stat-files').textContent = projects.reduce((s, p) => s + parseInt(p.file_count || 0), 0);
  document.getElementById('proj-count').textContent = projects.length;

  allProjects = projects;

  const list = document.getElementById('project-list');
  if (!projects.length) {
    list.innerHTML = `
      <div class="empty-state">
        <i class="bi bi-folder2-open"></i>
        <p>No projects yet — add one to get started</p>
      </div>`;
    return;
  }

  const statusClass = { active: 's-active', draft: 's-draft', 'on-hold': 's-on-hold' };
  list.innerHTML = projects.map((p, i) => `
    <div class="project-card" style="cursor:pointer;" onclick="openProject(${p.id})">
      <div class="p-dot" style="background:${TYPE_COLORS[i % TYPE_COLORS.length]}"></div>
      <div class="p-body">
        <div class="d-flex align-items-center gap-2 mb-1">
          <span class="p-name">${esc(p.name)} <small class="text-muted" style="font-size:11px; font-weight:normal;">(ID: ${p.id})</small></span>
          <span class="type-badge">${esc(p.type)}</span>
        </div>
        ${p.description ? `<div class="p-desc">${esc(p.description)}</div>` : ''}
        <div class="p-meta">
          <span class="status-pill ${statusClass[p.status] || 's-on-hold'}">${p.status}</span>
          <span><i class="bi bi-calendar3"></i> ${p.created_at}</span>
          ${p.country ? `<span><i class="bi bi-geo-alt"></i> ${esc(p.country)}</span>` : ''}
          ${p.payment_type ? `<span class="badge ${p.payment_type === 'paid' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'} border" style="font-size:10px;">${p.payment_type.toUpperCase()}</span>` : ''}
          ${p.project_origin ? `<span class="badge bg-info-subtle text-info border" style="font-size:10px;">${p.project_origin.toUpperCase()}</span>` : ''}
          ${p.file_count > 0 ? `<span><i class="bi bi-paperclip"></i> ${p.file_count} file${p.file_count > 1 ? 's' : ''}</span>` : ''}
          ${p.created_by ? `<span><i class="bi bi-person-circle me-1"></i><strong>${esc(p.created_by)}</strong></span>` : ''}
          <span style="margin-left:auto; display:flex; gap:4px;" onclick="event.stopPropagation()">
            <button class="btn btn-sm btn-outline-secondary" style="padding:2px 8px; font-size:11px;" onclick="openEditProject(${p.id})" title="Edit"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-outline-danger" style="padding:2px 8px; font-size:11px;" onclick="deleteProject(${p.id}, '${esc(p.name).replace(/'/g, "\\'")}')" title="Delete"><i class="bi bi-trash"></i></button>
          </span>
        </div>
      </div>
    </div>`).join('');
}

/* ── EDIT / DELETE PROJECT ── */
function openEditProject(id) {
  const p = allProjects.find(x => x.id == id);
  if (!p) return;
  document.getElementById('edit-project-id').value = p.id;
  document.getElementById('edit-project-name').value = p.name;
  document.getElementById('edit-project-type').value = p.type;
  document.getElementById('edit-project-status').value = p.status;
  document.getElementById('edit-project-payment').value = p.payment_type || 'paid';
  document.getElementById('edit-project-origin').value = p.project_origin || 'client';
  document.getElementById('edit-project-country').value = p.country || '';
  document.getElementById('edit-project-client-email').value = p.client_email || '';
  document.getElementById('edit-project-desc').value = p.description || '';
  new bootstrap.Modal(document.getElementById('editProjectModal')).show();
}

async function saveEditProject() {
  const fd = new FormData();
  fd.append('action', 'update');
  fd.append('id', document.getElementById('edit-project-id').value);
  fd.append('name', document.getElementById('edit-project-name').value.trim());
  fd.append('type', document.getElementById('edit-project-type').value.trim());
  fd.append('status', document.getElementById('edit-project-status').value);
  fd.append('payment_type', document.getElementById('edit-project-payment').value);
  fd.append('project_origin', document.getElementById('edit-project-origin').value);
  fd.append('country', document.getElementById('edit-project-country').value.trim());
  fd.append('client_email', document.getElementById('edit-project-client-email').value.trim());
  fd.append('description', document.getElementById('edit-project-desc').value.trim());

  try {
    const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      bootstrap.Modal.getInstance(document.getElementById('editProjectModal')).hide();
      showToast('Project updated');
      loadProjects();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    showToast('Failed to update project');
  }
}

async function deleteProject(id, name) {
  if (!confirm(`Delete "${name}"? This also removes its files and tasks. This cannot be undone.`)) return;
  try {
    const res = await fetch(API + `projects.php?id=${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      showToast('Project deleted');
      loadProjects();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    showToast('Failed to delete project');
  }
}

/* ── PROJECT DETAIL ── */
/* Keeps the Tasks page's project dropdown in sync with whichever project is
   currently active. Populated straight from `allProjects` — the same array
   Settings/Projects pages use — so any project added in Settings shows up
   here automatically the next time this page loads. */
function populateTasksProjectSelect() {
  const select = document.getElementById('tasks-project-select');
  if (!select || !allProjects) return;
  select.innerHTML = '<option value="">Select a project…</option>' +
    allProjects.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  if (currentProjectId) select.value = currentProjectId;
}

function onTasksProjectChange() {
  const select = document.getElementById('tasks-project-select');
  const id = select.value;
  if (!id) {
    currentProjectId = null;
    document.getElementById('task-list-pending').innerHTML = '<div class="text-center text-muted p-3">Select a project first to view tasks</div>';
    document.getElementById('task-list-completed').innerHTML = '';
    return;
  }
  const project = allProjects.find(p => p.id == id);
  currentProjectId = id;
  currentProjectName = project ? project.name : '';
  document.getElementById('detail-project-name').textContent = currentProjectName + ' Tasks';
  loadTasks();
}

function openProject(id) {
  currentProject = allProjects.find(p => p.id == id);
  if (!currentProject) return;
  currentProjectId = currentProject.id;
  currentProjectName = currentProject.name;
  switchPage('detail');
}

async function loadProjectDetail() {
  if (!currentProject) return;
  document.getElementById('detail-page-title').innerHTML = `${esc(currentProject.name)} <small class="text-muted fs-6" style="font-weight: normal;">(ID: ${currentProject.id})</small>`;
  const descEl = document.getElementById('detail-description');
  if (currentProject.description) {
    descEl.innerHTML = esc(currentProject.description).replace(/\n/g, '<br>');
  } else {
    descEl.innerHTML = '<span class="fst-italic text-muted">No description provided.</span>';
  }
  await loadDetailFiles();
  await loadDetailTasks();
  await loadDetailLinks();
  await loadPmTrackingSummary();
}

/* PM Connect automatic tracking summary — started/completed/days-taken and
   this week/month's activity, entirely derived from VS Code, no manual entry. */
async function loadPmTrackingSummary() {
  const summaryEl = document.getElementById('pm-tracking-summary');
  const completeBtn = document.getElementById('pm-complete-btn');
  if (!summaryEl || !currentProjectId) return;

  try {
    const res = await fetch(API + `pmconnect.php?action=rollup`, {
      credentials: 'same-origin',
      headers: { 'X-Project-Id': String(currentProjectId) },
    });
    const data = await res.json();
    if (!data.success) {
      summaryEl.textContent = 'No tracking data yet — not opened in VS Code.';
      return;
    }

    const p = data.project;
    window.__pmProjectCompleted = !!p.completedAt;

    if (!p.startedAt) {
      summaryEl.innerHTML = '<i class="bi bi-dot"></i> Not started yet — waiting for a developer to open this project in VS Code.';
      const tableContainer = document.getElementById('pm-activity-table-container');
      if (tableContainer) tableContainer.style.display = 'none';
    } else {
      const started = new Date(p.startedAt).toLocaleDateString();
      const ended = p.completedAt ? new Date(p.completedAt).toLocaleDateString() : 'In progress';
      summaryEl.innerHTML = `
        <strong>Started:</strong> ${started} &nbsp;|&nbsp;
        <strong>Ended:</strong> ${ended} &nbsp;|&nbsp;
        <strong>Days taken:</strong> ${p.daysTaken ?? '—'} &nbsp;|&nbsp;
        This week: ${data.week.commits} commits, ${data.week.activeMinutes}m &nbsp;|&nbsp;
        This month: ${data.month.commits} commits, ${data.month.activeMinutes}m
      `;

      const tableContainer = document.getElementById('pm-activity-table-container');
      const tbody = document.getElementById('pm-activity-table-body');
      if (tableContainer && tbody) {
        if (data.dailyBreakdown && data.dailyBreakdown.length > 0) {
          tableContainer.style.display = 'block';
          tbody.innerHTML = data.dailyBreakdown.map(d => {
            const dateVal = new Date(d.date);
            const dateStr = dateVal.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' });
            const hours = Math.floor(d.activeMinutes / 60);
            const mins = d.activeMinutes % 60;
            const timeStr = hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
            return `
              <tr>
                <td>${dateStr}</td>
                <td>${d.commits}</td>
                <td>${timeStr}</td>
              </tr>
            `;
          }).join('');
        } else {
          tableContainer.style.display = 'none';
        }
      }
    }

    if (completeBtn) {
      completeBtn.innerHTML = p.completedAt
        ? '<i class="bi bi-arrow-counterclockwise me-1"></i>Reopen'
        : '<i class="bi bi-check-circle me-1"></i>Mark Complete';
      completeBtn.classList.toggle('btn-success', !p.completedAt);
      completeBtn.classList.toggle('btn-outline-secondary', !!p.completedAt);
    }
  } catch (e) {
    summaryEl.textContent = 'Failed to load tracking data.';
    console.error('loadPmTrackingSummary failed', e);
  }
}

async function toggleProjectComplete() {
  if (!currentProjectId) return;
  const completed = !window.__pmProjectCompleted;
  try {
    const res = await fetch(API + 'pmconnect.php?action=complete', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId: currentProjectId, completed }),
    });
    const data = await res.json();
    if (data.success) {
      showToast(completed ? 'Project marked complete' : 'Project reopened');
      await loadPmTrackingSummary();
    } else {
      showToast(data.error || 'Failed to update project');
    }
  } catch (e) {
    showToast('Failed to update project');
    console.error('toggleProjectComplete failed', e);
  }
}

function openProjectReport() {
  if (!currentProjectId) return;
  window.open(`report.php?project=${currentProjectId}`, '_blank');
}

function toggleDescEdit() {
  const viewEl = document.getElementById('detail-description');
  const editEl = document.getElementById('desc-edit-mode');
  const isEditing = editEl.style.display !== 'none';
  if (isEditing) {
    editEl.style.display = 'none';
    viewEl.style.display = 'block';
  } else {
    document.getElementById('desc-textarea').value = currentProject ? (currentProject.description || '') : '';
    viewEl.style.display = 'none';
    editEl.style.display = 'block';
    document.getElementById('desc-textarea').focus();
  }
}

async function saveDescription() {
  const desc = document.getElementById('desc-textarea').value.trim();
  const fd = new FormData();
  fd.append('action', 'update_desc');
  fd.append('id', currentProjectId);
  fd.append('description', desc);
  try {
    const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      if (currentProject) currentProject.description = desc;
      const descEl = document.getElementById('detail-description');
      descEl.innerHTML = desc
        ? esc(desc).replace(/\n/g, '<br>')
        : '<span class="fst-italic text-muted">No description provided.</span>';
      toggleDescEdit();
      showToast('Description saved!');
    } else {
      showToast(data.error || 'Failed to save');
    }
  } catch (e) { showToast('Failed to save description'); }
}

async function uploadDetailFiles(files) {
  if (!files.length) return;
  showToast('Uploading...');
  for (const file of Array.from(files)) {
    const fd = new FormData();
    fd.append('project_id', currentProjectId);
    fd.append('file', file);
    try {
      await fetch(API + 'files.php', { method: 'POST', body: fd });
    } catch (e) { console.error('Upload failed:', file.name); }
  }
  document.getElementById('detail-file-input').value = '';
  await loadDetailFiles();
  showToast('Upload complete!');
}

async function loadDetailFiles() {
  try {
    const res = await fetch(API + `files.php?project_id=${currentProjectId}`);
    const data = await res.json();
    const files = data.files || [];
    const el = document.getElementById('detail-files');
    if (!files.length) {
      el.innerHTML = '<div class="text-center text-muted" style="font-size:13px; padding:20px 0;"><i class="bi bi-folder2-open d-block mb-2 fs-4"></i>No documents uploaded</div>';
      return;
    }
    el.innerHTML = files.map(f => `
      <div class="d-flex align-items-center gap-2 p-2 mb-2" style="background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
        <i class="bi ${getFileIcon(f.original_name)} text-primary fs-5"></i>
        <div class="flex-grow-1" style="min-width:0;">
          <div style="font-size:13px; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${esc(f.original_name)}">${esc(truncateName(f.original_name))}</div>
          <div style="font-size:11px; color:#94a3b8;">${formatSize(f.file_size)}</div>
        </div>
        <a href="uploads/${esc(f.stored_name)}" target="_blank" class="btn btn-sm btn-outline-secondary" style="font-size:11px; padding:2px 8px;" onclick="event.stopPropagation()">
          <i class="bi bi-download"></i>
        </a>
      </div>`).join('');
  } catch (e) {
    console.error('Failed to load files', e);
  }
}

async function loadDetailTasks() {
  if (!currentProjectId) return;
  try {
    const res = await fetch(API + `tasks.php?project_id=${currentProjectId}`);
    const data = await res.json();
    const tasks = data.tasks || [];
    const pending = tasks.filter(t => t.status !== 'done');
    const completed = tasks.filter(t => t.status === 'done');

    document.getElementById('detail-count-pending').textContent = pending.length;

    const pendingEl = document.getElementById('detail-list-pending');

    pendingEl.innerHTML = pending.length
      ? pending.map(t => `
          <div class="card border-0 shadow-sm" style="border-radius:10px;">
            <div class="card-body p-3">
              <div id="task-view-${t.id}">
                <h6 style="font-size:14px; font-weight:600; margin-bottom:3px;">${esc(t.title)}</h6>
                <p class="text-muted mb-2" style="font-size:12px;">${esc(t.description || '')}</p>
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-1">
                  <div class="d-flex gap-1 flex-wrap">
                    ${t.created_by ? `<span class="badge bg-primary-subtle text-primary border" style="font-size:10px;"><i class="bi bi-person-circle me-1"></i>${esc(t.created_by)}</span>` : ''}
                  </div>
                  <div class="d-flex gap-1">
                    <button class="btn btn-sm btn-outline-secondary" style="font-size:11px; padding:2px 8px;" onclick="toggleTaskEdit(${t.id})">
                      <i class="bi bi-pencil"></i> Update
                    </button>
                    <button class="btn btn-sm btn-success" style="font-size:11px; padding:2px 8px;" onclick="completeDetailTask(${t.id})">
                      <i class="bi bi-check-lg"></i> Done
                    </button>
                  </div>
                </div>
              </div>
              <div id="task-edit-${t.id}" style="display:none;">
                <input type="text" class="form-control form-control-sm mb-2" id="edit-title-${t.id}" value="${esc(t.title)}">
                <textarea class="form-control form-control-sm mb-2" id="edit-desc-${t.id}" rows="2" style="resize:none;">${esc(t.description || '')}</textarea>
                <div class="d-flex gap-2">
                  <button class="btn btn-primary btn-sm" style="font-size:11px;" onclick="saveTaskUpdate(${t.id})">
                    <i class="bi bi-check-lg"></i> Save
                  </button>
                  <button class="btn btn-outline-secondary btn-sm" style="font-size:11px;" onclick="toggleTaskEdit(${t.id})">Cancel</button>
                </div>
              </div>
            </div>
          </div>`).join('')
      : '<div class="text-center text-muted p-3" style="font-size:13px;">No pending tasks</div>';
  } catch (e) {
    console.error('Failed to load tasks', e);
  }
}

async function submitDetailTask() {
  if (!currentProjectId) { showToast('No project selected'); return; }
  const title = document.getElementById('detail-task-title').value.trim();
  if (!title) { showToast('Task title is required'); return; }
  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('project_id', currentProjectId);
  fd.append('title', title);
  try {
    const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      document.getElementById('detail-task-title').value = '';
      loadDetailTasks();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    showToast('Failed to assign task');
  }
}

async function completeDetailTask(id) {
  const fd = new FormData();
  fd.append('action', 'complete');
  fd.append('id', id);
  try {
    const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      showToast('Task marked as complete!');
      loadDetailTasks();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    showToast('Failed to complete task');
  }
}

function toggleTaskEdit(id) {
  const viewEl = document.getElementById('task-view-' + id);
  const editEl = document.getElementById('task-edit-' + id);
  const isEditing = editEl.style.display !== 'none';
  viewEl.style.display = isEditing ? 'block' : 'none';
  editEl.style.display = isEditing ? 'none' : 'block';
}

async function saveTaskUpdate(id) {
  const title = document.getElementById('edit-title-' + id).value.trim();
  const desc  = document.getElementById('edit-desc-'  + id).value.trim();
  if (!title) { showToast('Title is required'); return; }
  const fd = new FormData();
  fd.append('action', 'update');
  fd.append('id', id);
  fd.append('title', title);
  fd.append('description', desc);
  try {
    const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) { showToast('Task updated!'); loadDetailTasks(); }
    else showToast('Error: ' + (data.error || 'Update failed'));
  } catch (e) { showToast('Failed to update task'); }
}


async function loadDetailLinks() {
  try {
    const res = await fetch(API + `links.php?project_id=${currentProjectId}`);
    const data = await res.json();
    const links = data.links || [];
    const el = document.getElementById('detail-links-list');
    if (!links.length) {
      el.innerHTML = '<div class="text-center text-muted p-3" style="font-size:13px;">No links added</div>';
      return;
    }
    el.innerHTML = links.map(l => `
      <div class="d-flex align-items-center gap-2 p-2" style="background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0;">
        <i class="bi bi-link-45deg text-primary fs-5"></i>
        <div class="flex-grow-1" style="min-width:0;">
          <div style="font-size:13px; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${esc(l.title)}</div>
          <a href="${esc(l.url)}" target="_blank" style="font-size:11px; color:#6366f1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:block;">${esc(l.url)}</a>
        </div>
        <button class="btn btn-sm btn-outline-danger" style="font-size:11px; padding:2px 7px;" onclick="removeDetailLink(${l.id})">
          <i class="bi bi-trash"></i>
        </button>
      </div>`).join('');
  } catch (e) { console.error('Failed to load links', e); }
}

async function addDetailLink() {
  const title = document.getElementById('link-title').value.trim();
  const url   = document.getElementById('link-url').value.trim();
  if (!title || !url) { showToast('Title and URL are required'); return; }
  const fd = new FormData();
  fd.append('project_id', currentProjectId);
  fd.append('title', title);
  fd.append('url', url);
  try {
    const res = await fetch(API + 'links.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      document.getElementById('link-title').value = '';
      document.getElementById('link-url').value   = '';
      loadDetailLinks();
    } else showToast(data.error || 'Failed to add link');
  } catch (e) { showToast('Failed to add link'); }
}

async function removeDetailLink(id) {
  try {
    await fetch(API + 'links.php?id=' + id, { method: 'DELETE' });
    loadDetailLinks();
  } catch (e) { showToast('Failed to remove link'); }
}

/* ── SUBMIT PROJECT ── */
let isUploading = false;

async function submitProject() {
  if (isUploading) return;
  const name = document.getElementById('proj-name').value.trim();
  const type = document.getElementById('proj-type').value;
  const status = document.getElementById('proj-status').value;
  const country = document.getElementById('proj-country').value;
  const paymentType = document.querySelector('input[name="paymentType"]:checked').value;
  const projectOrigin = document.querySelector('input[name="projectOrigin"]:checked').value;
  const desc = document.getElementById('proj-desc').value.trim();

  if (!name) { showToast('Enter a project name'); return; }
  if (!type) { showToast('Select a project type'); return; }

  const validFiles = pendingFiles.filter(f => f.valid);
  if (pendingFiles.some(f => !f.valid)) {
    if (!confirm('Some files have errors and will be skipped. Continue?')) return;
  }

  isUploading = true;
  document.getElementById('upload-overall').style.display = 'block';
  document.getElementById('upload-overall').textContent = 'Creating project...';

  const fd = new FormData();
  
  fd.append('name', name);
  fd.append('type', type);
  fd.append('status', status);
  fd.append('payment_type', paymentType);
  fd.append('project_origin', projectOrigin);
  fd.append('country', country);
  fd.append('client_email', document.getElementById('proj-client-email').value.trim());
  fd.append('description', desc);

  try {
    const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.success) {
      if (validFiles.length > 0) {
        await uploadFilesSequential(data.id, validFiles);
      } else {
        finishUpload();
      }
    } else {
      throw new Error(data.error || 'Failed to create project');
    }
  } catch (err) {
    showToast(err.message);
    isUploading = false;
    document.getElementById('upload-overall').style.display = 'none';
  }
}

async function uploadFilesSequential(projectId, files) {
  for (let i = 0; i < files.length; i++) {
    document.getElementById('upload-overall').textContent = `Uploading ${i + 1} of ${files.length}...`;
    await uploadSingleFile(projectId, files[i]);
  }
  finishUpload();
}

function uploadSingleFile(projectId, fileObj) {
  return new Promise(resolve => {
    const xhr = new XMLHttpRequest();
    const fd = new FormData();
    fd.append('project_id', projectId);
    fd.append('file', fileObj.file);

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        fileObj.progress = Math.round((e.loaded / e.total) * 100);
        updateFileUI(fileObj.id);
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const res = JSON.parse(xhr.responseText);
          if (res.success) {
            fileObj.status = 'success';
          } else {
            fileObj.status = 'error';
            fileObj.error = res.error || 'Upload failed';
          }
        } catch (e) {
          fileObj.status = 'error';
          fileObj.error = 'Invalid response';
        }
      } else {
        fileObj.status = 'error';
        fileObj.error = `HTTP ${xhr.status}`;
      }
      fileObj.progress = 100;
      updateFileUI(fileObj.id);
      resolve();
    };

    xhr.onerror = () => {
      fileObj.status = 'error';
      fileObj.error = 'Network error';
      fileObj.progress = 100;
      updateFileUI(fileObj.id);
      resolve();
    };

    xhr.open('POST', API + 'files.php', true);
    xhr.send(fd);
  });
}

function finishUpload() {
  showToast('Project saved!');
  resetForm();
  switchPage('projects');
  isUploading = false;
  document.getElementById('upload-overall').style.display = 'none';
}

function resetForm() {
  document.getElementById('proj-name').value = '';
  document.getElementById('proj-desc').value = '';
  document.getElementById('proj-type').value = '';
  document.getElementById('proj-status').value = 'active';
  document.getElementById('proj-country').value = '';
  document.getElementById('proj-client-email').value = '';
  document.getElementById('payPaid').checked = true;
  document.getElementById('originClient').checked = true;
  pendingFiles = [];
  renderFileList();
  document.getElementById('file-input').value = '';
  document.getElementById('folder-input').value = '';
}

/* ── FILE UPLOAD ── */
function onDragOver(e) { e.preventDefault(); document.getElementById('drop-zone').classList.add('drag-over'); }
function onDragLeave() { document.getElementById('drop-zone').classList.remove('drag-over'); }
function onDrop(e) { e.preventDefault(); document.getElementById('drop-zone').classList.remove('drag-over'); handleFiles(e.dataTransfer.files); }

function handleFiles(files) {
  const disallowedExts = ['.exe', '.bat', '.sh', '.php'];
  const maxSizeBytes = 50 * 1024 * 1024;

  let hasErrors = false;

  Array.from(files).forEach(f => {
    if (!pendingFiles.find(x => x.file && x.file.name === f.name)) {
      let valid = true;
      let error = '';

      const extMatch = f.name.match(/\.[0-9a-z]+$/i);
      const ext = extMatch ? extMatch[0].toLowerCase() : '';

      if (disallowedExts.includes(ext)) {
        valid = false;
        error = 'File type not allowed';
        hasErrors = true;
      } else if (f.size > maxSizeBytes) {
        valid = false;
        error = 'File exceeds 50MB';
        hasErrors = true;
      }

      pendingFiles.push({
        id: 'file_' + Math.random().toString(36).substr(2, 9),
        file: f,
        valid: valid,
        error: error,
        progress: 0,
        status: 'pending'
      });
    }
  });

  const errDiv = document.getElementById('file-error');
  if (hasErrors) {
    errDiv.textContent = 'Some files have errors and will be skipped.';
    errDiv.style.display = 'block';
  } else {
    errDiv.style.display = 'none';
  }

  renderFileList();
}

function getFileIcon(filename) {
  const extMatch = filename.match(/\.[0-9a-z]+$/i);
  const ext = extMatch ? extMatch[0].toLowerCase() : '';
  if (['.jpg', '.jpeg', '.png', '.gif', '.svg'].includes(ext)) return 'bi-file-image';
  if (ext === '.pdf') return 'bi-file-pdf';
  if (['.zip', '.rar', '.7z'].includes(ext)) return 'bi-file-zip';
  if (['.doc', '.docx'].includes(ext)) return 'bi-file-word';
  return 'bi-file-earmark';
}

function formatSize(bytes) {
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / 1024).toFixed(1) + ' KB';
}

function truncateName(name) {
  if (name.length > 30) {
    const parts = name.split('.');
    const ext = parts.length > 1 ? '.' + parts.pop() : '';
    const base = parts.join('.');
    return base.substring(0, 26 - ext.length) + '...' + ext;
  }
  return name;
}

function renderFileList() {
  const sumDiv = document.getElementById('upload-summary');
  if (pendingFiles.length > 0) {
    const totalSize = pendingFiles.reduce((sum, f) => sum + f.file.size, 0);
    sumDiv.textContent = `${pendingFiles.length} files selected · ${formatSize(totalSize)}`;
    sumDiv.style.display = 'block';
  } else {
    sumDiv.style.display = 'none';
  }

  document.getElementById('file-list').innerHTML = pendingFiles.map((f, i) => `
    <div class="file-item ${!f.valid ? 'has-error' : ''}" id="${f.id}">
      <i class="bi ${getFileIcon(f.file.name)} file-icon"></i>
      <div class="d-flex flex-column flex-grow-1" style="min-width: 0;">
        <span class="file-name" title="${esc(f.file.name)}">${esc(truncateName(f.file.name))}</span>
        <span class="file-size">${!f.valid ? '<span class="text-danger">' + f.error + '</span>' : formatSize(f.file.size)}</span>
      </div>
      ${renderFileStatus(f, i)}
      ${f.valid ? `<div class="file-progress-container"><div class="file-progress-bar" style="width: ${f.progress}%"></div></div>` : ''}
    </div>`).join('');
}

function renderFileStatus(f, index) {
  if (f.status === 'success') return `<i class="bi bi-check-circle-fill file-status-icon success"></i>`;
  if (f.status === 'error') return `<i class="bi bi-x-circle-fill file-status-icon error" title="${esc(f.error || '')}"></i>`;
  if (isUploading) return ``;
  return `<button class="file-rm" onclick="removeFile(${index})" aria-label="Remove"><i class="bi bi-x"></i></button>`;
}

function updateFileUI(id) {
  const f = pendingFiles.find(x => x.id === id);
  if (!f) return;
  const el = document.getElementById(id);
  if (!el) return;

  const progBar = el.querySelector('.file-progress-bar');
  if (progBar) progBar.style.width = f.progress + '%';

  if (f.status === 'success' || f.status === 'error') {
    renderFileList();
  }
}

function removeFile(i) {
  pendingFiles.splice(i, 1);
  const hasErrors = pendingFiles.some(f => !f.valid);
  document.getElementById('file-error').style.display = hasErrors ? 'block' : 'none';
  renderFileList();
}

/* ── SETTINGS ── */
async function loadSettings() {
  // "Project name" list here is just `projects` — same table the Assign
  // Task dropdown reads from — so adding one here shows up there instantly.
  const res = await fetch(API + 'projects.php');
  const data = await res.json();
  renderTypeTags(data.projects || []);
  loadApiKeys();
  loadActivity();
}

const ACTIVITY_LABELS = {
  create_task: { icon: 'bi-plus-circle', label: 'created task' },
  update_status: { icon: 'bi-arrow-repeat', label: 'changed status' },
  push_progress: { icon: 'bi-graph-up', label: 'pushed progress' },
  start_timer: { icon: 'bi-play-circle', label: 'started timer' },
  stop_timer: { icon: 'bi-stop-circle', label: 'stopped timer' },
};

async function loadActivity() {
  try {
    // Session-authenticated (admin logged into the website) — no API key
    // needed here, unlike the VS Code-facing endpoints.
    const res = await fetch(API + 'pmconnect.php?action=activity', {
      credentials: 'same-origin',
    });
    const data = await res.json();
    const list = document.getElementById('activity-list');
    if (!list || !data.success) return;

    if (!data.activity.length) {
      list.innerHTML = '<div class="text-center text-muted p-3" style="font-size:13px;">No activity yet</div>';
      return;
    }

    list.innerHTML = data.activity.map(a => {
      const meta = ACTIVITY_LABELS[a.action] || { icon: 'bi-dot', label: a.action };
      return `
        <div class="d-flex align-items-start gap-2 py-2 border-bottom">
          <i class="bi ${meta.icon}" style="font-size:16px; margin-top:2px;"></i>
          <div class="flex-grow-1" style="font-size:13px;">
            <strong>${esc(a.employee)}</strong> ${meta.label}
            ${a.task_title ? `— <span class="text-muted">${esc(a.task_title)}</span>` : (a.task_id ? `— <span class="text-muted">task #${a.task_id}</span>` : '')}
            ${a.detail ? `<div class="text-muted" style="font-size:11px;">${esc(a.detail)}</div>` : ''}
          </div>
          <span class="text-muted" style="font-size:11px; white-space:nowrap;">${esc(a.created_at)}</span>
        </div>`;
    }).join('');
  } catch (e) {
    console.error("Failed to load activity", e);
  }
}

/* ── DEVELOPERS PAGE — Admin drill-down: all developers → a developer's
   real projects (only ones actually opened in VS Code) → one project's full
   detail + real GitHub commit history. Everything here comes straight from
   PM Connect's automatic tracking — no manual entry, no dummy data. ── */

function devFmtDate(iso) {
  if (!iso) return '—';
  return new Date(String(iso).replace(' ', 'T')).toLocaleDateString();
}
function devFmtMin(m) {
  if (!m) return '0m';
  const h = Math.floor(m / 60), r = m % 60;
  return h > 0 ? `${h}h ${r}m` : `${r}m`;
}

function devSetBreadcrumb(text) {
  const bc = document.getElementById('dev-breadcrumb');
  const bcText = document.getElementById('dev-breadcrumb-text');
  if (text) {
    bc.style.setProperty('display', 'flex', 'important');
    bcText.textContent = text;
  } else {
    bc.style.setProperty('display', 'none', 'important');
  }
}

// Only 2 levels now: 'directory' (developers list, projects expand inline
// via accordion — no extra click/page) -> 'detail' (one project's report).
let devHistory = [];

function devGoBack() {
  loadDeveloperDirectory();
}

async function loadDeveloperDirectory() {
  devHistory = [{ view: 'directory' }];
  devExpandedIndex = null;
  devSetBreadcrumb('');
  const content = document.getElementById('dev-content');
  content.innerHTML = '<div class="text-muted p-3">Loading…</div>';

  try {
    const res = await fetch(API + 'pmconnect.php?action=devdirectory', { credentials: 'same-origin' });
    const data = await res.json();
    if (!data.success) { content.innerHTML = '<div class="text-danger p-3">Failed to load developers.</div>'; return; }

    if (!data.developers.length) {
      content.innerHTML = '<div class="text-center text-muted p-4">No developers with API keys yet.</div>';
      return;
    }

    const avatarPalette = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6', '#14b8a6'];
    const colorFor = (name) => {
      let hash = 0;
      for (let c = 0; c < name.length; c++) hash = name.charCodeAt(c) + ((hash << 5) - hash);
      return avatarPalette[Math.abs(hash) % avatarPalette.length];
    };
    const initials = (name) => name.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();

    content.innerHTML = `
      <div class="row g-3" id="dev-card-grid">${data.developers.map((d, i) => `
        <div class="col-md-4">
          <div class="form-card h-100" id="dev-card-${i}" style="cursor:pointer; border:2px solid transparent; transition:border-color .15s, transform .15s;"
               onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'"
               onclick="toggleDeveloperProjects('${esc(d.name).replace(/'/g, "\\'")}', ${i})">
            <div class="d-flex align-items-center gap-3">
              <div style="width:44px; height:44px; border-radius:50%; background:${colorFor(d.name)}; color:#fff; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:15px; flex-shrink:0;">
                ${esc(initials(d.name))}
              </div>
              <div class="flex-grow-1" style="min-width:0;">
                <div class="d-flex align-items-center gap-2">
                  <strong style="font-size:15px;">${esc(d.name)}</strong>
                  <span class="badge bg-secondary-subtle text-secondary border" style="font-size:10px;">${esc(d.employeeId || '—')}</span>
                </div>
                <div class="text-muted" style="font-size:12px;">
                  ${d.projectsCount} project${d.projectsCount === 1 ? '' : 's'} &middot;
                  ${d.totalCommits} commits
                </div>
              </div>
              <i class="bi bi-chevron-down" id="dev-chevron-${i}" style="transition:transform .15s;"></i>
            </div>
            <div class="text-muted mt-2" style="font-size:12px;">
              <i class="bi bi-clock"></i> ${devFmtMin(d.totalActiveMinutes)} active time logged
            </div>
          </div>
        </div>
      `).join('')}</div>
      <div id="dev-expand-panel" class="mt-3"></div>
    `;
  } catch (e) {
    content.innerHTML = '<div class="text-danger p-3">Failed to load developers.</div>';
    console.error('loadDeveloperDirectory failed', e);
  }
}

let devExpandedIndex = null;

// Expands a developer's projects inline, below the card grid — no page
// navigation / extra click needed to see what they're working on.
async function toggleDeveloperProjects(employeeName, i) {
  const panel = document.getElementById('dev-expand-panel');
  const chevron = document.getElementById(`dev-chevron-${i}`);
  const card = document.getElementById(`dev-card-${i}`);

  if (devExpandedIndex !== null) {
    const prevChevron = document.getElementById(`dev-chevron-${devExpandedIndex}`);
    const prevCard = document.getElementById(`dev-card-${devExpandedIndex}`);
    if (prevChevron) prevChevron.style.transform = '';
    if (prevCard) prevCard.style.borderColor = 'transparent';
  }

  if (devExpandedIndex === i) {
    devExpandedIndex = null;
    panel.innerHTML = '';
    return;
  }

  devExpandedIndex = i;
  chevron.style.transform = 'rotate(180deg)';
  card.style.borderColor = '#6366f1';
  panel.innerHTML = '<div class="text-muted p-3">Loading projects…</div>';

  try {
    const res = await fetch(API + `pmconnect.php?action=devprojects&employee=${encodeURIComponent(employeeName)}`, { credentials: 'same-origin' });
    const data = await res.json();
    if (!data.success) { panel.innerHTML = '<div class="text-danger p-3">Failed to load projects.</div>'; return; }

    if (!data.projects.length) {
      panel.innerHTML = `<div class="form-card text-muted" style="font-size:13px;">${esc(employeeName)} hasn't opened any project in VS Code yet.</div>`;
      return;
    }

    const safeName = esc(employeeName).replace(/'/g, "\\'");
    panel.innerHTML = `
      <div class="text-muted mb-2" style="font-size:12px; text-transform:uppercase; letter-spacing:.04em;">${esc(employeeName)}'s projects</div>
      <div class="row g-3">${data.projects.map(p => {
        const isDone = !!p.project.completedAt;
        const statusColor = isDone ? '#10b981' : '#3b82f6';
        return `
        <div class="col-md-4">
          <div class="form-card h-100" style="cursor:pointer; border:1px solid #e2e8f0; transition:box-shadow .15s, transform .15s;"
               onmouseover="this.style.boxShadow='0 4px 14px rgba(0,0,0,.08)'; this.style.transform='translateY(-2px)'"
               onmouseout="this.style.boxShadow=''; this.style.transform='translateY(0)'"
               onclick="showDevProjectDetail('${safeName}', ${p.project.id})">
            <div class="d-flex align-items-start justify-content-between mb-2">
              <div class="d-flex align-items-center gap-2">
                <div style="width:34px; height:34px; border-radius:9px; background:${statusColor}1a; color:${statusColor}; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                  <i class="bi ${isDone ? 'bi-check-circle-fill' : 'bi-arrow-repeat'}" style="font-size:16px;"></i>
                </div>
                <strong style="font-size:14px;">${esc(p.project.name)}</strong>
              </div>
              <span class="badge" style="font-size:10px; background:${statusColor}1a; color:${statusColor};">${isDone ? 'Completed' : 'Active'}</span>
            </div>
            <div class="text-muted" style="font-size:11px;"><i class="bi bi-calendar3"></i> Started ${devFmtDate(p.project.startedAt)}${p.project.daysTaken != null ? ` — ${p.project.daysTaken}d` : ''}</div>
            <div class="text-muted mt-1" style="font-size:12px;"><i class="bi bi-graph-up"></i> This week: ${p.week.commits} commits, ${devFmtMin(p.week.activeMinutes)}</div>
          </div>
        </div>
      `;
      }).join('')}</div>
    `;
  } catch (e) {
    panel.innerHTML = '<div class="text-danger p-3">Failed to load projects.</div>';
    console.error('toggleDeveloperProjects failed', e);
  }
}

async function showDevProjectDetail(employeeName, projectId) {
  devHistory.push({ view: 'detail' });
  devSetBreadcrumb(`Developers / ${employeeName} / …`);
  const content = document.getElementById('dev-content');
  content.innerHTML = '<div class="text-muted p-3">Loading…</div>';

  try {
    const res = await fetch(API + `pmconnect.php?action=devprojectdetail&employee=${encodeURIComponent(employeeName)}&project=${projectId}`, { credentials: 'same-origin' });
    const data = await res.json();
    if (!data.success) { content.innerHTML = '<div class="text-danger p-3">Failed to load project detail.</div>'; return; }

    devSetBreadcrumb(`Developers / ${employeeName} / ${data.project.name}`);

    const dailyRows = (data.dailyBreakdown || []).length
      ? data.dailyBreakdown.map(d => `
          <tr>
            <td>${devFmtDate(d.date)}</td>
            <td>${d.commits}</td>
            <td>${devFmtMin(d.activeMinutes)}</td>
          </tr>`).join('')
      : '<tr><td colspan="3" class="text-muted">No activity recorded yet.</td></tr>';

    const commitRows = (data.commits || []).length
      ? data.commits.map(c => `
          <div class="d-flex align-items-start gap-2 py-2 border-bottom">
            <code style="font-size:11px; color:#94a3b8;">${esc(c.sha)}</code>
            <div class="flex-grow-1" style="font-size:13px;">${esc(c.message || '(no message)')}</div>
            <span class="text-muted" style="font-size:11px; white-space:nowrap;">${devFmtDate(c.committedAt)}</span>
          </div>`).join('')
      : '<div class="text-muted p-2">No commits pushed to this project yet via VS Code.</div>';

    // "Aug 1: worked on Home Page — 'fix navbar'" — auto-derived from real
    // commit messages + real changed files, zero manual entry.
    const summaryRows = (data.dailyWorkSummary || []).length
      ? data.dailyWorkSummary.map(d => `
          <div class="py-2 border-bottom">
            <div class="fw-semibold" style="font-size:13px;">${devFmtDate(d.date)}</div>
            ${d.areas.length ? `<div class="d-flex flex-wrap gap-1 mt-1 mb-1">${d.areas.map(a => `<span class="badge bg-primary-subtle text-primary border" style="font-size:11px;">${esc(a)}</span>`).join('')}</div>` : ''}
            ${d.files && d.files.length ? `<div class="text-muted mt-1 mb-1" style="font-size:11.5px; line-height: 1.4;"><strong>Files:</strong> ${d.files.map(f => `<code class="bg-light px-1 py-0.5 rounded border text-secondary" style="font-size:10.5px;">${esc(f)}</code>`).join(' ')}</div>` : ''}
            ${d.commitMessages.length ? `<ul class="mb-0 ps-3 text-muted mt-1" style="font-size:12px;">${d.commitMessages.map(m => `<li>${esc(m)}</li>`).join('')}</ul>` : ''}
          </div>`).join('')
      : '<div class="text-muted p-2">No daily activity yet.</div>';

    content.innerHTML = `
      ${data.project.description ? `
        <div class="form-card mb-3" style="background:var(--accent-light); border-color:var(--accent-border);">
          <i class="bi bi-info-circle me-2" style="color:var(--accent-dark);"></i><span style="font-size:13.5px; color:var(--accent-dark);">${esc(data.project.description)}</span>
        </div>` : ''}
      <div class="row g-3 mb-3">
        <div class="col-md-3"><div class="form-card"><div class="text-muted" style="font-size:11px;">STARTED</div><div class="fw-bold">${devFmtDate(data.project.startedAt)}</div></div></div>
        <div class="col-md-3"><div class="form-card"><div class="text-muted" style="font-size:11px;">COMPLETED</div><div class="fw-bold">${data.project.completedAt ? devFmtDate(data.project.completedAt) : 'In progress'}</div></div></div>
        <div class="col-md-3"><div class="form-card"><div class="text-muted" style="font-size:11px;">DAYS TAKEN</div><div class="fw-bold">${data.project.daysTaken ?? '—'}</div></div></div>
        <div class="col-md-3"><div class="form-card"><div class="text-muted" style="font-size:11px;">THIS MONTH</div><div class="fw-bold">${data.month.commits} commits, ${devFmtMin(data.month.activeMinutes)}</div></div></div>
      </div>
      <div class="row g-3">
        <div class="col-md-4">
          <div class="form-card h-100">
            <label class="form-label fw-semibold">Daily Work Summary <span class="text-muted fw-normal" style="font-size:12px;">— auto-detected</span></label>
            <div style="max-height:320px; overflow-y:auto;">${summaryRows}</div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-card h-100">
            <label class="form-label fw-semibold">Last 30 Days</label>
            <div style="max-height:320px; overflow-y:auto;">
              <table class="table table-sm mb-0" style="font-size:13px;">
                <thead><tr><th>Date</th><th>Commits</th><th>Active Time</th></tr></thead>
                <tbody>${dailyRows}</tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="form-card h-100">
            <label class="form-label fw-semibold">GitHub Commits (via PM Connect)</label>
            <div style="max-height:320px; overflow-y:auto;">${commitRows}</div>
          </div>
        </div>
      </div>
    `;
  } catch (e) {
    content.innerHTML = '<div class="text-danger p-3">Failed to load project detail.</div>';
    console.error('showDevProjectDetail failed', e);
  }
}

function renderTypeTags(projects) {
  document.getElementById('type-tags').innerHTML = projects.map((p) => `
    <span class="tag-pill">${esc(p.name)}
      <button onclick="removeType(${p.id})" aria-label="Remove ${esc(p.name)}">×</button>
    </span>`).join('');
}

async function addType() {
  const inp = document.getElementById('new-type-input');
  const val = inp.value.trim();
  if (!val) return;

  const fd = new FormData();
  fd.append('name', val);
  fd.append('type', 'General');
  fd.append('status', 'active');
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();

  if (data.success) {
    inp.value = '';
    loadSettings();
    if (allProjects) loadProjects(); // refresh the shared project list too
  } else {
    showToast(data.error || 'Failed to add project');
  }
}

async function removeType(id) {
  await fetch(API + 'projects.php?id=' + id, { method: 'DELETE' });
  loadSettings();
  if (allProjects) loadProjects();
}

/* ── Team API keys (for PM Connect / VS Code) ── */
async function loadApiKeys() {
  const res = await fetch(API + 'users.php');
  const data = await res.json();
  const list = document.getElementById('api-key-list');
  if (!list || !data.success) return;

  list.innerHTML = data.users.map(u => `
    <div class="d-flex align-items-center gap-2 mb-2">
      <span class="badge bg-secondary-subtle text-secondary border" style="min-width:64px;">${esc(u.employee_id || '—')}</span>
      <span style="min-width:100px;">${esc(u.name)}</span>
      <code class="flex-grow-1 p-2 bg-light rounded" style="font-size:12px;">${u.api_key ? esc(u.api_key) : '— no key yet —'}</code>
      ${u.api_key ? `<button class="btn btn-sm btn-outline-secondary" onclick="copyApiKey('${esc(u.api_key)}')">Copy</button>` : ''}
      <button class="btn btn-sm btn-outline-primary" onclick="generateApiKey(${u.id})">${u.api_key ? 'Regenerate' : 'Generate'}</button>
    </div>
  `).join('');
}

async function generateApiKey(userId) {
  if (!confirm('Generate a new key? Any old key for this person will stop working immediately.')) return;
  const fd = new FormData();
  fd.append('action', 'generate_key');
  fd.append('id', userId);
  const res = await fetch(API + 'users.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    showToast('API key generated — copy it and give it to the developer');
    loadApiKeys();
  } else {
    showToast(data.error || 'Failed to generate key');
  }
}

function copyApiKey(key) {
  navigator.clipboard.writeText(key);
  showToast('API key copied to clipboard');
}

async function loadTypesIntoSelect() {
  try {
    const res = await fetch(API + 'types.php');
    const data = await res.json();
    if (data.types && data.types.length > 0) {
      const sel = document.getElementById('proj-type');
      sel.innerHTML = '<option value="">Select type…</option>' +
        data.types.map(t => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('');
    }
  } catch (e) {
    console.error("Failed to fetch types:", e);
  }
}

/* ── HELPERS ── */
function esc(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

/* ── TASKS ── */
const PRIORITY_COLOR = { low: '#6B778C', medium: '#0C66E4', high: '#C9372C', urgent: '#C9372C' };
const PRIORITY_ICON = { low: 'bi-arrow-down', medium: 'bi-dash', high: 'bi-arrow-up', urgent: 'bi-exclamation-triangle-fill' };

function taskCardHtml(t) {
  const overdue = t.due_date && t.status !== 'done' && new Date(t.due_date) < new Date(new Date().toDateString());
  return `
    <div class="card border-0 shadow-sm" id="task-card-${t.id}" draggable="true"
         ondragstart="kanbanDragStart(event, ${t.id})"
         style="border-radius:10px; cursor:grab;" onclick="openTaskDetail(${t.id})">
      <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-start gap-2">
          <h6 class="card-title mb-1" style="font-size:13.5px; font-weight:600;">${esc(t.title)}</h6>
          <i class="bi ${PRIORITY_ICON[t.priority] || 'bi-dash'}" style="color:${PRIORITY_COLOR[t.priority] || '#6B778C'}; font-size:14px;" title="${esc(t.priority || 'medium')} priority"></i>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-1 mt-2">
          ${t.assignee ? `<span class="badge bg-light text-dark border" style="font-size:10px;"><i class="bi bi-person me-1"></i>${esc(t.assignee)}</span>` : ''}
          ${t.due_date ? `<span class="badge ${overdue ? '' : 'bg-light text-dark border'}" style="font-size:10px; ${overdue ? 'background:var(--status-red-bg); color:var(--status-red);' : ''}"><i class="bi bi-calendar3 me-1"></i>${esc(t.due_date)}</span>` : ''}
        </div>
      </div>
    </div>
  `;
}

async function loadTasks() {
  if (!currentProjectId) return;
  try {
    const res = await fetch(API + `tasks.php?project_id=${currentProjectId}`);
    const data = await res.json();
    const tasks = data.tasks || [];

    for (const key of ['todo', 'in_progress', 'done']) {
      const list = tasks.filter(t => t.status === key);
      document.getElementById(`task-count-${key}`).textContent = list.length;
      const el = document.getElementById(`task-list-${key}`);
      el.innerHTML = list.length
        ? list.map(taskCardHtml).join('')
        : `<div class="text-center text-muted p-3" style="font-size:12px;">No tasks</div>`;
    }
  } catch (e) {
    console.error("Failed to load tasks", e);
  }
}

/* ── KANBAN DRAG & DROP ── */
let kanbanDraggedId = null;
function kanbanDragStart(ev, id) {
  kanbanDraggedId = id;
  ev.dataTransfer.effectAllowed = 'move';
}
function kanbanDragOver(ev) {
  ev.preventDefault();
  ev.currentTarget.style.background = 'var(--accent-light)';
}
async function kanbanDrop(ev, status) {
  ev.preventDefault();
  ev.currentTarget.style.background = '';
  if (!kanbanDraggedId) return;
  const fd = new FormData();
  fd.append('action', 'updateStatus');
  fd.append('id', kanbanDraggedId);
  fd.append('status', status);
  await fetch(API + 'tasks.php', { method: 'POST', body: fd });
  kanbanDraggedId = null;
  loadTasks();
}
document.addEventListener('dragleave', (ev) => {
  if (ev.target.classList && ev.target.classList.contains('kanban-col')) ev.target.style.background = '';
});

/* ── TASK DETAIL MODAL (comments, attachments, subtasks) ── */
let currentTaskDetailId = null;

async function openTaskDetail(id) {
  currentTaskDetailId = id;
  const res = await fetch(API + `tasks.php?action=detail&id=${id}`);
  const data = await res.json();
  if (!data.success) { showToast('Failed to load task'); return; }

  const t = data.task;
  document.getElementById('td-title').textContent = t.title;

  const subtasksHtml = (data.subtasks || []).length
    ? data.subtasks.map(s => `
        <div class="d-flex align-items-center gap-2 py-1">
          <input type="checkbox" ${s.status === 'done' ? 'checked' : ''} onchange="toggleSubtask(${s.id}, this.checked)">
          <span style="font-size:13px; ${s.status === 'done' ? 'text-decoration:line-through; color:#6B778C;' : ''}">${esc(s.title)}</span>
        </div>`).join('')
    : '<div class="text-muted" style="font-size:13px;">No subtasks yet.</div>';

  const commentsHtml = (data.comments || []).length
    ? data.comments.map(c => `
        <div class="border-bottom py-2">
          <div class="d-flex justify-content-between">
            <strong style="font-size:13px;">${esc(c.author)}</strong>
            <span class="text-muted" style="font-size:11px;">${new Date(c.created_at.replace(' ', 'T')).toLocaleString()}</span>
          </div>
          <div style="font-size:13px;">${esc(c.comment)}</div>
        </div>`).join('')
    : '<div class="text-muted" style="font-size:13px;">No comments yet.</div>';

  const attachmentsHtml = (data.attachments || []).length
    ? data.attachments.map(a => `
        <a href="uploads/${esc(a.stored_name)}" target="_blank" class="d-flex align-items-center gap-2 py-1 text-decoration-none">
          <i class="bi bi-paperclip"></i><span style="font-size:13px;">${esc(a.original_name)}</span>
        </a>`).join('')
    : '<div class="text-muted" style="font-size:13px;">No attachments.</div>';

  document.getElementById('td-body').innerHTML = `
    <div class="d-flex flex-wrap gap-2 mb-3">
      <span class="badge" style="background:var(--accent-light); color:var(--accent-dark);"><i class="bi bi-person me-1"></i>${esc(t.assignee || 'Unassigned')}</span>
      <span class="badge" style="background:${PRIORITY_COLOR[t.priority]}1a; color:${PRIORITY_COLOR[t.priority]};">${esc(t.priority || 'medium')} priority</span>
      ${t.due_date ? `<span class="badge bg-light text-dark border"><i class="bi bi-calendar3 me-1"></i>Due ${esc(t.due_date)}</span>` : ''}
      <span class="badge bg-light text-dark border">${esc(t.status)}</span>
    </div>
    <p style="font-size:13.5px; color:var(--text-muted);">${esc(t.description || 'No description.')}</p>

    <hr>
    <label class="form-label fw-semibold">Subtasks</label>
    <div class="mb-2">${subtasksHtml}</div>
    <div class="d-flex gap-2 mb-3">
      <input type="text" class="form-control form-control-sm" id="td-subtask-title" placeholder="Add a subtask...">
      <button class="btn btn-sm btn-outline-primary" onclick="addSubtask()">Add</button>
    </div>

    <hr>
    <label class="form-label fw-semibold">Attachments</label>
    <div class="mb-2">${attachmentsHtml}</div>
    <input type="file" class="form-control form-control-sm mb-3" id="td-attachment-file" onchange="uploadAttachment()">

    <hr>
    <label class="form-label fw-semibold">Comments</label>
    <div class="mb-2" style="max-height:200px; overflow-y:auto;">${commentsHtml}</div>
    <div class="d-flex gap-2">
      <input type="text" class="form-control form-control-sm" id="td-comment-text" placeholder="Write a comment...">
      <button class="btn btn-sm btn-primary" onclick="addComment()">Post</button>
    </div>
  `;

  new bootstrap.Modal(document.getElementById('taskDetailModal')).show();
}

async function addSubtask() {
  const input = document.getElementById('td-subtask-title');
  const title = input.value.trim();
  if (!title || !currentTaskDetailId) return;
  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('project_id', currentProjectId);
  fd.append('title', title);
  fd.append('parent_task_id', currentTaskDetailId);
  await fetch(API + 'tasks.php', { method: 'POST', body: fd });
  input.value = '';
  openTaskDetail(currentTaskDetailId);
}

async function toggleSubtask(id, checked) {
  const fd = new FormData();
  fd.append('action', 'updateStatus');
  fd.append('id', id);
  fd.append('status', checked ? 'done' : 'todo');
  await fetch(API + 'tasks.php', { method: 'POST', body: fd });
}

async function addComment() {
  const input = document.getElementById('td-comment-text');
  const comment = input.value.trim();
  if (!comment || !currentTaskDetailId) return;
  const fd = new FormData();
  fd.append('action', 'comment');
  fd.append('task_id', currentTaskDetailId);
  fd.append('comment', comment);
  await fetch(API + 'tasks.php', { method: 'POST', body: fd });
  input.value = '';
  openTaskDetail(currentTaskDetailId);
}

async function uploadAttachment() {
  const fileInput = document.getElementById('td-attachment-file');
  if (!fileInput.files.length || !currentTaskDetailId) return;
  const fd = new FormData();
  fd.append('action', 'uploadAttachment');
  fd.append('task_id', currentTaskDetailId);
  fd.append('file', fileInput.files[0]);
  await fetch(API + 'tasks.php', { method: 'POST', body: fd });
  openTaskDetail(currentTaskDetailId);
}

async function submitTask() {
  if (!currentProjectId) {
    showToast('No project selected');
    return;
  }

  const title = document.getElementById('task-title').value.trim();
  const assignee = document.getElementById('task-assignee').value.trim();
  const desc = document.getElementById('task-desc').value.trim();
  const dueDate = document.getElementById('task-due-date').value;
  const priority = document.getElementById('task-priority').value;

  if (!title) {
    showToast('Task title is required');
    return;
  }

  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('project_id', currentProjectId);
  fd.append('title', title);
  fd.append('assignee', assignee);
  fd.append('description', desc);
  fd.append('due_date', dueDate);
  fd.append('priority', priority);

  try {
    const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      showToast('Task assigned successfully!');
      document.getElementById('task-title').value = '';
      document.getElementById('task-assignee').value = '';
      document.getElementById('task-desc').value = '';
      document.getElementById('task-due-date').value = '';
      document.getElementById('task-priority').value = 'medium';
      loadTasks();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    console.error("Failed to assign task", e);
    showToast('Failed to assign task');
  }
}

async function completeTask(id) {
  const fd = new FormData();
  fd.append('action', 'complete');
  fd.append('id', id);

  try {
    const res = await fetch(API + 'tasks.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      showToast('Task marked as complete!');
      loadTasks();
    } else {
      showToast('Error: ' + data.error);
    }
  } catch (e) {
    console.error("Failed to complete task", e);
    showToast('Failed to complete task');
  }
}

/* ── NOTIFICATIONS BELL ── */
async function loadNotificationBell() {
  try {
    const res = await fetch(API + 'tasks.php?action=allNotifications');
    const data = await res.json();
    if (!data.success) return;

    const badge = document.getElementById('notif-badge');
    if (data.unreadCount > 0) {
      badge.style.display = 'block';
      badge.textContent = data.unreadCount > 9 ? '9+' : data.unreadCount;
    } else {
      badge.style.display = 'none';
    }

    const dropdown = document.getElementById('notif-dropdown');
    dropdown.innerHTML = data.notifications.length
      ? data.notifications.map(n => `
          <div class="d-flex align-items-start gap-2 py-2 border-bottom ${n.is_read ? '' : 'bg-light'}" style="border-radius:6px; padding-left:6px;">
            <i class="bi bi-bell-fill text-primary" style="font-size:12px; margin-top:3px;"></i>
            <div class="flex-grow-1">
              <div style="font-size:12.5px;">${esc(n.message)}</div>
              <div class="text-muted" style="font-size:10.5px;">${new Date(n.created_at.replace(' ', 'T')).toLocaleString()}</div>
            </div>
          </div>`).join('')
      : '<div class="text-muted p-2" style="font-size:13px;">No notifications yet.</div>';
  } catch (e) {
    console.error('Failed to load notifications', e);
  }
}

setInterval(loadNotificationBell, 60000);
setTimeout(loadNotificationBell, 1000);

/* ── INIT ── */
checkAuth();

/* ── DASHBOARD (real data, no placeholders) ── */
let dashCharts = { progress: null, stat: null };
const STATUS_LABEL = { todo: 'To Do', in_progress: 'In Progress', done: 'Done' };
const STATUS_COLOR2 = { todo: '#6B778C', in_progress: '#946F00', done: '#1F845A' };
const AVATAR_PALETTE = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6', '#14b8a6'];

function avatarColorFor(name) {
  let hash = 0;
  for (let c = 0; c < name.length; c++) hash = name.charCodeAt(c) + ((hash << 5) - hash);
  return AVATAR_PALETTE[Math.abs(hash) % AVATAR_PALETTE.length];
}
function avatarInitials(name) {
  return name.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
}
function avatarHtml(name, size = 26) {
  return `<div class="dash-avatar" style="width:${size}px; height:${size}px; background:${avatarColorFor(name)};" title="${esc(name)}">${esc(avatarInitials(name))}</div>`;
}

// Real data only — trend (+X%) and the "peak" bar are derived from the
// actual per-period task-creation counts returned by the backend.
let dashCurrentPeriod = 'day';

function computePeriodPoints(points) {
  const counts = points.map(p => p.count);
  const maxCount = Math.max(...counts, 1);
  // Only the first bar that reaches the max gets the peak badge — ties don't
  // all light up. Trend pills only show on bars that actually have data;
  // an empty (0-count) bar has nothing meaningful to compare, so it's skipped.
  const peakIndex = counts.indexOf(maxCount);
  return points.map((p, i) => {
    const prev = counts[i - 1];
    // A percentage change is only meaningful with a non-zero baseline —
    // "0 to 1" isn't "+0%", it's undefined. In that case we still label the
    // bar automatically, just with "New" (real data: this period had zero
    // before) instead of a fabricated percentage.
    let trend = null;
    if (p.count > 0) {
      trend = prev > 0
        ? `${p.count >= prev ? '+' : ''}${Math.round((p.count - prev) / prev * 100)}%`
        : 'New';
    }
    return {
      label: p.label,
      count: p.count,
      trend,
      peak: i === peakIndex && maxCount > 0
    };
  });
}

async function switchDashboardPeriod(period) {
  dashCurrentPeriod = period;
  document.querySelectorAll('.dash-period-btn').forEach(b => b.classList.toggle('active', b.dataset.period === period));
  try {
    const res = await fetch(API + `tasks.php?action=progressByPeriod&period=${period}`);
    const data = await res.json();
    if (!data.success) return;
    renderTaskProgressChart(computePeriodPoints(data.points));
  } catch (e) {
    console.error('Failed to load task progress', e);
  }
}

async function loadDashboard() {
  switchDashboardPeriod(dashCurrentPeriod);
  try {
    const res = await fetch(API + 'tasks.php?action=stats');
    const data = await res.json();
    if (!data.success) return;

    document.getElementById('dash-stat-projects').textContent = data.totalProjects;
    document.getElementById('dash-stat-tasks').textContent = data.totalTasks;
    document.getElementById('dash-stat-developers').textContent = data.totalDevelopers;
    document.getElementById('dash-stat-commits').textContent = data.totalCommits;

    const byStatus = data.projectsByStatus || {};
    document.getElementById('dash-stat-active-projects').textContent = byStatus.active || 0;
    document.getElementById('dash-stat-projects-meta').textContent =
      `${byStatus.active || 0} active, ${byStatus['on-hold'] || 0} on hold`;

    const byTaskStatus = data.byStatus || {};
    document.getElementById('dash-stat-tasks-meta').textContent =
      `${byTaskStatus.todo || 0} to do, ${byTaskStatus.in_progress || 0} in progress`;

    document.getElementById('dash-stat-commits-meta').textContent =
      `${data.totalActiveMinutes || 0}m active time tracked`;

    // Project Statistic donut: real completed vs in-progress PROJECTS
    // (projects.completed_at set or not) — not task status.
    renderTaskStatChart(data.completionPct, data.inProgressPct, null);
    renderTaskSummary(data.recentTasks);
    renderProjectOverview(data.recentProject);
    renderTodayTasks(data.todayTasks);
  } catch (e) {
    console.error('Failed to load dashboard', e);
  }

  loadDashboardProjectsTable();
}

let dashProjectsCache = [];

async function loadDashboardProjectsTable() {
  const body = document.getElementById('dash-active-projects-body');
  if (!body) return;
  try {
    const res = await fetch(API + 'projects.php');
    const data = await res.json();
    dashProjectsCache = (data.projects || []).slice(0, 8);
    renderDashboardProjectsTable(dashProjectsCache);
  } catch (e) {
    body.innerHTML = '<tr><td colspan="6" class="text-muted text-center py-4">Failed to load projects.</td></tr>';
  }
}

const STATUS_DOT_COLOR = { active: '#15803D', 'on-hold': '#B91C1C', draft: '#B45309' };

function renderDashboardProjectsTable(projects) {
  const body = document.getElementById('dash-active-projects-body');
  if (!body) return;
  if (!projects.length) {
    body.innerHTML = '<tr><td colspan="6" class="text-muted text-center py-4">No projects match.</td></tr>';
    return;
  }
  const statusClass = { active: 's-active', draft: 's-draft', 'on-hold': 's-on-hold' };
  body.innerHTML = projects.map(p => `
    <tr onclick="openProject(${p.id})">
      <td class="ps-3">
        <div class="fw-semibold" style="color:var(--text-main);">${esc(p.name)}</div>
        <div class="text-muted" style="font-size:11px;">PRJ-${String(p.id).padStart(3, '0')}</div>
      </td>
      <td><span class="type-badge">${esc(p.type)}</span></td>
      <td>
        <span class="dash-stat-dot" style="background:${STATUS_DOT_COLOR[p.status] || '#94A3B8'}; margin-right:6px;"></span>
        <span class="status-pill ${statusClass[p.status] || 's-on-hold'}">${esc(p.status)}</span>
      </td>
      <td class="text-muted">${p.project_origin ? esc(p.project_origin) : '—'}</td>
      <td class="text-muted">${p.created_at ? new Date(p.created_at.replace(' ', 'T')).toLocaleDateString() : '—'}</td>
      <td class="pe-3">${avatarHtml(p.created_by || 'Unassigned', 24)}</td>
    </tr>`).join('');
}

function filterDashboardProjects(query) {
  const q = query.trim().toLowerCase();
  if (!q) return renderDashboardProjectsTable(dashProjectsCache);
  const filtered = dashProjectsCache.filter(p =>
    p.name.toLowerCase().includes(q) || (p.type || '').toLowerCase().includes(q)
  );
  renderDashboardProjectsTable(filtered);
}

// Draws the floating callouts above each bar — a green "+X%" trend pill on
// every bar, plus a red value badge with a connecting dot on the peak bar —
// matching the reference image's layered look.
const peakBadgePlugin = {
  id: 'peakBadge',
  afterDatasetsDraw(chart) {
    const { ctx, data } = chart;
    const points = chart.$dashPoints || [];
    const meta = chart.getDatasetMeta(0);

    points.forEach((p, i) => {
      const bar = meta.data[i];
      if (!bar) return;
      const x = bar.x;

      if (p.peak) {
        if (p.trend) {
          const pillY = bar.y - 46;
          ctx.save();
          ctx.font = 'bold 10px Inter, sans-serif';
          const textWidth = ctx.measureText(p.trend).width;
          const pillW = textWidth + 16;
          roundRect(ctx, x - pillW / 2, pillY - 10, pillW, 20, 10);
          ctx.fillStyle = '#DCFFF1';
          ctx.fill();
          ctx.fillStyle = '#1F845A';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(p.trend, x, pillY);
          ctx.restore();
        }

        const badgeY = bar.y - 22;
        ctx.save();
        ctx.beginPath();
        ctx.arc(x, badgeY, 15, 0, Math.PI * 2);
        ctx.fillStyle = '#EF4444';
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(p.count), x, badgeY);
        ctx.beginPath();
        ctx.arc(x, bar.y - 4, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#EF4444';
        ctx.fill();
        ctx.restore();
      } else if (p.trend) {
        const pillY = bar.y - 18;
        ctx.save();
        ctx.font = 'bold 10px Inter, sans-serif';
        const textWidth = ctx.measureText(p.trend).width;
        const pillW = textWidth + 16;
        roundRect(ctx, x - pillW / 2, pillY - 10, pillW, 20, 10);
        ctx.fillStyle = '#DCFFF1';
        ctx.fill();
        ctx.fillStyle = '#1F845A';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(p.trend, x, pillY);
        ctx.restore();
      }
    });
  }
};

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function renderTaskProgressChart(days) {
  const canvas = document.getElementById('taskProgressChart');
  if (!canvas) return;
  if (dashCharts.progress) dashCharts.progress.destroy();
  canvas.$dashPoints = days;
  dashCharts.progress = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: days.map(d => d.label),
      datasets: [{
        data: days.map(d => d.count),
        backgroundColor: days.map(d => d.peak ? '#0F172A' : '#E2E8F0'),
        borderRadius: 8,
        maxBarThickness: 30
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { top: 60 } },
      plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
      scales: {
        x: { grid: { display: false }, border: { display: false }, ticks: { color: '#94A3B8', font: { size: 11 } } },
        y: { grid: { color: '#E2E8F0' }, border: { display: false }, ticks: { color: '#94A3B8', font: { size: 11 }, precision: 0 } }
      }
    },
    plugins: [{
      id: 'peakBadgeBridge',
      beforeDraw(chart) { chart.$dashPoints = days; }
    }, peakBadgePlugin]
  });
}

function renderTaskStatChart(completionPct, inProgressPct, weekOverWeek) {
  const canvas = document.getElementById('taskStatChart');
  document.getElementById('dash-completion-pct').textContent = completionPct + '%';
  if (!canvas) return;
  if (dashCharts.stat) dashCharts.stat.destroy();

  const ctx2d = canvas.getContext('2d');
  const gradient = ctx2d.createLinearGradient(0, 0, 140, 140);
  gradient.addColorStop(0, '#4F46E5');
  gradient.addColorStop(1, '#818CF8');

  dashCharts.stat = new Chart(canvas, {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [completionPct, 100 - completionPct],
        backgroundColor: [gradient, '#CBD5E1'],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '76%',
      plugins: { legend: { display: false }, tooltip: { enabled: false } }
    }
  });

  document.getElementById('dash-status-legend').innerHTML = `
    <div class="text-center">
      <div class="fw-bold" style="font-size:14px; color:#0F172A;">${completionPct}%</div>
      <div class="text-muted d-flex align-items-center justify-content-center gap-1" style="font-size:10px;">
        <span style="width:7px; height:7px; border-radius:50%; background:#EF4444; display:inline-block;"></span>Completed
      </div>
    </div>
    <div class="text-center">
      <div class="fw-bold" style="font-size:14px; color:#0F172A;">${inProgressPct}%</div>
      <div class="text-muted d-flex align-items-center justify-content-center gap-1" style="font-size:10px;">
        <span style="width:7px; height:7px; border-radius:50%; background:#CBD5E1; display:inline-block;"></span>In Progress
      </div>
    </div>
  `;

  const capEl = document.getElementById('dash-week-caption');
  if (capEl) capEl.textContent = '';
}

const PRIORITY_FIDELITY_CLASS = { low: 'is-low', medium: 'is-med', high: '', urgent: '' };
const STATUS_PILL_CLASS = { todo: '', in_progress: '', done: 'is-done' };

function renderTaskSummary(tasks) {
  const el = document.getElementById('dash-task-summary');
  if (!el) return;
  el.innerHTML = tasks.length ? tasks.map(t => {
    const pct = t.status === 'done' ? 100 : t.status === 'in_progress' ? 50 : (t.subtask_total > 0 ? Math.round(t.subtask_done / t.subtask_total * 100) : 0);
    return `
      <div class="col-md-3">
        <div class="dash-task-card" style="cursor:pointer;" onclick="switchPage('tasks')">
          <div class="d-flex gap-1 mb-2 flex-wrap">
            <span class="dash-pill dash-pill-status ${STATUS_PILL_CLASS[t.status]}">${STATUS_LABEL[t.status]}</span>
            ${t.priority ? `<span class="dash-pill dash-fidelity-badge ${PRIORITY_FIDELITY_CLASS[t.priority] || ''}">${esc(t.priority)}</span>` : ''}
          </div>
          <div class="fw-semibold mb-1" style="font-size:13px; color:#0F172A;">${esc(t.title)}</div>
          <div style="font-size:11px; color:#94A3B8;" class="mb-2">${esc(t.project_name)}</div>
          <div class="dash-progress-track mb-2"><div class="dash-progress-fill" style="width:${pct}%;"></div></div>
          <div class="d-flex justify-content-between align-items-center">
            <span style="font-size:11px; color:#94A3B8;"><i class="bi bi-chat-left-text me-1"></i>${t.comment_count}</span>
            ${t.assignee ? avatarHtml(t.assignee, 22) : ''}
          </div>
        </div>
      </div>`;
  }).join('') : '<div class="text-muted p-2" style="font-size:13px;">No tasks yet — create one to see it here.</div>';
}

function renderProjectOverview(project) {
  const el = document.getElementById('dash-project-overview');
  if (!el) return;
  if (!project) {
    el.innerHTML = '<div class="text-muted p-2" style="font-size:13px;">No projects yet.</div>';
    return;
  }
  const contributors = project.contributors || [];
  el.innerHTML = `
    <div class="d-flex justify-content-between align-items-start mb-3">
      <div class="dash-overview-icon"><i class="bi bi-kanban"></i></div>
      <span class="dash-pill dash-fidelity-badge">${esc(project.status)}</span>
    </div>
    <div class="fw-bold mb-1" style="font-size:17px; color:#0F172A; cursor:pointer;" onclick="openProject(${project.id})">${esc(project.name)}</div>
    <div style="font-size:12.5px; color:#94A3B8;" class="mb-3">${esc(project.description || 'No description yet.')}</div>
    <div class="d-flex flex-column gap-3" style="font-size:12.5px;">
      <div class="d-flex justify-content-between align-items-center">
        <span style="color:#94A3B8;"><i class="bi bi-arrow-repeat me-1"></i>Status</span>
        <span class="dash-pill dash-pill-status">${esc(project.status)}</span>
      </div>
      <div class="d-flex justify-content-between align-items-center">
        <span style="color:#94A3B8;"><i class="bi bi-person-circle me-1"></i>Created by</span>
        ${avatarHtml(project.created_by || 'Unassigned', 24)}
      </div>
      <div class="d-flex justify-content-between align-items-center">
        <span style="color:#94A3B8;"><i class="bi bi-calendar3 me-1"></i>Timeline</span>
        <strong style="color:#0F172A;">${project.started_at ? new Date(project.started_at.replace(' ', 'T')).toLocaleDateString() : '—'}</strong>
      </div>
      ${contributors.length ? `
      <div class="d-flex justify-content-between align-items-center">
        <span style="color:#94A3B8;"><i class="bi bi-people me-1"></i>Team</span>
        <div class="dash-avatar-stack">${contributors.map(name => avatarHtml(name, 24)).join('')}</div>
      </div>` : ''}
    </div>
  `;
}

function renderTodayTasks(tasks) {
  const el = document.getElementById('dash-today-tasks');
  if (!el) return;
  const countEl = document.getElementById('dash-today-count');
  if (countEl) countEl.textContent = tasks.length;
  el.innerHTML = tasks.length ? tasks.map((t, i) => `
      <div class="d-flex align-items-center gap-2 py-2 border-bottom">
        <span class="dash-today-dot" style="background:${i < 2 ? '#EF4444' : 'transparent'}; ${i >= 2 ? 'border:2px solid #CBD5E1;' : ''} border-radius:${i < 2 ? '3px' : '50%'};"></span>
        <div class="flex-grow-1" style="font-size:13px; color:#0F172A;">
          ${esc(t.title)}
          <div class="text-muted" style="font-size:10.5px;">${esc(t.project_name)}${t.assignee ? ' · ' + esc(t.assignee) : ''}</div>
        </div>
      </div>`).join('') : '<div class="text-muted p-2" style="font-size:13px;">Nothing due today.</div>';
}

/* ── PEOPLE ── */
async function loadPeople() {
  const body = document.getElementById('people-table-body');
  try {
    const res = await fetch(API + 'users.php');
    const data = await res.json();
    const users = data.users || [];
    if (!users.length) {
      body.innerHTML = '<tr><td colspan="5" class="text-muted text-center py-4">No people yet.</td></tr>';
      return;
    }
    body.innerHTML = users.map(u => `
      <tr>
        <td class="ps-3 d-flex align-items-center gap-2 py-2">${avatarHtml(u.name, 26)}<span class="fw-semibold">${esc(u.name)}</span></td>
        <td class="text-muted">${esc(u.email || '—')}</td>
        <td><span class="type-badge text-capitalize">${esc(u.role || 'developer')}</span></td>
        <td class="text-muted">${esc(u.employee_id || '—')}</td>
        <td class="pe-3">${u.api_key
          ? '<span class="status-pill s-active">Connected</span>'
          : '<span class="status-pill s-on-hold">Not connected</span>'}</td>
      </tr>`).join('');
  } catch (e) {
    body.innerHTML = '<tr><td colspan="5" class="text-danger text-center py-4">Failed to load people.</td></tr>';
  }
}

/* ── SKILLS MATRIX ── */
const SKILL_LEVELS = ['none', 'beginner', 'intermediate', 'advanced', 'expert'];
const SKILL_LEVEL_COLOR = { none: '#E2E8F0', beginner: '#F59E0B', intermediate: '#3B82F6', advanced: '#6366F1', expert: '#15803D' };

async function loadSkillsMatrix() {
  const table = document.getElementById('skills-matrix-table');
  try {
    const res = await fetch(API + 'skills.php?action=matrix');
    const data = await res.json();
    const { users, skills, levels } = data;

    if (!skills.length) {
      table.querySelector('tbody').innerHTML = '<tr><td class="text-muted text-center py-4">No skills added yet — add one above.</td></tr>';
      table.querySelector('thead').innerHTML = '<tr><th class="ps-3 text-muted" style="font-size:10.5px; text-transform:uppercase;">Member</th></tr>';
      return;
    }

    table.querySelector('thead').innerHTML = `
      <tr>
        <th class="ps-3 text-muted" style="font-size:10.5px; text-transform:uppercase;">Member</th>
        ${skills.map(s => `<th class="text-muted" style="font-size:10.5px; text-transform:uppercase;">${esc(s.name)}</th>`).join('')}
      </tr>`;

    table.querySelector('tbody').innerHTML = !users.length
      ? '<tr><td class="text-muted text-center py-4">No people yet.</td></tr>'
      : users.map(u => `
        <tr>
          <td class="ps-3 d-flex align-items-center gap-2 py-2">${avatarHtml(u.name, 24)}<span>${esc(u.name)}</span></td>
          ${skills.map(s => {
            const level = (levels[u.id] && levels[u.id][s.id]) || 'none';
            return `<td>
              <select class="form-select form-select-sm" style="width:120px; border-color:${SKILL_LEVEL_COLOR[level]};"
                      onchange="setSkillLevel(${u.id}, ${s.id}, this.value)">
                ${SKILL_LEVELS.map(l => `<option value="${l}" ${l === level ? 'selected' : ''}>${l}</option>`).join('')}
              </select>
            </td>`;
          }).join('')}
        </tr>`).join('');
  } catch (e) {
    table.querySelector('tbody').innerHTML = '<tr><td class="text-danger text-center py-4">Failed to load skills matrix.</td></tr>';
  }
}

async function addSkill() {
  const input = document.getElementById('new-skill-name');
  const name = input.value.trim();
  if (!name) return;
  const fd = new FormData();
  fd.append('action', 'addSkill');
  fd.append('name', name);
  const res = await fetch(API + 'skills.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    input.value = '';
    showToast(`Skill "${name}" added`);
    loadSkillsMatrix();
  } else {
    showToast(data.error || 'Failed to add skill');
  }
}

async function setSkillLevel(userId, skillId, level) {
  const fd = new FormData();
  fd.append('action', 'setLevel');
  fd.append('user_id', userId);
  fd.append('skill_id', skillId);
  fd.append('level', level);
  const res = await fetch(API + 'skills.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (!data.success) showToast(data.error || 'Failed to update level');
}

/* ── R&D LOG ── */
const RND_STATUS_CLASS = { open: 's-draft', in_progress: 's-on-hold', resolved: 's-active' };
const RND_PRIORITY_COLOR = { low: '#6B778C', medium: '#0C66E4', high: '#C9372C' };

async function loadRnd() {
  const body = document.getElementById('rnd-table-body');
  populateRndProjectSelect();
  try {
    const res = await fetch(API + 'rnd.php');
    const data = await res.json();
    const entries = data.entries || [];
    if (!entries.length) {
      body.innerHTML = '<tr><td colspan="7" class="text-muted text-center py-4">No R&D entries yet — add one.</td></tr>';
      return;
    }
    body.innerHTML = entries.map(r => `
      <tr>
        <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(r.question)}</td>
        <td class="text-muted">${esc(r.project_name || '—')}</td>
        <td><span class="type-badge">${esc(r.category)}</span></td>
        <td style="color:${RND_PRIORITY_COLOR[r.priority] || '#6B778C'}; font-weight:600; text-transform:capitalize;">${esc(r.priority)}</td>
        <td>
          <select class="form-select form-select-sm status-pill ${RND_STATUS_CLASS[r.status]}" style="width:120px; border:none;" onchange="updateRndStatus(${r.id}, this.value)">
            <option value="open" ${r.status === 'open' ? 'selected' : ''}>Open</option>
            <option value="in_progress" ${r.status === 'in_progress' ? 'selected' : ''}>In Progress</option>
            <option value="resolved" ${r.status === 'resolved' ? 'selected' : ''}>Resolved</option>
          </select>
        </td>
        <td class="text-muted">${esc(r.owner || '—')}</td>
        <td class="pe-3 text-muted">${esc(r.created_at)}</td>
      </tr>`).join('');
  } catch (e) {
    body.innerHTML = '<tr><td colspan="7" class="text-danger text-center py-4">Failed to load R&D log.</td></tr>';
  }
}

function populateRndProjectSelect() {
  const sel = document.getElementById('rnd-project');
  if (!sel || sel.dataset.filled) return;
  sel.dataset.filled = '1';
  fetch(API + 'projects.php').then(r => r.json()).then(data => {
    (data.projects || []).forEach(p => {
      sel.insertAdjacentHTML('beforeend', `<option value="${p.id}">${esc(p.name)}</option>`);
    });
  });
}

async function createRndEntry() {
  const question = document.getElementById('rnd-question').value.trim();
  if (!question) { showToast('Research question is required'); return; }

  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('question', question);
  fd.append('project_id', document.getElementById('rnd-project').value);
  fd.append('category', document.getElementById('rnd-category').value);
  fd.append('priority', document.getElementById('rnd-priority').value);
  fd.append('owner', document.getElementById('rnd-owner').value.trim());

  const res = await fetch(API + 'rnd.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    bootstrap.Modal.getInstance(document.getElementById('rndModal')).hide();
    document.getElementById('rnd-question').value = '';
    document.getElementById('rnd-owner').value = '';
    showToast('R&D entry added');
    loadRnd();
  } else {
    showToast(data.error || 'Failed to save entry');
  }
}

async function updateRndStatus(id, status) {
  const fd = new FormData();
  fd.append('action', 'updateStatus');
  fd.append('id', id);
  fd.append('status', status);
  const res = await fetch(API + 'rnd.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (!data.success) showToast(data.error || 'Failed to update status');
}

/* ── BILLING ── */
const INVOICE_STATUS_CLASS = { not_raised: 's-on-hold', sent: 's-draft', paid: 's-active', overdue: 's-on-hold' };
const INVOICE_STATUS_LABEL = { not_raised: 'Not raised', sent: 'Sent', paid: 'Paid', overdue: 'Overdue' };

function formatMoney(n) {
  return '$' + Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 });
}

async function loadBilling() {
  const body = document.getElementById('billing-table-body');
  populateInvoiceProjectSelect();
  try {
    const res = await fetch(API + 'billing.php');
    const data = await res.json();
    const invoices = data.invoices || [];
    const totals = data.totals || { outstanding: 0, overdue: 0, invoicedThisMonth: 0 };

    document.getElementById('bill-stat-outstanding').textContent = formatMoney(totals.outstanding);
    document.getElementById('bill-stat-overdue').textContent = formatMoney(totals.overdue);
    document.getElementById('bill-stat-month').textContent = formatMoney(totals.invoicedThisMonth);

    if (!invoices.length) {
      body.innerHTML = '<tr><td colspan="6" class="text-muted text-center py-4">No invoices yet — raise one.</td></tr>';
      return;
    }
    body.innerHTML = invoices.map(i => `
      <tr>
        <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(i.project_name)}</td>
        <td class="text-muted">${esc(i.client || '—')}</td>
        <td class="text-muted">${esc(i.milestone || '—')}</td>
        <td class="fw-semibold">${formatMoney(i.amount)}</td>
        <td class="text-muted">${esc(i.due_date_fmt || '—')}</td>
        <td class="pe-3">
          <select class="form-select form-select-sm status-pill ${INVOICE_STATUS_CLASS[i.status]}" style="width:130px; border:none;" onchange="updateInvoiceStatus(${i.id}, this.value)">
            ${Object.keys(INVOICE_STATUS_LABEL).map(s => `<option value="${s}" ${s === i.status ? 'selected' : ''}>${INVOICE_STATUS_LABEL[s]}</option>`).join('')}
          </select>
        </td>
      </tr>`).join('');
  } catch (e) {
    body.innerHTML = '<tr><td colspan="6" class="text-danger text-center py-4">Failed to load billing.</td></tr>';
  }
}

function populateInvoiceProjectSelect() {
  const sel = document.getElementById('inv-project');
  if (!sel || sel.dataset.filled) return;
  sel.dataset.filled = '1';
  fetch(API + 'projects.php').then(r => r.json()).then(data => {
    (data.projects || []).forEach(p => {
      sel.insertAdjacentHTML('beforeend', `<option value="${p.id}">${esc(p.name)}</option>`);
    });
  });
}

async function createInvoice() {
  const projectId = document.getElementById('inv-project').value;
  const amount = document.getElementById('inv-amount').value;
  if (!projectId || !amount || Number(amount) <= 0) { showToast('Project and a positive amount are required'); return; }

  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('project_id', projectId);
  fd.append('client', document.getElementById('inv-client').value.trim());
  fd.append('milestone', document.getElementById('inv-milestone').value.trim());
  fd.append('amount', amount);
  fd.append('due_date', document.getElementById('inv-due').value);

  const res = await fetch(API + 'billing.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    bootstrap.Modal.getInstance(document.getElementById('invoiceModal')).hide();
    ['inv-client', 'inv-milestone', 'inv-amount', 'inv-due'].forEach(id => document.getElementById(id).value = '');
    showToast('Invoice raised');
    loadBilling();
  } else {
    showToast(data.error || 'Failed to raise invoice');
  }
}

/* ── ESTIMATIONS ── */
const EST_STATUS_CLASS = { new_inquiry: 's-draft', queue: 's-on-hold', pipeline: 's-draft', won: 's-active', lost: 's-on-hold' };
const EST_STATUS_LABEL = { new_inquiry: 'New Inquiry', queue: 'Queue', pipeline: 'Pipeline', won: 'Won', lost: 'Lost' };

let estimationsCache = [];
let estimationsCurrentTab = 'new_inquiry';

async function loadEstimations() {
  const statsEl = document.getElementById('est-stats');
  try {
    const res = await fetch(API + 'estimations.php');
    const data = await res.json();
    estimationsCache = data.estimations || [];
    const by = data.byStatus || {};

    statsEl.innerHTML = ['new_inquiry', 'queue', 'pipeline', 'won'].map(s => `
      <div class="col-md-3">
        <div class="stat-card">
          <div class="stat-label"><span class="dash-stat-dot" style="background:#4F46E5;"></span> ${EST_STATUS_LABEL[s]}</div>
          <div class="stat-value">${by[s] || 0}</div>
        </div>
      </div>`).join('');

    renderEstimationsTable(estimationsCurrentTab);
  } catch (e) {
    document.getElementById('est-table-body').innerHTML = '<tr><td colspan="4" class="text-danger text-center py-4">Failed to load estimations.</td></tr>';
  }
}

function renderEstimationsTable(statusFilter) {
  estimationsCurrentTab = statusFilter;
  const body = document.getElementById('est-table-body');
  const rows = estimationsCache.filter(e => e.status === statusFilter);

  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="4" class="text-muted text-center py-4">No estimations in ${EST_STATUS_LABEL[statusFilter]}.</td></tr>`;
    return;
  }
  body.innerHTML = rows.map(e => `
    <tr>
      <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(e.title)}</td>
      <td class="text-muted">${esc(e.client || '—')}</td>
      <td class="fw-semibold">${formatMoney(e.estimated_value)}</td>
      <td class="pe-3">
        <select class="form-select form-select-sm status-pill ${EST_STATUS_CLASS[e.status]}" style="width:130px; border:none;" onchange="updateEstimationStatus(${e.id}, this.value)">
          ${Object.keys(EST_STATUS_LABEL).map(s => `<option value="${s}" ${s === e.status ? 'selected' : ''}>${EST_STATUS_LABEL[s]}</option>`).join('')}
        </select>
      </td>
    </tr>`).join('');
}

async function createEstimation() {
  const title = document.getElementById('est-title').value.trim();
  if (!title) { showToast('Title is required'); return; }
  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('title', title);
  fd.append('client', document.getElementById('est-client').value.trim());
  fd.append('estimated_value', document.getElementById('est-value').value || 0);
  fd.append('notes', document.getElementById('est-notes').value.trim());
  const res = await fetch(API + 'estimations.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    bootstrap.Modal.getInstance(document.getElementById('estModal')).hide();
    ['est-title', 'est-client', 'est-value', 'est-notes'].forEach(id => document.getElementById(id).value = '');
    showToast('Estimation added');
    loadEstimations();
  } else {
    showToast(data.error || 'Failed to save');
  }
}

async function updateEstimationStatus(id, status) {
  const fd = new FormData();
  fd.append('action', 'updateStatus');
  fd.append('id', id);
  fd.append('status', status);
  const res = await fetch(API + 'estimations.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (!data.success) showToast(data.error || 'Failed to update status');
  loadEstimations();
}

/* ── CAPACITY ── */
async function loadCapacity() {
  const body = document.getElementById('capacity-table-body');
  try {
    const res = await fetch(API + 'capacity.php');
    const data = await res.json();
    const rows = data.capacity || [];
    if (!rows.length) {
      body.innerHTML = '<tr><td colspan="4" class="text-muted text-center py-4">No people yet.</td></tr>';
      return;
    }
    body.innerHTML = rows.map(u => {
      const loadPct = Math.min(100, Math.round((u.active_tasks / 8) * 100)); // rough visual only, not a real hour-based %
      return `
      <tr>
        <td class="ps-3 d-flex align-items-center gap-2 py-2">${avatarHtml(u.name, 24)}<span>${esc(u.name)}</span></td>
        <td>
          <input type="number" min="1" class="form-control form-control-sm" style="width:90px;" value="${u.weekly_capacity_hours}"
                 onchange="setCapacityHours(${u.id}, this.value)">h / week
        </td>
        <td>${u.active_tasks}</td>
        <td class="pe-3" style="width:160px;">
          <div class="dash-progress-track"><div class="dash-progress-fill" style="width:${loadPct}%;"></div></div>
        </td>
      </tr>`;
    }).join('');
  } catch (e) {
    body.innerHTML = '<tr><td colspan="4" class="text-danger text-center py-4">Failed to load capacity.</td></tr>';
  }
}

async function setCapacityHours(id, hours) {
  const fd = new FormData();
  fd.append('action', 'setCapacity');
  fd.append('id', id);
  fd.append('weekly_capacity_hours', hours);
  const res = await fetch(API + 'capacity.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) showToast('Capacity updated'); else showToast(data.error || 'Failed to update');
}

/* ── INTERNS ── */
async function loadInterns() {
  const statsEl = document.getElementById('intern-stats');
  const queueBody = document.getElementById('intern-queue-body');
  const cardsEl = document.getElementById('intern-cards');
  const selectEl = document.getElementById('intern-user-select');

  try {
    const [internRes, usersRes] = await Promise.all([
      fetch(API + 'interns.php').then(r => r.json()),
      fetch(API + 'users.php').then(r => r.json()),
    ]);
    const interns = internRes.interns || [];
    const queue = internRes.queue || [];
    const allUsers = usersRes.users || [];

    const active = interns.length;
    const awaiting = interns.reduce((s, i) => s + Number(i.awaiting || 0), 0);
    const inProgress = interns.reduce((s, i) => s + Number(i.in_progress || 0), 0);

    statsEl.innerHTML = `
      <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#15803D;"></span> Active Interns</div><div class="stat-value">${active}</div></div></div>
      <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#B45309;"></span> Awaiting Assignment</div><div class="stat-value">${awaiting}</div></div></div>
      <div class="col-md-4"><div class="stat-card"><div class="stat-label"><span class="dash-stat-dot" style="background:#4F46E5;"></span> In Progress</div><div class="stat-value">${inProgress}</div></div></div>
    `;

    queueBody.innerHTML = queue.length ? queue.map(t => `
      <tr>
        <td class="ps-3">${esc(t.title)}</td>
        <td class="text-muted">${esc(t.project_name)}</td>
        <td style="color:${RND_PRIORITY_COLOR[t.priority] || '#6B778C'}; text-transform:capitalize;">${esc(t.priority)}</td>
        <td class="text-muted">${t.due_date || '—'}</td>
        <td class="pe-3">${esc(t.assignee)}</td>
      </tr>`).join('') : '<tr><td colspan="5" class="text-muted text-center py-4">No tasks assigned to interns yet.</td></tr>';

    cardsEl.innerHTML = interns.length ? interns.map(i => `
      <div class="d-flex align-items-center gap-2 py-2 border-bottom">
        ${avatarHtml(i.name, 28)}
        <div class="flex-grow-1">
          <div style="font-size:13px; font-weight:600;">${esc(i.name)}</div>
          <div class="text-muted" style="font-size:11px;">${i.active_tasks} active task${i.active_tasks == 1 ? '' : 's'}</div>
        </div>
      </div>`).join('') : '<div class="text-muted" style="font-size:13px;">No interns yet.</div>';

    const internIds = new Set(interns.map(i => i.id));
    selectEl.innerHTML = allUsers.filter(u => !internIds.has(u.id)).map(u => `<option value="${u.id}">${esc(u.name)}</option>`).join('')
      || '<option value="">Everyone is already an intern</option>';
  } catch (e) {
    queueBody.innerHTML = '<tr><td colspan="5" class="text-danger text-center py-4">Failed to load interns.</td></tr>';
  }
}

async function markAsIntern() {
  const id = document.getElementById('intern-user-select').value;
  if (!id) return;
  const fd = new FormData();
  fd.append('action', 'setIntern');
  fd.append('id', id);
  fd.append('is_intern', '1');
  const res = await fetch(API + 'interns.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Added to interns'); loadInterns(); } else showToast(data.error || 'Failed');
}

/* ── TIME & COST ── */
function formatSeconds(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

async function loadTimeCost() {
  const trackedBody = document.getElementById('timecost-tracked-body');
  const manualBody = document.getElementById('timecost-manual-body');
  try {
    const res = await fetch(API + 'timecost.php');
    const data = await res.json();
    const tracked = data.tracked || [];
    const manual = data.manual || [];

    trackedBody.innerHTML = tracked.length ? tracked.map(t => `
      <tr>
        <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(t.project_name)}</td>
        <td>${formatSeconds(t.active_seconds)}</td>
        <td class="pe-3">${t.commits}</td>
      </tr>`).join('') : '<tr><td colspan="3" class="text-muted text-center py-4">No VS Code activity tracked yet.</td></tr>';

    manualBody.innerHTML = manual.length ? manual.map(m => `
      <tr>
        <td class="ps-3">${esc(m.employee)}</td>
        <td>${esc(m.task_title)}</td>
        <td class="text-muted">${esc(m.project_name)}</td>
        <td class="pe-3">${m.minutes}m</td>
      </tr>`).join('') : '<tr><td colspan="4" class="text-muted text-center py-4">No manual time logs yet.</td></tr>';
  } catch (e) {
    trackedBody.innerHTML = '<tr><td colspan="3" class="text-danger text-center py-4">Failed to load.</td></tr>';
  }
}

/* ── SERVICES ── */
async function loadServices() {
  const grid = document.getElementById('services-grid');
  try {
    const res = await fetch(API + 'services.php');
    const data = await res.json();
    const services = data.services || [];
    grid.innerHTML = services.length ? services.map(s => `
      <div class="col-md-4">
        <div class="form-card h-100 p-3">
          <div class="d-flex justify-content-between align-items-start">
            <div class="fw-bold" style="font-size:15px;">${esc(s.name)}</div>
            <button class="btn btn-sm btn-outline-danger" style="padding:2px 8px; font-size:11px;" onclick="deleteService(${s.id})"><i class="bi bi-trash"></i></button>
          </div>
          <div class="text-muted mb-2" style="font-size:12.5px;">${esc(s.description || 'No description.')}</div>
          <div class="fw-semibold" style="color:var(--accent);">${formatMoney(s.price)}</div>
        </div>
      </div>`).join('') : '<div class="col-12"><div class="empty-state"><i class="bi bi-tools"></i><p>No services yet — add one above.</p></div></div>';
  } catch (e) {
    grid.innerHTML = '<div class="col-12 text-danger text-center py-4">Failed to load services.</div>';
  }
}

async function addService() {
  const name = document.getElementById('svc-name').value.trim();
  if (!name) { showToast('Name is required'); return; }
  const fd = new FormData();
  fd.append('action', 'create');
  fd.append('name', name);
  fd.append('description', document.getElementById('svc-desc').value.trim());
  fd.append('price', document.getElementById('svc-price').value || 0);
  const res = await fetch(API + 'services.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) {
    ['svc-name', 'svc-desc', 'svc-price'].forEach(id => document.getElementById(id).value = '');
    showToast('Service added');
    loadServices();
  } else {
    showToast(data.error || 'Failed to add service');
  }
}

async function deleteService(id) {
  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id', id);
  const res = await fetch(API + 'services.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Service removed'); loadServices(); } else showToast(data.error || 'Failed');
}

/* ── LIFECYCLE ── */
const LIFECYCLE_PHASES = [
  { key: 'initiation', label: 'Initiation' }, { key: 'planning', label: 'Planning' },
  { key: 'execution', label: 'Execution' }, { key: 'review', label: 'Review' },
  { key: 'closure', label: 'Closure' }, { key: 'post_sale', label: 'Post-Sale' },
];

let currentLifecycleProjectId = null;
let lifecycleProjectsCache = [];

async function loadLifecycleProjectSelect() {
  const sel = document.getElementById('lifecycle-project-select');
  const res = await fetch(API + 'projects.php');
  const data = await res.json();
  lifecycleProjectsCache = data.projects || [];
  sel.innerHTML = '<option value="">Select a project…</option>' + lifecycleProjectsCache.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  if (lifecycleProjectsCache.length) { sel.value = lifecycleProjectsCache[0].id; onLifecycleProjectChange(lifecycleProjectsCache[0].id); }
}

function onLifecycleProjectChange(projectId) {
  currentLifecycleProjectId = projectId;
  loadLifecycle(projectId);
  const project = lifecycleProjectsCache.find(p => String(p.id) === String(projectId));
  document.getElementById('closure-notes').value = project?.closure_notes || '';
  document.getElementById('case-study-text').value = project?.case_study || '';
}

async function saveClosureNotes() {
  if (!currentLifecycleProjectId) { showToast('Select a project first'); return; }
  const fd = new FormData();
  fd.append('action', 'setClosureNotes');
  fd.append('id', currentLifecycleProjectId);
  fd.append('closure_notes', document.getElementById('closure-notes').value);
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) showToast('Closure notes saved'); else showToast(data.error || 'Failed to save');
}

async function generateCaseStudyDraft() {
  if (!currentLifecycleProjectId) { showToast('Select a project first'); return; }
  const fd = new FormData();
  fd.append('action', 'generateCaseStudy');
  fd.append('id', currentLifecycleProjectId);
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) document.getElementById('case-study-text').value = data.draft;
  else showToast(data.error || 'Failed to generate draft');
}

async function saveCaseStudy() {
  if (!currentLifecycleProjectId) { showToast('Select a project first'); return; }
  const fd = new FormData();
  fd.append('action', 'setCaseStudy');
  fd.append('id', currentLifecycleProjectId);
  fd.append('case_study', document.getElementById('case-study-text').value);
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) showToast('Case study saved'); else showToast(data.error || 'Failed to save');
}

async function loadLifecycle(projectId) {
  const body = document.getElementById('lifecycle-body');
  if (!projectId) { body.innerHTML = '<div class="text-muted text-center py-4">Select a project above.</div>'; return; }

  const res = await fetch(API + 'projects.php');
  const data = await res.json();
  const project = (data.projects || []).find(p => String(p.id) === String(projectId));
  if (!project) { body.innerHTML = '<div class="text-muted text-center py-4">Project not found.</div>'; return; }

  const currentIndex = LIFECYCLE_PHASES.findIndex(p => p.key === project.phase);

  body.innerHTML = `
    <div class="d-flex align-items-center justify-content-between mb-4" style="overflow-x:auto;">
      ${LIFECYCLE_PHASES.map((p, i) => `
        <div class="d-flex align-items-center" style="${i < LIFECYCLE_PHASES.length - 1 ? 'flex:1;' : ''}">
          <div class="text-center">
            <div style="width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto;
                        background:${i < currentIndex ? 'var(--status-green-bg)' : i === currentIndex ? 'var(--accent-light)' : 'var(--bg-page)'};
                        color:${i < currentIndex ? 'var(--status-green)' : i === currentIndex ? 'var(--accent)' : 'var(--text-hint)'};
                        border:2px solid ${i <= currentIndex ? (i < currentIndex ? 'var(--status-green)' : 'var(--accent)') : 'var(--card-border)'};">
              ${i < currentIndex ? '<i class="bi bi-check-lg"></i>' : i + 1}
            </div>
            <div style="font-size:11px; font-weight:600; margin-top:6px;">${p.label}</div>
            <div class="text-muted" style="font-size:10px;">${i < currentIndex ? 'Complete' : i === currentIndex ? 'Active' : 'Upcoming'}</div>
          </div>
          ${i < LIFECYCLE_PHASES.length - 1 ? `<div style="flex:1; height:2px; background:${i < currentIndex ? 'var(--status-green)' : 'var(--card-border)'}; margin:0 8px 24px;"></div>` : ''}
        </div>`).join('')}
    </div>
    <div class="d-flex justify-content-between align-items-center">
      <div>
        <div class="fw-bold" style="font-size:15px;">${esc(project.name)}</div>
        <div class="text-muted" style="font-size:12.5px;">Currently in <strong>${LIFECYCLE_PHASES[currentIndex]?.label || project.phase}</strong></div>
      </div>
      <div class="d-flex gap-2">
        ${currentIndex > 0 ? `<button class="btn btn-outline-secondary btn-sm" onclick="setProjectPhase(${project.id}, '${LIFECYCLE_PHASES[currentIndex - 1].key}')">Back</button>` : ''}
        ${currentIndex < LIFECYCLE_PHASES.length - 1 ? `<button class="btn btn-primary btn-sm" onclick="setProjectPhase(${project.id}, '${LIFECYCLE_PHASES[currentIndex + 1].key}')">Advance to ${LIFECYCLE_PHASES[currentIndex + 1].label}</button>` : '<span class="status-pill s-active">Final phase</span>'}
      </div>
    </div>
  `;
}

async function setProjectPhase(id, phase) {
  const fd = new FormData();
  fd.append('action', 'setPhase');
  fd.append('id', id);
  fd.append('phase', phase);
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Phase updated'); loadLifecycle(id); } else showToast(data.error || 'Failed to update phase');
}

/* ── REPORTS ── */
function csvDownload(filename, rows) {
  if (!rows.length) { showToast('Nothing to export yet'); return; }
  const headers = Object.keys(rows[0]);
  const csv = [headers.join(',')].concat(
    rows.map(r => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))
  ).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

let reportProjectsCache = [];
let reportInvoicesCache = [];

async function loadReports() {
  const [statsRes, projRes, billRes, rndRes] = await Promise.all([
    fetch(API + 'tasks.php?action=stats').then(r => r.json()),
    fetch(API + 'projects.php').then(r => r.json()),
    fetch(API + 'billing.php').then(r => r.json()),
    fetch(API + 'rnd.php').then(r => r.json()),
  ]);

  reportProjectsCache = projRes.projects || [];
  reportInvoicesCache = billRes.invoices || [];

  const byStatus = statsRes.projectsByStatus || {};
  document.getElementById('report-projects-summary').innerHTML = `
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Total projects</span><strong>${statsRes.totalProjects || 0}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Active</span><strong>${byStatus.active || 0}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">On hold</span><strong>${byStatus['on-hold'] || 0}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Draft</span><strong>${byStatus.draft || 0}</strong></div>
  `;

  const totals = billRes.totals || {};
  document.getElementById('report-billing-summary').innerHTML = `
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Outstanding</span><strong>${formatMoney(totals.outstanding)}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Overdue</span><strong>${formatMoney(totals.overdue)}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Invoiced this month</span><strong>${formatMoney(totals.invoicedThisMonth)}</strong></div>
  `;

  const byTask = statsRes.byStatus || {};
  document.getElementById('report-task-summary').innerHTML = `
    <div class="d-flex justify-content-between py-1"><span class="text-muted">To do</span><strong>${byTask.todo || 0}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">In progress</span><strong>${byTask.in_progress || 0}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Done</span><strong>${byTask.done || 0}</strong></div>
  `;

  const rndEntries = rndRes.entries || [];
  const rndByStatus = { open: 0, in_progress: 0, resolved: 0 };
  rndEntries.forEach(r => rndByStatus[r.status]++);
  document.getElementById('report-rnd-summary').innerHTML = `
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Open</span><strong>${rndByStatus.open}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">In progress</span><strong>${rndByStatus.in_progress}</strong></div>
    <div class="d-flex justify-content-between py-1"><span class="text-muted">Resolved</span><strong>${rndByStatus.resolved}</strong></div>
  `;
}

function exportProjectsCsv() { csvDownload('projects.csv', reportProjectsCache); }
function exportInvoicesCsv() { csvDownload('invoices.csv', reportInvoicesCache); }

/* ── CLIENT PORTAL (admin management view) ── */
async function loadClientPortal() {
  const body = document.getElementById('clientportal-table-body');
  const res = await fetch(API + 'projects.php');
  const data = await res.json();
  const projects = data.projects || [];

  body.innerHTML = projects.length ? projects.map(p => `
    <tr>
      <td class="ps-3 fw-semibold" style="color:var(--text-main);">${esc(p.name)}</td>
      <td class="pe-3">
        ${p.share_token
          ? `<code style="font-size:11px;">${location.origin}${location.pathname.replace(/index\.php$/, '')}client.php?token=${p.share_token}</code>
             <button class="btn btn-sm btn-outline-secondary ms-2" style="padding:2px 8px; font-size:11px;" onclick="copyClientLink('${p.share_token}')"><i class="bi bi-clipboard"></i></button>`
          : `<button class="btn btn-sm btn-outline-primary" onclick="generateClientLink(${p.id})">Generate link</button>`}
      </td>
    </tr>`).join('') : '<tr><td colspan="2" class="text-muted text-center py-4">No projects yet.</td></tr>';
}

async function generateClientLink(id) {
  const fd = new FormData();
  fd.append('action', 'getShareLink');
  fd.append('id', id);
  const res = await fetch(API + 'projects.php', { method: 'POST', body: fd });
  const data = await res.json();
  if (data.success) { showToast('Client link generated'); loadClientPortal(); } else showToast(data.error || 'Failed');
}

function copyClientLink(token) {
  const url = `${location.origin}${location.pathname.replace(/index\.php$/, '')}client.php?token=${token}`;
  navigator.clipboard.writeText(url).then(() => showToast('Link copied')).catch(() => showToast(url));
}
