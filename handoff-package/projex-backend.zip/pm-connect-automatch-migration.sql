-- Run once against projex_db.
-- Adds repo_url column to the projects table for auto-matching.
ALTER TABLE `projects` ADD COLUMN `repo_url` VARCHAR(255) NULL AFTER `description`;
