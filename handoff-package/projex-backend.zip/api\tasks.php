<?php
require_once __DIR__ . '/config.php';

$pdo = getDB();

function notify(PDO $pdo, string $recipient, string $message, ?int $taskId = null): void {
    if (!$recipient) return;
    $stmt = $pdo->prepare("INSERT INTO notifications (recipient, message, task_id) VALUES (?, ?, ?)");
    $stmt->execute([$recipient, $message, $taskId]);
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'list';

    if ($action === 'list') {
        $project_id = $_GET['project_id'] ?? 0;
        if (!$project_id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);

        $stmt = $pdo->prepare("SELECT * FROM tasks WHERE project_id = ? AND parent_task_id IS NULL ORDER BY created_at DESC");
        $stmt->execute([$project_id]);
        jsonResponse(['success' => true, 'tasks' => $stmt->fetchAll()]);
    }

    if ($action === 'detail') {
        $id = intval($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Task ID required'], 400);

        $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
        $stmt->execute([$id]);
        $task = $stmt->fetch();
        if (!$task) jsonResponse(['success' => false, 'error' => 'Task not found'], 404);

        $subStmt = $pdo->prepare("SELECT * FROM tasks WHERE parent_task_id = ? ORDER BY created_at ASC");
        $subStmt->execute([$id]);
        $subtasks = $subStmt->fetchAll();

        $commentStmt = $pdo->prepare("SELECT * FROM task_comments WHERE task_id = ? ORDER BY created_at ASC");
        $commentStmt->execute([$id]);
        $comments = $commentStmt->fetchAll();

        $attStmt = $pdo->prepare("SELECT * FROM task_attachments WHERE task_id = ? ORDER BY uploaded_at DESC");
        $attStmt->execute([$id]);
        $attachments = $attStmt->fetchAll();

        jsonResponse(['success' => true, 'task' => $task, 'subtasks' => $subtasks, 'comments' => $comments, 'attachments' => $attachments]);
    }

    if ($action === 'allNotifications') {
        // Admin oversight feed — every assignment/comment notification across
        // all developers, not just one recipient's inbox.
        $rows = $pdo->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20")->fetchAll();
        $countStmt = $pdo->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0");
        jsonResponse(['success' => true, 'notifications' => $rows, 'unreadCount' => (int) $countStmt->fetchColumn()]);
    }

    if ($action === 'progressByPeriod') {
        // Real project START counts, bucketed by day/week/month/year — feeds
        // the dashboard's Day/Week/Month/Year chart switcher. Uses
        // projects.started_at (when a project actually began), not task
        // creation — so the chart reflects real project activity over time.
        $period = $_GET['period'] ?? 'day';
        $points = [];

        if ($period === 'day') {
            $rows = $pdo->query("
                SELECT DATE(started_at) d, COUNT(*) c FROM projects
                WHERE started_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
                GROUP BY DATE(started_at)
            ")->fetchAll();
            $byKey = [];
            foreach ($rows as $r) $byKey[$r['d']] = (int) $r['c'];
            for ($i = 14; $i >= 0; $i--) {
                $d = date('Y-m-d', strtotime("-$i day"));
                $points[] = ['label' => date('d M', strtotime($d)), 'count' => $byKey[$d] ?? 0];
            }
        } elseif ($period === 'week') {
            $rows = $pdo->query("
                SELECT YEARWEEK(started_at, 1) wk, COUNT(*) c FROM projects
                WHERE started_at >= DATE_SUB(CURDATE(), INTERVAL 7 WEEK)
                GROUP BY wk
            ")->fetchAll();
            $byKey = [];
            foreach ($rows as $r) $byKey[$r['wk']] = (int) $r['c'];
            for ($i = 7; $i >= 0; $i--) {
                $yw = (int) date('oW', strtotime("-$i week"));
                $points[] = ['label' => 'Wk ' . date('W', strtotime("-$i week")), 'count' => $byKey[$yw] ?? 0];
            }
        } elseif ($period === 'month') {
            $rows = $pdo->query("
                SELECT DATE_FORMAT(started_at, '%Y-%m') m, COUNT(*) c FROM projects
                WHERE started_at >= DATE_SUB(CURDATE(), INTERVAL 11 MONTH)
                GROUP BY m
            ")->fetchAll();
            $byKey = [];
            foreach ($rows as $r) $byKey[$r['m']] = (int) $r['c'];
            for ($i = 11; $i >= 0; $i--) {
                $m = date('Y-m', strtotime("-$i month"));
                $points[] = ['label' => date('M', strtotime("-$i month")), 'count' => $byKey[$m] ?? 0];
            }
        } else { // year
            $rows = $pdo->query("
                SELECT YEAR(started_at) y, COUNT(*) c FROM projects
                WHERE started_at IS NOT NULL
                GROUP BY y
            ")->fetchAll();
            $byKey = [];
            foreach ($rows as $r) $byKey[(int) $r['y']] = (int) $r['c'];
            $thisYear = (int) date('Y');
            for ($y = $thisYear - 4; $y <= $thisYear; $y++) {
                $points[] = ['label' => (string) $y, 'count' => $byKey[$y] ?? 0];
            }
        }

        jsonResponse(['success' => true, 'points' => $points]);
    }

    if ($action === 'stats') {
        // Site-wide dashboard numbers — real data only, across every project.
        $statusCounts = $pdo->query("SELECT status, COUNT(*) c FROM tasks WHERE parent_task_id IS NULL GROUP BY status")->fetchAll();
        $byStatus = ['todo' => 0, 'in_progress' => 0, 'done' => 0];
        foreach ($statusCounts as $row) $byStatus[$row['status']] = (int) $row['c'];

        // Project Statistic donut is driven by real project start/completion —
        // how many of our actual projects finished vs are still in progress.
        $projectsCompleted = (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE completed_at IS NOT NULL")->fetchColumn();
        $projectsStarted = (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE started_at IS NOT NULL")->fetchColumn();
        $projectsInProgress = $projectsStarted - $projectsCompleted;
        $total = array_sum($byStatus);
        $completionPct = $projectsStarted ? (int) round($projectsCompleted / $projectsStarted * 100) : 0;
        $inProgressPct = $projectsStarted ? (int) round($projectsInProgress / $projectsStarted * 100) : 0;

        $todayStmt = $pdo->query("
            SELECT t.id, t.title, t.status, t.priority, t.assignee, p.name AS project_name
            FROM tasks t
            JOIN projects p ON p.id = t.project_id
            WHERE t.due_date = CURDATE() AND t.parent_task_id IS NULL
            ORDER BY t.priority = 'urgent' DESC, t.priority = 'high' DESC
            LIMIT 8
        ");
        $todayTasks = $todayStmt->fetchAll();

        // Pick the project with the most real activity (commits) to feature —
        // not just whatever was created most recently, which tends to surface
        // throwaway test projects instead of substantial real work.
        $recentStmt = $pdo->query("
            SELECT p.id, p.name, p.status, p.description, p.started_at, p.completed_at, p.created_by,
                   COALESCE(SUM(l.commits_count), 0) AS totalCommits
            FROM projects p
            LEFT JOIN project_daily_log l ON l.project_id = p.id
            GROUP BY p.id
            ORDER BY totalCommits DESC, GREATEST(COALESCE(p.started_at, p.created_at), p.created_at) DESC
            LIMIT 1
        ");
        $recentProject = $recentStmt->fetch();

        if ($recentProject) {
            $contribStmt = $pdo->prepare("SELECT DISTINCT employee FROM project_daily_log WHERE project_id = ? LIMIT 6");
            $contribStmt->execute([$recentProject['id']]);
            $recentProject['contributors'] = $contribStmt->fetchAll(PDO::FETCH_COLUMN);
        }

        $projectCounts = $pdo->query("SELECT status, COUNT(*) c FROM projects GROUP BY status")->fetchAll();
        $projectsByStatus = ['active' => 0, 'on-hold' => 0, 'draft' => 0];
        foreach ($projectCounts as $row) $projectsByStatus[$row['status']] = (int) $row['c'];
        $totalProjects = array_sum($projectsByStatus);

        $totalDevelopers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE api_key IS NOT NULL")->fetchColumn();
        $totalCommits = (int) $pdo->query("SELECT COALESCE(SUM(commits_count),0) FROM project_daily_log")->fetchColumn();
        $totalActiveMinutes = intdiv((int) $pdo->query("SELECT COALESCE(SUM(active_seconds),0) FROM project_daily_log")->fetchColumn(), 60);

        // Most recent tasks across every project, with real comment/attachment
        // counts and each subtask's completion ratio (used for the progress bar).
        $recentTasksStmt = $pdo->query("
            SELECT t.id, t.title, t.status, t.assignee, t.priority, p.name AS project_name,
                   (SELECT COUNT(*) FROM task_comments WHERE task_id = t.id) AS comment_count,
                   (SELECT COUNT(*) FROM tasks st WHERE st.parent_task_id = t.id) AS subtask_total,
                   (SELECT COUNT(*) FROM tasks st WHERE st.parent_task_id = t.id AND st.status = 'done') AS subtask_done
            FROM tasks t
            JOIN projects p ON p.id = t.project_id
            WHERE t.parent_task_id IS NULL
            ORDER BY t.created_at DESC
            LIMIT 4
        ");
        $recentTasks = $recentTasksStmt->fetchAll();

        jsonResponse([
            'success' => true,
            'byStatus' => $byStatus,
            'recentTasks' => $recentTasks,
            'completionPct' => $completionPct,
            'inProgressPct' => $inProgressPct,
            'projectsCompleted' => $projectsCompleted,
            'projectsInProgress' => $projectsInProgress,
            'totalTasks' => $total,
            'todayTasks' => $todayTasks,
            'recentProject' => $recentProject ?: null,
            'projectsByStatus' => $projectsByStatus,
            'totalProjects' => $totalProjects,
            'totalDevelopers' => $totalDevelopers,
            'totalCommits' => $totalCommits,
            'totalActiveMinutes' => $totalActiveMinutes,
        ]);
    }

    if ($action === 'notifications') {
        $recipient = trim($_GET['recipient'] ?? '');
        if (!$recipient) jsonResponse(['success' => false, 'error' => 'recipient required'], 400);

        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE recipient = ? ORDER BY created_at DESC LIMIT 30");
        $stmt->execute([$recipient]);
        $rows = $stmt->fetchAll();

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE recipient = ? AND is_read = 0");
        $countStmt->execute([$recipient]);

        jsonResponse(['success' => true, 'notifications' => $rows, 'unreadCount' => (int) $countStmt->fetchColumn()]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid request'], 400);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $project_id  = $_POST['project_id'] ?? 0;
        $title       = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $assignee    = $_POST['assignee'] ?? '';
        $due_date    = $_POST['due_date'] ?? null;
        $priority    = $_POST['priority'] ?? 'medium';
        $parent_id   = intval($_POST['parent_task_id'] ?? 0) ?: null;
        $created_by  = $_SESSION['name'] ?? $_SESSION['email'] ?? 'Admin';

        if (!$project_id || !$title) {
            jsonResponse(['success' => false, 'error' => 'Project ID and Title are required'], 400);
        }

        $stmt = $pdo->prepare("INSERT INTO tasks (project_id, title, description, assignee, due_date, priority, parent_task_id, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$project_id, $title, $description, $assignee, $due_date ?: null, $priority, $parent_id, $created_by]);
        $id = $pdo->lastInsertId();

        if ($assignee) notify($pdo, $assignee, "You were assigned: \"$title\"", (int) $id);

        jsonResponse(['success' => true, 'id' => $id]);
    }
    elseif ($action === 'complete') {
        $id = $_POST['id'] ?? 0;
        if (!$id) jsonResponse(['success' => false, 'error' => 'Task ID required'], 400);

        $stmt = $pdo->prepare("UPDATE tasks SET status = 'done' WHERE id = ?");
        $stmt->execute([$id]);

        jsonResponse(['success' => true]);
    }
    elseif ($action === 'updateStatus') {
        $id = intval($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if (!$id || !in_array($status, ['todo', 'in_progress', 'done'], true)) {
            jsonResponse(['success' => false, 'error' => 'Valid ID and status required'], 400);
        }

        $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);

        jsonResponse(['success' => true]);
    }
    elseif ($action === 'update') {
        $id = intval($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $due_date = $_POST['due_date'] ?? null;
        $priority = $_POST['priority'] ?? 'medium';
        $assignee = trim($_POST['assignee'] ?? '');
        if (!$id || !$title) {
            jsonResponse(['success' => false, 'error' => 'ID and title required'], 400);
        }
        $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, due_date = ?, priority = ?, assignee = ? WHERE id = ?");
        $stmt->execute([$title, $description, $due_date ?: null, $priority, $assignee, $id]);
        jsonResponse(['success' => true]);
    }
    elseif ($action === 'comment') {
        $task_id = intval($_POST['task_id'] ?? 0);
        $comment = trim($_POST['comment'] ?? '');
        $author  = $_SESSION['name'] ?? $_SESSION['email'] ?? 'Admin';
        if (!$task_id || !$comment) {
            jsonResponse(['success' => false, 'error' => 'task_id and comment required'], 400);
        }
        $stmt = $pdo->prepare("INSERT INTO task_comments (task_id, author, comment) VALUES (?, ?, ?)");
        $stmt->execute([$task_id, $author, $comment]);

        $taskStmt = $pdo->prepare("SELECT title, assignee FROM tasks WHERE id = ?");
        $taskStmt->execute([$task_id]);
        $task = $taskStmt->fetch();
        if ($task && $task['assignee'] && $task['assignee'] !== $author) {
            notify($pdo, $task['assignee'], "$author commented on \"{$task['title']}\"", $task_id);
        }

        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }
    elseif ($action === 'uploadAttachment') {
        $task_id = intval($_POST['task_id'] ?? 0);
        if (!$task_id || empty($_FILES['file'])) {
            jsonResponse(['success' => false, 'error' => 'task_id and file required'], 400);
        }
        $file = $_FILES['file'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $storedName = 'task_' . uniqid() . ($ext ? ".$ext" : '');
        $destDir = __DIR__ . '/../uploads/';
        if (!is_dir($destDir)) mkdir($destDir, 0755, true);
        move_uploaded_file($file['tmp_name'], $destDir . $storedName);

        $stmt = $pdo->prepare("INSERT INTO task_attachments (task_id, original_name, stored_name, file_size) VALUES (?, ?, ?, ?)");
        $stmt->execute([$task_id, $file['name'], $storedName, $file['size']]);

        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }
    elseif ($action === 'markNotificationsRead') {
        $recipient = trim($_POST['recipient'] ?? '');
        if ($recipient) {
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE recipient = ?");
            $stmt->execute([$recipient]);
        } else {
            $pdo->exec("UPDATE notifications SET is_read = 1");
        }
        jsonResponse(['success' => true]);
    }
}

jsonResponse(['success' => false, 'error' => 'Invalid request'], 400);
