# Projex — Complete Project Management System
### Full Requirements & Build Prompt (for development firm / freelancer / AI agent)

---

## 1. What This Is

A complete, production-grade **Project Management System** for a software services
company (TimeGlobal), covering three types of users — **Admin**, **Developer**,
and **Client** — with a **mandatory integration to an existing VS Code extension**
("PM Connect") that automatically tracks developer activity (coding time, commits,
task progress) and feeds it into this system in real time.

This is not a generic to-do app. It must answer, at any moment, for the business
owner:

- Kitne projects chal rahe hain, kis phase mein hain, kab shuru hue, kab khatam
  honge, aur har project ki **cost** kya hai.
- Har **employee** ke paas is waqt kitne projects hain, un projects se kitni
  **cost** aayi, aur **profit ya loss** hua.
- Har **client** ke kitne projects hain, kitne complete ho chuke, kitne baaki
  hain.
- **Interns** ka kaam kya hai, unki performance kaisi hai.
- Har project ki **agreement**, **meetings**, aur **lifecycle** (initiation se
  closure tak) ka record.

Everything must be backed by real database records — no placeholder/fake numbers
anywhere in the shipped product.

---

## 2. Technology (non-negotiable)

- **Backend:** Core PHP (no framework — no Laravel/Symfony), PDO + MySQL
- **Frontend:** Server-rendered PHP + vanilla JS + Bootstrap 5 (existing stack,
  do not rewrite in React/Vue/Next.js)
- **Database:** MySQL
- **VS Code Extension Integration:** MANDATORY. A working extension ("PM Connect")
  already exists and already sends this system:
  - Project start events
  - Git commit events (SHA, message, timestamp)
  - Active coding time (heartbeats, in seconds)
  - Task status/progress/time-log updates
  - This data must be preserved and remain the **source of truth** for all
    "real activity" numbers shown anywhere in the system (dashboards, reports,
    employee performance, project cost calculations). Do not replace it with
    manually-entered estimates.

---

## 3. Roles & What Each One Sees

### 3.1 Admin (full visibility — owner/manager)

Admin must be able to see, for **every** project and **every** person:

**Projects — full detail per project:**
- Name, client, type, description
- Current lifecycle phase (Initiation → Planning → Execution → Review →
  Closure → Post-Sale)
- Start date (real — set automatically the first time a developer opens the
  project in VS Code, or manually)
- Expected/actual end date
- **Cost so far** — derived from: hours tracked (VS Code + manual time logs) ×
  a rate, PLUS/MINUS any invoiced amounts and expenses. Must be a real
  calculation, not a guess.
- Revenue (from invoices raised against this project)
- **Profit/Loss** = Revenue − Cost, shown per project
- Team assigned, real commit count, real active coding hours
- Task breakdown (todo/in progress/done), % complete
- Files, discussion/comments, agreement document, meeting log

**Employees — full detail per person:**
- Name, role, contact
- **Current projects** — live list of what they're assigned to right now
- **Total projects worked on** (all-time count)
- Per project and in total: **hours tracked** (real, from VS Code + manual
  logs), **commits made**, **tasks completed**
- **Cost generated** (their tracked hours × their rate) vs. **revenue
  attributed** to the projects they worked on → individual profit/loss
  contribution
- Capacity (weekly hours) vs. current load
- Skills matrix entry

**Clients — full detail per client:**
- Name, contact
- Total projects with this client
- Completed vs. in-progress vs. not-started count
- Total invoiced, total paid, outstanding, overdue
- Agreements/contracts on file
- Meeting history

**Interns:**
- Same as employees but flagged separately, with a dedicated report: work
  queue, tasks completed, skills being built, mentor/reviewer notes

**Also required for Admin:**
- Company-wide dashboard: total projects, active/completed/on-hold, total
  revenue, total cost, total profit, developers online, overdue tasks
- Reports module: exportable (CSV/PDF) reports for any of the above, filterable
  by date range, project, client, employee
- Full audit log (who did what, when)
- Roles & permissions management
- Settings (project types, SMTP, branding)

### 3.2 Developer

- Their own dashboard: today's work, current task, coding time (from VS Code),
  idle time, git activity, assigned tasks, notifications
- List of projects they're currently on, with real progress
- Their own time log (tracked + manual), submitted for approval
- Cannot see other developers' cost/profit numbers, cannot see company-wide
  financials
- Can view/comment on tasks assigned to them, update status, log time

### 3.3 Client

- Read-only portal (no login required — secure shareable link per project, OR
  a lightweight client login if the firm prefers)
- Their project(s): current phase, real progress %, milestones, timeline
- Files/deliverables shared with them
- Their invoices and payment status
- Meeting schedule/history relevant to them
- Ability to leave feedback/approve deliverables
- **Must never see:** internal cost breakdown, other clients' data, employee
  performance/profit numbers

---

## 4. Required Modules

1. **Projects** — list/grid/kanban view, create/edit/archive, full detail page
   (overview, tasks, files, discussion, timeline, budget, agreement, meetings)
2. **Tasks** — kanban + list view, priority, labels, checklist, comments,
   attachments, due dates, subtasks, dependencies, time tracking
3. **Project Lifecycle** — phase stepper (Initiation → Planning → Execution →
   Review → Closure → Post-Sale) with sign-off per phase
4. **Project Agreements** — upload/generate contract documents per project,
   track signature status
5. **Meetings** — schedule, log notes/outcomes, link to a project and/or client
6. **Time & Cost** — VS Code-tracked time + manual time logs, approvals,
   per-project cost, organisation-wide cost report
7. **Billing/Invoicing** — raise invoices per project/milestone, track
   sent/paid/overdue, client-facing payment status
8. **People (Employees)** — directory, roles, capacity, performance, cost/P&L
   contribution
9. **Interns** — separate tracking, work queue, performance report
10. **Clients** — directory derived from real project/invoice data, per-client
    project and billing summary
11. **Skills Matrix** — team skill levels, skill library, gap analysis
12. **Estimations** — inquiry → queue → pipeline → won/lost, with estimated
    value
13. **Reports** — cross-module real-data reports, exportable
14. **R&D Log / Knowledge Base** — research questions tracked to resolution,
    reusable internal knowledge articles
15. **Client Portal** — read-only external view per project
16. **Notifications** — in-app + (optionally) email, real-time where possible
17. **VS Code Extension API** — the existing contract (task CRUD,
    project-start ping, commit heartbeat, active-time heartbeat, rollups) must
    keep working exactly as-is; this system is the backend for it

---

## 5. Cost / Profit-Loss Calculation Rules (must be explicit, not guessed)

To show real cost and profit/loss, the system needs:
- An **hourly rate per employee** (admin-configurable)
- Real tracked hours per employee per project (already available via VS Code
  extension + manual logs)
- **Project cost** = Σ(employee hours on this project × employee rate)
- **Project revenue** = Σ(invoices raised against this project that are paid,
  or paid + pending — firm should ask which the business wants)
- **Project profit/loss** = revenue − cost
- **Employee cost generated** = their hours × their rate, summed across all
  their projects
- **Employee profit contribution** = revenue of projects they worked on
  (apportioned by their share of hours, or simple attribution — firm should
  confirm the business's preferred method) − their cost generated

If a rate hasn't been set for an employee, the system should show hours only
and **not** fabricate a $ figure.

---

## 6. Data Integrity Rules

- No fake/placeholder financial data anywhere in the shipped product —
  everything starts at real zero and fills up as the business uses it.
- No fabricated "AI" features (no fake AI agents, no fake automation logs)
  unless the firm is separately asked to build a real automation engine.
- All existing VS Code extension API endpoints, database tables, and
  authentication must continue to work unchanged — this is an extension of an
  existing live system, not a rewrite.

---

## 7. Deliverables Expected From the Firm

1. Updated MySQL schema (migration scripts, additive only where the existing
   system is concerned)
2. All PHP APIs for the modules above (REST-style, JSON)
3. Full frontend (Admin, Developer, Client views) matching the existing
   design system (or a refreshed one, to be agreed)
4. Documentation: how each cost/profit figure is calculated, and how to
   configure employee rates
5. A short handoff walkthrough (video or written) for the Admin user

---

## 8. Reference for Visual/UX Direction (optional)

If a visual reference is needed for layout/navigation style (sidebar +
topbar + card-based dashboards), use `https://progect-mangment.lovable.app/`
as **inspiration only** — do not copy it feature-for-feature; adapt to the
real modules and real data listed above.
