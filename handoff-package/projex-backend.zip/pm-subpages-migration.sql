-- Sub-page support: approvals, project closure/case-study notes, knowledge base.
-- Run once: mysql -u root projex_db < pm-subpages-migration.sql

ALTER TABLE `task_time_logs`
  ADD COLUMN `approved` TINYINT(1) NOT NULL DEFAULT 0 AFTER `minutes`;

ALTER TABLE `projects`
  ADD COLUMN `case_study` TEXT NULL AFTER `share_token`,
  ADD COLUMN `closure_notes` TEXT NULL AFTER `case_study`;

CREATE TABLE IF NOT EXISTS `knowledge_base` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `tags` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
