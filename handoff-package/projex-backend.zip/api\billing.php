<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'list';

    if ($action === 'list') {
        $rows = $pdo->query("
            SELECT i.id, i.project_id, i.client, i.milestone, i.amount, i.status, i.due_date,
                   DATE_FORMAT(i.due_date, '%d %b %Y') AS due_date_fmt,
                   p.name AS project_name
            FROM invoices i
            JOIN projects p ON p.id = i.project_id
            ORDER BY i.created_at DESC
        ")->fetchAll();

        // Real totals only — computed from actual rows, zero everywhere until data exists.
        $outstanding = 0;
        $overdue     = 0;
        $invoicedThisMonth = 0;
        $thisMonth = date('Y-m');
        foreach ($rows as $r) {
            if (in_array($r['status'], ['sent', 'overdue'], true)) $outstanding += (float) $r['amount'];
            if ($r['status'] === 'overdue') $overdue += (float) $r['amount'];
        }
        $monthStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM invoices WHERE DATE_FORMAT(created_at,'%Y-%m') = ?");
        $monthStmt->execute([$thisMonth]);
        $invoicedThisMonth = (float) $monthStmt->fetchColumn();

        jsonResponse([
            'success' => true,
            'invoices' => $rows,
            'totals' => [
                'outstanding' => $outstanding,
                'overdue' => $overdue,
                'invoicedThisMonth' => $invoicedThisMonth,
            ],
        ]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $projectId = intval($_POST['project_id'] ?? 0);
        $client    = trim($_POST['client'] ?? '');
        $milestone = trim($_POST['milestone'] ?? '');
        $amount    = floatval($_POST['amount'] ?? 0);
        $dueDate   = $_POST['due_date'] ?? null;

        if (!$projectId || $amount <= 0) {
            jsonResponse(['success' => false, 'error' => 'project_id and a positive amount are required'], 400);
        }

        $stmt = $pdo->prepare("INSERT INTO invoices (project_id, client, milestone, amount, status, due_date) VALUES (?, ?, ?, ?, 'sent', ?)");
        $stmt->execute([$projectId, $client ?: null, $milestone ?: null, $amount, $dueDate ?: null]);

        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'updateStatus') {
        $id     = intval($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if (!$id || !in_array($status, ['not_raised', 'sent', 'paid', 'overdue'], true)) {
            jsonResponse(['success' => false, 'error' => 'Valid id and status required'], 400);
        }
        $pdo->prepare("UPDATE invoices SET status = ? WHERE id = ?")->execute([$status, $id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
