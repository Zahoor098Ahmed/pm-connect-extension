<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM estimations ORDER BY created_at DESC")->fetchAll();
    $byStatus = ['new_inquiry' => 0, 'queue' => 0, 'pipeline' => 0, 'won' => 0, 'lost' => 0];
    foreach ($rows as $r) $byStatus[$r['status']]++;
    jsonResponse(['success' => true, 'estimations' => $rows, 'byStatus' => $byStatus]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $title = trim($_POST['title'] ?? '');
        $client = trim($_POST['client'] ?? '');
        $value = floatval($_POST['estimated_value'] ?? 0);
        $notes = trim($_POST['notes'] ?? '');
        if (!$title) jsonResponse(['success' => false, 'error' => 'Title is required'], 400);

        $stmt = $pdo->prepare("INSERT INTO estimations (title, client, estimated_value, notes) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $client ?: null, $value, $notes ?: null]);
        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'updateStatus') {
        $id = intval($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if (!$id || !in_array($status, ['new_inquiry', 'queue', 'pipeline', 'won', 'lost'], true)) {
            jsonResponse(['success' => false, 'error' => 'Valid id and status required'], 400);
        }
        $pdo->prepare("UPDATE estimations SET status = ? WHERE id = ?")->execute([$status, $id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
