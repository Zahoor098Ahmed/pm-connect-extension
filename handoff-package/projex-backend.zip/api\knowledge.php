<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM knowledge_base ORDER BY created_at DESC")->fetchAll();
    jsonResponse(['success' => true, 'articles' => $rows]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $tags = trim($_POST['tags'] ?? '');
        if (!$title || !$content) jsonResponse(['success' => false, 'error' => 'Title and content are required'], 400);

        $stmt = $pdo->prepare("INSERT INTO knowledge_base (title, content, tags) VALUES (?, ?, ?)");
        $stmt->execute([$title, $content, $tags ?: null]);
        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'id required'], 400);
        $pdo->prepare("DELETE FROM knowledge_base WHERE id = ?")->execute([$id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
