<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = $pdo->query("SELECT * FROM services ORDER BY name")->fetchAll();
    jsonResponse(['success' => true, 'services' => $rows]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        if (!$name) jsonResponse(['success' => false, 'error' => 'Name is required'], 400);

        $stmt = $pdo->prepare("INSERT INTO services (name, description, price) VALUES (?, ?, ?)");
        $stmt->execute([$name, $description ?: null, $price]);
        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
    }

    if ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'id required'], 400);
        $pdo->prepare("DELETE FROM services WHERE id = ?")->execute([$id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
