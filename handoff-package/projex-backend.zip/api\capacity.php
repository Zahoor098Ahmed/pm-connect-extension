<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Real active-task counts per person vs. their stated weekly capacity.
    // No fabricated utilization % — this app doesn't track per-task hour
    // estimates, so we only show what's actually knowable: how many open
    // tasks someone is carrying right now.
    $rows = $pdo->query("
        SELECT u.id, u.name, u.weekly_capacity_hours,
               COUNT(t.id) AS active_tasks
        FROM users u
        LEFT JOIN tasks t ON t.assignee COLLATE utf8mb4_general_ci = u.name AND t.status IN ('todo','in_progress') AND t.parent_task_id IS NULL
        GROUP BY u.id
        ORDER BY active_tasks DESC
    ")->fetchAll();

    jsonResponse(['success' => true, 'capacity' => $rows]);
}

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'setCapacity') {
        $id = intval($_POST['id'] ?? 0);
        $hours = intval($_POST['weekly_capacity_hours'] ?? 0);
        if (!$id || $hours <= 0) jsonResponse(['success' => false, 'error' => 'Valid id and hours required'], 400);

        $pdo->prepare("UPDATE users SET weekly_capacity_hours = ? WHERE id = ?")->execute([$hours, $id]);
        jsonResponse(['success' => true]);
    }

    jsonResponse(['success' => false, 'error' => 'Invalid action'], 400);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
