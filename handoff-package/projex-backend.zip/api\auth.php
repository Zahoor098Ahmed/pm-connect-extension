<?php
session_start();
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        $email    = trim($_POST['email']    ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            jsonResponse(['success' => false, 'error' => 'Email and password required'], 400);
        }

        // Check admins first
        $stmt = $db->prepare("SELECT id, password, email FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        if ($row && password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['email']    = $row['email'];
            $_SESSION['role']     = 'admin';
            $_SESSION['name']     = 'Admin';
            jsonResponse(['success' => true, 'role' => 'admin', 'email' => $row['email']]);
        }

        // Check users table
        $stmt = $db->prepare("SELECT id, password, email, name FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        if ($row && password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['email']    = $row['email'];
            $_SESSION['role']     = 'user';
            $_SESSION['name']     = $row['name'];
            jsonResponse(['success' => true, 'role' => 'user', 'email' => $row['email'], 'name' => $row['name']]);
        }

        jsonResponse(['success' => false, 'error' => 'Invalid credentials'], 401);
    }

    if ($action === 'logout') {
        session_destroy();
        jsonResponse(['success' => true]);
    }
}

if ($method === 'GET') {
    if (isset($_SESSION['admin_id'])) {
        jsonResponse([
            'authenticated' => true,
            'email' => $_SESSION['email'],
            'role'  => $_SESSION['role'] ?? 'admin',
            'name'  => $_SESSION['name'] ?? ''
        ]);
    } else {
        jsonResponse(['authenticated' => false]);
    }
}

jsonResponse(['error' => 'Invalid request'], 400);
