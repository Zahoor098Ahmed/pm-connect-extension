<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Real audit trail — reads the activity_log table that already exists and
// is already being written to by pmconnect.php (VS Code extension events).
if ($method === 'GET') {
    $rows = $pdo->query("
        SELECT employee, action, task_title, detail,
               DATE_FORMAT(created_at, '%d %b %Y, %h:%i %p') AS created_at
        FROM activity_log
        ORDER BY created_at DESC
        LIMIT 200
    ")->fetchAll();

    jsonResponse(['success' => true, 'entries' => $rows]);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
