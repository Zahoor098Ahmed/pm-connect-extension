-- Estimations, Capacity, Interns, Lifecycle, Services, Client Portal — additive only.
-- Run once: mysql -u root projex_db < pm-more-modules-migration.sql

ALTER TABLE `users`
  ADD COLUMN `is_intern` TINYINT(1) NOT NULL DEFAULT 0 AFTER `role`,
  ADD COLUMN `weekly_capacity_hours` INT UNSIGNED NOT NULL DEFAULT 40 AFTER `is_intern`;

ALTER TABLE `projects`
  ADD COLUMN `phase` ENUM('initiation','planning','execution','review','closure','post_sale') NOT NULL DEFAULT 'initiation' AFTER `status`,
  ADD COLUMN `share_token` VARCHAR(64) NULL UNIQUE AFTER `phase`;

CREATE TABLE IF NOT EXISTS `estimations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `client` VARCHAR(255) NULL,
  `status` ENUM('new_inquiry','queue','pipeline','won','lost') NOT NULL DEFAULT 'new_inquiry',
  `estimated_value` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `services` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `price` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
