-- Full project-management feature set: Kanban statuses, due dates, priority,
-- subtasks, comments, attachments, notifications/activity feed, user roles.
-- Run once: mysql -u root projex_db < pm-full-pm-features-migration.sql

-- 1. Tasks: real Kanban statuses (todo/in_progress/done), due date, priority,
--    subtasks (parent_task_id self-reference).
ALTER TABLE `tasks`
  MODIFY COLUMN `status` ENUM('todo','in_progress','done') NOT NULL DEFAULT 'todo',
  ADD COLUMN `due_date` DATE NULL AFTER `assignee`,
  ADD COLUMN `priority` ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium' AFTER `due_date`,
  ADD COLUMN `parent_task_id` INT NULL AFTER `priority`,
  ADD CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks`(`id`) ON DELETE CASCADE;

-- Migrate old 2-state data into the new 3-state enum.
UPDATE `tasks` SET `status` = 'done' WHERE `status` = 'completed';
UPDATE `tasks` SET `status` = 'todo' WHERE `status` = 'pending';

-- 2. Comments on tasks.
CREATE TABLE IF NOT EXISTS `task_comments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_id` INT NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `comment` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_comments_task` FOREIGN KEY (`task_id`) REFERENCES `tasks`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. File attachments on tasks (mirrors project_files).
CREATE TABLE IF NOT EXISTS `task_attachments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `task_id` INT NOT NULL,
  `original_name` VARCHAR(255) NOT NULL,
  `stored_name` VARCHAR(255) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL DEFAULT 0,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_attachments_task` FOREIGN KEY (`task_id`) REFERENCES `tasks`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Notifications (bell icon feed) — separate from activity_log, since
--    notifications are per-recipient and get marked read/unread.
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `recipient` VARCHAR(255) NOT NULL,
  `message` VARCHAR(500) NOT NULL,
  `task_id` INT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Roles — Admin / Manager / Developer permission levels.
ALTER TABLE `users`
  ADD COLUMN `role` ENUM('admin','manager','developer') NOT NULL DEFAULT 'developer' AFTER `email`;
