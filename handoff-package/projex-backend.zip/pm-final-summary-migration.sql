-- Final Summary feature: client-facing "project complete" report.
-- Daily/weekly/monthly rollups stay internal-only (unchanged); this is a
-- separate, one-time-per-completion consolidated summary that also goes
-- out to the client, not just the admin.

ALTER TABLE `projects`
  ADD COLUMN `client_email` VARCHAR(255) NULL AFTER `country`;

CREATE TABLE IF NOT EXISTS `project_final_summary` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT UNSIGNED NOT NULL,
  `started_at` TIMESTAMP NULL DEFAULT NULL,
  `completed_at` TIMESTAMP NULL DEFAULT NULL,
  `total_commits` INT UNSIGNED NOT NULL DEFAULT 0,
  `total_active_seconds` INT UNSIGNED NOT NULL DEFAULT 0,
  `internal_summary` TEXT NULL,
  `client_summary` TEXT NULL,
  `pdf_path` VARCHAR(500) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_final_summary_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
