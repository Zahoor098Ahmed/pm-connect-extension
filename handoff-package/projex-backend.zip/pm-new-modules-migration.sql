-- Skills Matrix, R&D Log, Billing/Invoices — new, additive tables only.
-- Run once: mysql -u root projex_db < pm-new-modules-migration.sql

-- 1. Skills Matrix
CREATE TABLE IF NOT EXISTS `skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `user_skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT UNSIGNED NOT NULL,
  `skill_id` INT NOT NULL,
  `level` ENUM('none','beginner','intermediate','advanced','expert') NOT NULL DEFAULT 'none',
  UNIQUE KEY `uniq_user_skill` (`user_id`, `skill_id`),
  CONSTRAINT `fk_user_skills_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_skills_skill` FOREIGN KEY (`skill_id`) REFERENCES `skills`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. R&D Log
CREATE TABLE IF NOT EXISTS `research_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question` VARCHAR(500) NOT NULL,
  `project_id` INT UNSIGNED NULL,
  `category` ENUM('Technical','Legal','Market','Other') NOT NULL DEFAULT 'Technical',
  `priority` ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  `status` ENUM('open','in_progress','resolved') NOT NULL DEFAULT 'open',
  `owner` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_research_log_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Billing / Invoices
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT UNSIGNED NOT NULL,
  `client` VARCHAR(255) NULL,
  `milestone` VARCHAR(255) NULL,
  `amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `status` ENUM('not_raised','sent','paid','overdue') NOT NULL DEFAULT 'not_raised',
  `due_date` DATE NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_invoices_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
