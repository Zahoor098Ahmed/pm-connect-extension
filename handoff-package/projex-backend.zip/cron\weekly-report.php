<?php
// Weekly Cron Report — runs every Monday.
// Generates weekly rollup PDF for active projects and emails them to the admin.

require_once dirname(__DIR__) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/api/config.php';

use Dompdf\Dompdf;
use Dompdf\Options;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Create logs directory if not exists
$logDir = dirname(__DIR__) . '/uploads/logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0777, true);
}
$logFile = $logDir . '/cron_weekly.log';

function cronLog($msg) {
    global $logFile;
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] " . $msg . "\n", FILE_APPEND);
}

cronLog("Starting weekly cron report...");

$pdo = getDB();

// 1. Get Admin email
$adminEmail = 'admin@example.com'; // Default fallback
try {
    $adminStmt = $pdo->query("SELECT email FROM admins LIMIT 1");
    $dbAdminEmail = $adminStmt->fetchColumn();
    if ($dbAdminEmail) {
        $adminEmail = $dbAdminEmail;
    }
} catch (Exception $e) {
    cronLog("Failed to fetch admin email: " . $e->getMessage());
}

// 2. Find projects active in the last 7 days
try {
    $projectStmt = $pdo->query("
        SELECT DISTINCT p.id, p.name, p.started_at, p.completed_at, p.description
        FROM projects p
        JOIN project_daily_log l ON l.project_id = p.id
        WHERE l.log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ");
    $projects = $projectStmt->fetchAll();
} catch (Exception $e) {
    cronLog("Failed to fetch active projects: " . $e->getMessage());
    exit;
}

if (empty($projects)) {
    cronLog("No active projects in the last 7 days. Exiting.");
    exit;
}

// Create reports directory
$reportsDir = dirname(__DIR__) . '/uploads/reports';
if (!is_dir($reportsDir)) {
    mkdir($reportsDir, 0777, true);
}

// Helper formatting functions
function fmtDate($v) { return $v ? date('d M Y', strtotime($v)) : '—'; }
function fmtMin($seconds) { return intdiv((int) $seconds, 60) . ' min'; }
function guessFeatureLabel(string $path): string {
    $base = basename($path);
    $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    $name = trim(preg_replace('/[-_]+/', ' ', preg_replace('/\.[a-zA-Z0-9]+$/', '', $base)));
    if ($name === '') return $base;
    $lower = strtolower($name);
    if (in_array($lower, ['index', 'home', 'main'], true)) return 'Home Page';
    $label = implode(' ', array_map('ucfirst', explode(' ', $lower)));
    if (in_array($ext, ['php', 'html', 'htm']) && stripos($label, 'page') === false) $label .= ' Page';
    return $label;
}

foreach ($projects as $project) {
    cronLog("Generating report for project ID {$project['id']}: {$project['name']}");

    $projectId = (int)$project['id'];
    $daysTaken = $project['started_at']
        ? (new DateTime($project['completed_at'] ?? 'now'))->diff(new DateTime($project['started_at']))->days
        : null;

    // Week rollup
    $weekStmt = $pdo->prepare("SELECT COALESCE(SUM(commits_count),0) c, COALESCE(SUM(active_seconds),0) s FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)");
    $weekStmt->execute([$projectId]);
    $week = $weekStmt->fetch();

    // Month rollup
    $monthStmt = $pdo->prepare("SELECT COALESCE(SUM(commits_count),0) c, COALESCE(SUM(active_seconds),0) s FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')");
    $monthStmt->execute([$projectId]);
    $month = $monthStmt->fetch();

    // Last 7 days breakdown
    $dailyStmt = $pdo->prepare("SELECT log_date, employee, commits_count, active_seconds FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY log_date DESC");
    $dailyStmt->execute([$projectId]);
    $daily = $dailyStmt->fetchAll();

    // Commit log daily work summary
    $commitLogStmt = $pdo->prepare("SELECT employee, commit_message, files_changed, committed_at FROM project_commit_log WHERE project_id = ? AND committed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) ORDER BY committed_at ASC");
    $commitLogStmt->execute([$projectId]);
    $dailyWorkSummary = [];
    foreach ($commitLogStmt->fetchAll() as $row) {
        $day = date('Y-m-d', strtotime($row['committed_at']));
        $key = $day . '|' . $row['employee'];
        $dailyWorkSummary[$key] ??= ['date' => $day, 'employee' => $row['employee'], 'commitMessages' => [], 'areas' => []];
        if ($row['commit_message']) $dailyWorkSummary[$key]['commitMessages'][] = $row['commit_message'];
        foreach (json_decode($row['files_changed'] ?? '[]', true) ?: [] as $file) {
            $label = guessFeatureLabel($file);
            if (!in_array($label, $dailyWorkSummary[$key]['areas'], true)) $dailyWorkSummary[$key]['areas'][] = $label;
        }
    }

    // Merge active (uncommitted) files
    $activeLogStmt = $pdo->prepare("SELECT employee, log_date, active_files FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY log_date ASC");
    $activeLogStmt->execute([$projectId]);
    foreach ($activeLogStmt->fetchAll() as $row) {
        $day = $row['log_date'];
        $key = $day . '|' . $row['employee'];
        $dailyWorkSummary[$key] ??= ['date' => $day, 'employee' => $row['employee'], 'commitMessages' => [], 'areas' => []];
        foreach (json_decode($row['active_files'] ?? '[]', true) ?: [] as $file) {
            $label = guessFeatureLabel($file);
            if (!in_array($label, $dailyWorkSummary[$key]['areas'], true)) $dailyWorkSummary[$key]['areas'][] = $label;
        }
    }

    $dailyWorkSummary = array_reverse(array_values($dailyWorkSummary));

    // Construct HTML for Dompdf
    $html = '<!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <title>Weekly Report — ' . htmlspecialchars($project['name']) . '</title>
    <style>
      body { font-family: Arial, Helvetica, sans-serif; color: #1e293b; line-height: 1.5; font-size: 13px; }
      h1 { font-size: 20px; margin-bottom: 2px; color: #0f172a; }
      .sub { color: #64748b; font-size: 11px; margin-bottom: 20px; }
      .summary { margin-bottom: 20px; width: 100%; }
      .card { border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; text-align: center; background: #ffffff; }
      .card-half { border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; text-align: center; background: #ffffff; }
      .label { font-size: 9px; text-transform: uppercase; color: #94a3b8; margin-bottom: 2px; }
      .value { font-size: 15px; font-weight: 700; color: #1e293b; }
      h3 { font-size: 14px; border-bottom: 2px solid #f1f5f9; padding-bottom: 4px; margin-top: 25px; color: #334155; }
      table { width: 100%; border-collapse: collapse; margin-top: 10px; }
      th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid #e2e8f0; }
      th { color: #64748b; font-weight: 600; font-size: 10px; text-transform: uppercase; background: #f8fafc; }
      .badge { display: inline-block; background: #eef2ff; color: #4338ca; border-radius: 10px; padding: 1px 6px; font-size: 10px; margin-right: 4px; }
      ul { margin: 2px 0 0; padding-left: 15px; color: #64748b; font-size: 11px; }
    </style>
    </head>
    <body>
      <h1>' . htmlspecialchars($project['name']) . '</h1>
      <div class="sub">PM Connect Weekly Report — Generated ' . date('d M Y, H:i') . '</div>
    
      <table style="width: 100%; border: none; margin-bottom: 20px;">
        <tr>
          <td style="border: none; width: 25%; padding: 0 5px 0 0;">
            <div class="card"><div class="label">Started</div><div class="value">' . fmtDate($project['started_at']) . '</div></div>
          </td>
          <td style="border: none; width: 25%; padding: 0 5px;">
            <div class="card"><div class="label">Ended</div><div class="value">' . ($project['completed_at'] ? fmtDate($project['completed_at']) : 'In progress') . '</div></div>
          </td>
          <td style="border: none; width: 25%; padding: 0 5px;">
            <div class="card"><div class="label">Days Taken</div><div class="value">' . ($daysTaken ?? '—') . '</div></div>
          </td>
          <td style="border: none; width: 25%; padding: 0 0 0 5px;">
            <div class="card"><div class="label">Status</div><div class="value">' . ($project['completed_at'] ? 'Completed' : 'Active') . '</div></div>
          </td>
        </tr>
      </table>

      <table style="width: 100%; border: none; margin-bottom: 20px;">
        <tr>
          <td style="border: none; width: 50%; padding: 0 5px 0 0;">
            <div class="card-half"><div class="label">This Week</div><div class="value">' . (int)$week['c'] . ' commits, ' . fmtMin($week['s']) . '</div></div>
          </td>
          <td style="border: none; width: 50%; padding: 0 0 0 5px;">
            <div class="card-half"><div class="label">This Month</div><div class="value">' . (int)$month['c'] . ' commits, ' . fmtMin($month['s']) . '</div></div>
          </td>
        </tr>
      </table>
    
      <h3>Weekly Work Summary (by Developer)</h3>';
      if (!$dailyWorkSummary) {
          $html .= '<div style="color:#94a3b8; font-size:12px; margin-top: 10px;">No commits pushed in the last 7 days.</div>';
      } else {
          foreach ($dailyWorkSummary as $entry) {
              $html .= '<div style="border-bottom:1px solid #f1f5f9; padding:6px 0;">
                <div style="font-weight:600; font-size:12px; color: #334155;">' . fmtDate($entry['date']) . ' — ' . htmlspecialchars($entry['employee']) . '</div>';
                if ($entry['areas']) {
                    $html .= '<div style="margin:2px 0;">';
                    foreach ($entry['areas'] as $area) {
                        $html .= '<span class="badge">' . htmlspecialchars($area) . '</span>';
                    }
                    $html .= '</div>';
                }
                if (!empty($entry['files'])) {
                    $html .= '<div style="font-size: 10px; color: #64748b; margin: 2px 0;"><strong>Files:</strong> ' . implode(', ', array_map('htmlspecialchars', $entry['files'])) . '</div>';
                }
                if ($entry['commitMessages']) {
                    $html .= '<ul>';
                    foreach ($entry['commitMessages'] as $msg) {
                        $html .= '<li>' . htmlspecialchars($msg) . '</li>';
                    }
                    $html .= '</ul>';
                }
              $html .= '</div>';
          }
      }
    
      $html .= '<h3>Daily Breakdown (Last 7 Days)</h3>
      <table>
        <thead><tr><th>Date</th><th>Developer</th><th>Commits</th><th>Active Time</th></tr></thead>
        <tbody>';
        if (!$daily) {
            $html .= '<tr><td colspan="4" style="color:#94a3b8; text-align: center;">No activity recorded.</td></tr>';
        } else {
            foreach ($daily as $d) {
                $html .= '<tr>
                  <td>' . fmtDate($d['log_date']) . '</td>
                  <td>' . htmlspecialchars($d['employee']) . '</td>
                  <td>' . (int)$d['commits_count'] . '</td>
                  <td>' . fmtMin($d['active_seconds']) . '</td>
                </tr>';
            }
        }
        $html .= '</tbody>
      </table>
    </body>
    </html>';

    // Set Dompdf options and render
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);
    
    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    
    $output = $dompdf->output();
    
    $pdfFilename = 'weekly_report_' . $projectId . '_' . date('Ymd') . '.pdf';
    $pdfPath = $reportsDir . '/' . $pdfFilename;
    file_put_contents($pdfPath, $output);
    
    cronLog("PDF report saved to: " . $pdfPath);

    // Email to Admin
    $mail = new PHPMailer(true);
    try {
        // Since SMTP might not be configured locally, we default to PHP mail()
        // but PHPMailer can be configured with SMTP if parameters exist.
        $mail->isMail();
        $mail->setFrom('no-reply@projex.local', 'PM Connect Reports');
        $mail->addAddress($adminEmail);
        
        $mail->Subject = 'Weekly Progress Report - ' . $project['name'];
        $mail->isHTML(true);
        $mail->Body = '<p>Hello Admin,</p>'
                    . '<p>Please find attached the weekly progress report for the project <strong>' . htmlspecialchars($project['name']) . '</strong>.</p>'
                    . '<p>Report generated on ' . date('d M Y, H:i') . '.</p>'
                    . '<br><p>Best regards,<br>PM Connect Automation</p>';
        
        $mail->addAttachment($pdfPath);
        
        $mail->send();
        cronLog("Email sent successfully to: " . $adminEmail);
    } catch (Exception $e) {
        cronLog("Email delivery failed: " . $mail->ErrorInfo);
    }
}

cronLog("Weekly cron report completed successfully.");
?>
