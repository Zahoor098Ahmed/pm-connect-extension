<?php
// Printable PM Connect tracking report for one project — admin-only.
// Print → Save as PDF from the browser; no PHP PDF library dependency.
require_once __DIR__ . '/api/config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$pdo = getDB();
$projectId = intval($_GET['project'] ?? 0);
if (!$projectId) {
    http_response_code(400);
    echo 'Missing ?project=';
    exit;
}

$projStmt = $pdo->prepare("SELECT id, name, started_at, completed_at FROM projects WHERE id = ?");
$projStmt->execute([$projectId]);
$project = $projStmt->fetch();
if (!$project) {
    http_response_code(404);
    echo 'Project not found';
    exit;
}

$daysTaken = $project['started_at']
    ? (new DateTime($project['completed_at'] ?? 'now'))->diff(new DateTime($project['started_at']))->days
    : null;

$weekStmt = $pdo->prepare("SELECT COALESCE(SUM(commits_count),0) c, COALESCE(SUM(active_seconds),0) s FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)");
$weekStmt->execute([$projectId]);
$week = $weekStmt->fetch();

$monthStmt = $pdo->prepare("SELECT COALESCE(SUM(commits_count),0) c, COALESCE(SUM(active_seconds),0) s FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')");
$monthStmt->execute([$projectId]);
$month = $monthStmt->fetch();

$dailyStmt = $pdo->prepare("SELECT log_date, employee, commits_count, active_seconds FROM project_daily_log WHERE project_id = ? AND log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) ORDER BY log_date DESC");
$dailyStmt->execute([$projectId]);
$daily = $dailyStmt->fetchAll();

function fmtDate($v) { return $v ? date('d M Y', strtotime($v)) : '—'; }
function fmtMin($seconds) { return intdiv((int) $seconds, 60) . ' min'; }

function guessFeatureLabel(string $path): string {
    $base = basename($path);
    $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    $name = trim(preg_replace('/[-_]+/', ' ', preg_replace('/\.[a-zA-Z0-9]+$/', '', $base)));
    if ($name === '') return $base;
    $lower = strtolower($name);
    if (in_array($lower, ['index', 'home', 'main'], true)) return 'Home Page';
    $label = implode(' ', array_map('ucfirst', explode(' ', $lower)));
    if (in_array($ext, ['php', 'html', 'htm']) && stripos($label, 'page') === false) $label .= ' Page';
    return $label;
}

// "Aug 1 — Zahoor: worked on Home Page, About Page" — auto-derived from
// real commit messages + real changed files across every developer on this
// project, so the whole-project PDF shows what actually got built, day by day.
$commitLogStmt = $pdo->prepare("SELECT employee, commit_message, files_changed, committed_at FROM project_commit_log WHERE project_id = ? ORDER BY committed_at ASC");
$commitLogStmt->execute([$projectId]);
$dailyWorkSummary = [];
foreach ($commitLogStmt->fetchAll() as $row) {
    $day = date('Y-m-d', strtotime($row['committed_at']));
    $key = $day . '|' . $row['employee'];
    $dailyWorkSummary[$key] ??= ['date' => $day, 'employee' => $row['employee'], 'commitMessages' => [], 'areas' => []];
    if ($row['commit_message']) $dailyWorkSummary[$key]['commitMessages'][] = $row['commit_message'];
    foreach (json_decode($row['files_changed'] ?? '[]', true) ?: [] as $file) {
        $label = guessFeatureLabel($file);
        if (!in_array($label, $dailyWorkSummary[$key]['areas'], true)) $dailyWorkSummary[$key]['areas'][] = $label;
    }
}

// Merge active (uncommitted) files
$activeLogStmt = $pdo->prepare("SELECT employee, log_date, active_files FROM project_daily_log WHERE project_id = ? ORDER BY log_date ASC");
$activeLogStmt->execute([$projectId]);
foreach ($activeLogStmt->fetchAll() as $row) {
    $day = $row['log_date'];
    $key = $day . '|' . $row['employee'];
    $dailyWorkSummary[$key] ??= ['date' => $day, 'employee' => $row['employee'], 'commitMessages' => [], 'areas' => []];
    foreach (json_decode($row['active_files'] ?? '[]', true) ?: [] as $file) {
        $label = guessFeatureLabel($file);
        if (!in_array($label, $dailyWorkSummary[$key]['areas'], true)) $dailyWorkSummary[$key]['areas'][] = $label;
    }
}

$dailyWorkSummary = array_reverse(array_values($dailyWorkSummary));
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Report — <?= htmlspecialchars($project['name']) ?></title>
<style>
  body { font-family: Arial, Helvetica, sans-serif; color: #1e293b; max-width: 800px; margin: 40px auto; padding: 0 20px; }
  h1 { font-size: 22px; margin-bottom: 4px; }
  .sub { color: #64748b; font-size: 13px; margin-bottom: 24px; }
  .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 28px; }
  .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; }
  .card .label { font-size: 11px; text-transform: uppercase; color: #94a3b8; margin-bottom: 4px; }
  .card .value { font-size: 18px; font-weight: 700; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid #e2e8f0; }
  th { color: #64748b; font-weight: 600; font-size: 11px; text-transform: uppercase; }
  .print-btn { margin-bottom: 20px; }
  @media print {
    .print-btn { display: none; }
    body { margin: 0; }
  }
</style>
</head>
<body>
  <button class="print-btn" onclick="window.print()">🖨 Print / Save as PDF</button>

  <h1><?= htmlspecialchars($project['name']) ?></h1>
  <div class="sub">PM Connect automatic tracking report — generated <?= date('d M Y, H:i') ?></div>

  <div class="summary">
    <div class="card"><div class="label">Started</div><div class="value"><?= fmtDate($project['started_at']) ?></div></div>
    <div class="card"><div class="label">Ended</div><div class="value"><?= $project['completed_at'] ? fmtDate($project['completed_at']) : 'In progress' ?></div></div>
    <div class="card"><div class="label">Days Taken</div><div class="value"><?= $daysTaken ?? '—' ?></div></div>
    <div class="card"><div class="label">Status</div><div class="value"><?= $project['completed_at'] ? 'Completed' : 'Active' ?></div></div>
  </div>

  <div class="summary" style="grid-template-columns: repeat(2, 1fr);">
    <div class="card"><div class="label">This Week</div><div class="value"><?= (int) $week['c'] ?> commits, <?= fmtMin($week['s']) ?></div></div>
    <div class="card"><div class="label">This Month</div><div class="value"><?= (int) $month['c'] ?> commits, <?= fmtMin($month['s']) ?></div></div>
  </div>

  <h3>Daily Work Summary <span style="font-weight:400; color:#94a3b8; font-size:12px;">(auto-detected from commits)</span></h3>
  <div style="margin-bottom:24px;">
    <?php if (!$dailyWorkSummary): ?>
      <div style="color:#94a3b8; font-size:13px;">No commits pushed via PM Connect yet.</div>
    <?php endif; ?>
    <?php foreach ($dailyWorkSummary as $entry): ?>
      <div style="border-bottom:1px solid #e2e8f0; padding:8px 0;">
        <div style="font-weight:600; font-size:13px;"><?= fmtDate($entry['date']) ?> — <?= htmlspecialchars($entry['employee']) ?></div>
        <?php if ($entry['areas']): ?>
          <div style="margin:4px 0;">
            <?php foreach ($entry['areas'] as $area): ?>
              <span style="display:inline-block; background:#eef2ff; color:#4338ca; border-radius:12px; padding:2px 8px; font-size:11px; margin:2px 4px 2px 0;"><?= htmlspecialchars($area) ?></span>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php if ($entry['commitMessages']): ?>
          <ul style="margin:4px 0 0; padding-left:18px; color:#64748b; font-size:12px;">
            <?php foreach ($entry['commitMessages'] as $msg): ?>
              <li><?= htmlspecialchars($msg) ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <h3>Last 30 Days</h3>
  <table>
    <thead><tr><th>Date</th><th>Developer</th><th>Commits</th><th>Active Time</th></tr></thead>
    <tbody>
      <?php if (!$daily): ?>
        <tr><td colspan="4" style="color:#94a3b8;">No activity recorded yet.</td></tr>
      <?php endif; ?>
      <?php foreach ($daily as $d): ?>
        <tr>
          <td><?= fmtDate($d['log_date']) ?></td>
          <td><?= htmlspecialchars($d['employee']) ?></td>
          <td><?= (int) $d['commits_count'] ?></td>
          <td><?= fmtMin($d['active_seconds']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
