<?php
// Final Summary — built once, when a project is marked complete.
// Different from the daily/weekly/monthly rollups (which stay internal-only):
// this is a single consolidated "what got done" overview, GitHub-comment
// style, and it goes out to the client as well as the admin.

require_once dirname(__DIR__) . '/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function finalSummaryLog(string $msg): void {
    $logDir = dirname(__DIR__) . '/uploads/logs';
    if (!is_dir($logDir)) mkdir($logDir, 0777, true);
    file_put_contents($logDir . '/final_summary.log', "[" . date('Y-m-d H:i:s') . "] " . $msg . "\n", FILE_APPEND);
}

function finalSummaryFeatureLabel(string $path): string {
    $base = basename($path);
    $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    $name = trim(preg_replace('/[-_]+/', ' ', preg_replace('/\.[a-zA-Z0-9]+$/', '', $base)));
    if ($name === '') return $base;
    $lower = strtolower($name);
    if (in_array($lower, ['index', 'home', 'main'], true)) return 'Home Page';
    $label = implode(' ', array_map('ucfirst', explode(' ', $lower)));
    if (in_array($ext, ['php', 'html', 'htm']) && stripos($label, 'page') === false) $label .= ' Page';
    return $label;
}

/**
 * Aggregates a completed project's full history, builds an internal (full
 * detail) and client-facing (polished, no raw tracking numbers) summary,
 * renders a PDF, stores everything in project_final_summary, and emails the
 * admin and — if project.client_email is set — the client too.
 *
 * Safe to call more than once (e.g. if "complete" is toggled): each call
 * inserts a fresh row rather than mutating history.
 */
function buildAndSendFinalSummary(PDO $pdo, int $projectId): void {
    $projectStmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $projectStmt->execute([$projectId]);
    $project = $projectStmt->fetch();
    if (!$project) {
        finalSummaryLog("Project $projectId not found — skipping final summary.");
        return;
    }

    // Totals across the project's whole life, not just a recent window.
    $totalsStmt = $pdo->prepare("SELECT COALESCE(SUM(commits_count),0) c, COALESCE(SUM(active_seconds),0) s FROM project_daily_log WHERE project_id = ?");
    $totalsStmt->execute([$projectId]);
    $totals = $totalsStmt->fetch();

    $devStmt = $pdo->prepare("SELECT employee, SUM(commits_count) c, SUM(active_seconds) s FROM project_daily_log WHERE project_id = ? GROUP BY employee ORDER BY c DESC");
    $devStmt->execute([$projectId]);
    $byDeveloper = $devStmt->fetchAll();

    $commitStmt = $pdo->prepare("SELECT employee, commit_message, files_changed, committed_at FROM project_commit_log WHERE project_id = ? ORDER BY committed_at ASC");
    $commitStmt->execute([$projectId]);
    $commits = $commitStmt->fetchAll();

    $areas = [];
    $commitMessages = [];
    foreach ($commits as $row) {
        if ($row['commit_message']) $commitMessages[] = $row['commit_message'];
        foreach (json_decode($row['files_changed'] ?? '[]', true) ?: [] as $file) {
            $label = finalSummaryFeatureLabel($file);
            if (!in_array($label, $areas, true)) $areas[] = $label;
        }
    }

    $startedAt = $project['started_at'];
    $completedAt = $project['completed_at'] ?? date('Y-m-d H:i:s');
    $daysTaken = $startedAt ? (new DateTime($completedAt))->diff(new DateTime($startedAt))->days : null;

    $fmtMin = fn($seconds) => intdiv((int) $seconds, 60) . ' min';
    $fmtDate = fn($v) => $v ? date('d M Y', strtotime($v)) : '—';

    // Internal summary: full raw detail, admin-only.
    $internalSummary = "Project: {$project['name']}\n"
        . "Started: " . $fmtDate($startedAt) . " | Completed: " . $fmtDate($completedAt) . " | Days taken: " . ($daysTaken ?? '—') . "\n"
        . "Total commits: {$totals['c']} | Total active time: " . $fmtMin($totals['s']) . "\n"
        . "By developer:\n";
    foreach ($byDeveloper as $d) {
        $internalSummary .= "  - {$d['employee']}: {$d['c']} commits, " . $fmtMin($d['s']) . "\n";
    }

    // Client-facing summary: polished, high-level only — no raw active-seconds
    // or per-developer machine-level tracking data.
    $clientSummary = "Project \"{$project['name']}\" was completed on " . $fmtDate($completedAt) . "."
        . ($daysTaken !== null ? " Total time from start to completion: {$daysTaken} day(s)." : "")
        . ($areas ? " Work covered: " . implode(', ', array_slice($areas, 0, 12)) . "." : "");

    // --- PDF (client-facing content; this is what actually gets emailed) ---
    $reportsDir = dirname(__DIR__) . '/uploads/reports';
    if (!is_dir($reportsDir)) mkdir($reportsDir, 0777, true);

    $html = '<!DOCTYPE html><html><head><meta charset="utf-8">
    <title>Final Summary — ' . htmlspecialchars($project['name']) . '</title>
    <style>
      body { font-family: Arial, Helvetica, sans-serif; color: #1e293b; line-height: 1.5; font-size: 13px; }
      h1 { font-size: 20px; margin-bottom: 2px; color: #0f172a; }
      .sub { color: #64748b; font-size: 11px; margin-bottom: 20px; }
      .card { border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; text-align: center; background: #fff; }
      .label { font-size: 9px; text-transform: uppercase; color: #94a3b8; margin-bottom: 2px; }
      .value { font-size: 15px; font-weight: 700; color: #1e293b; }
      .badge { display: inline-block; background: #eef2ff; color: #4338ca; border-radius: 10px; padding: 2px 8px; font-size: 11px; margin: 2px; }
      h3 { font-size: 14px; border-bottom: 2px solid #f1f5f9; padding-bottom: 4px; margin-top: 25px; color: #334155; }
    </style></head><body>
      <h1>' . htmlspecialchars($project['name']) . ' — Final Summary</h1>
      <div class="sub">Generated ' . date('d M Y, H:i') . '</div>
      <table style="width:100%; border:none; margin-bottom:20px;"><tr>
        <td style="border:none; width:33%;"><div class="card"><div class="label">Started</div><div class="value">' . $fmtDate($startedAt) . '</div></div></td>
        <td style="border:none; width:33%;"><div class="card"><div class="label">Completed</div><div class="value">' . $fmtDate($completedAt) . '</div></div></td>
        <td style="border:none; width:33%;"><div class="card"><div class="label">Days Taken</div><div class="value">' . ($daysTaken ?? '—') . '</div></div></td>
      </tr></table>
      <h3>Summary</h3>
      <p>' . nl2br(htmlspecialchars($clientSummary)) . '</p>';
    if ($areas) {
        $html .= '<h3>Areas Covered</h3><div>';
        foreach ($areas as $area) $html .= '<span class="badge">' . htmlspecialchars($area) . '</span>';
        $html .= '</div>';
    }
    $html .= '</body></html>';

    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);
    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    $pdfFilename = 'final_summary_' . $projectId . '_' . date('Ymd_His') . '.pdf';
    $pdfPath = $reportsDir . '/' . $pdfFilename;
    file_put_contents($pdfPath, $dompdf->output());

    $pdo->prepare("
        INSERT INTO project_final_summary
          (project_id, started_at, completed_at, total_commits, total_active_seconds, internal_summary, client_summary, pdf_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ")->execute([$projectId, $startedAt, $completedAt, (int) $totals['c'], (int) $totals['s'], $internalSummary, $clientSummary, $pdfPath]);

    // --- Email: admin always, client only if project.client_email is set ---
    $adminEmail = 'admin@example.com';
    try {
        $row = $pdo->query("SELECT email FROM admins LIMIT 1")->fetchColumn();
        if ($row) $adminEmail = $row;
    } catch (Exception $e) {
        finalSummaryLog("Failed to fetch admin email: " . $e->getMessage());
    }

    $recipients = [$adminEmail => 'Admin'];
    if (!empty($project['client_email'])) {
        $recipients[$project['client_email']] = 'Client';
    }

    foreach ($recipients as $email => $label) {
        $mail = new PHPMailer(true);
        try {
            $mail->isMail();
            $mail->setFrom('no-reply@projex.local', 'PM Connect');
            $mail->addAddress($email);
            $mail->Subject = 'Project Completed — ' . $project['name'];
            $mail->isHTML(true);
            $mail->Body = '<p>Hello,</p>'
                . '<p>The project <strong>' . htmlspecialchars($project['name']) . '</strong> has been marked complete.</p>'
                . '<p>' . nl2br(htmlspecialchars($clientSummary)) . '</p>'
                . '<p>Please find the full final summary attached as a PDF.</p>'
                . '<br><p>Best regards,<br>PM Connect Automation</p>';
            $mail->addAttachment($pdfPath);
            $mail->send();
            finalSummaryLog("Final summary emailed to $label ($email) for project $projectId.");
        } catch (Exception $e) {
            finalSummaryLog("Email to $label ($email) failed: " . $mail->ErrorInfo);
        }
    }
}
