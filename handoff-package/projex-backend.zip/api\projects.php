<?php
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

/* ── GET — list all projects with file counts ── */
if ($method === 'GET') {
    $stmt = $db->query("
        SELECT
            p.id,
            p.name,
            p.type,
            p.status,
            p.phase,
            p.share_token,
            p.case_study,
            p.closure_notes,
            p.payment_type,
            p.project_origin,
            p.country,
            p.client_email,
            p.description,
            DATE_FORMAT(p.created_at, '%d %b %Y') AS created_at,
            COUNT(f.id) AS file_count,
            p.created_by
        FROM projects p
        LEFT JOIN project_files f ON f.project_id = p.id
        GROUP BY p.id
        ORDER BY p.created_at DESC
    ");
    jsonResponse(['projects' => $stmt->fetchAll()]);
}

/* ── POST — update description ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'update_desc') {
    $id   = intval($_POST['id'] ?? 0);
    $desc = trim($_POST['description'] ?? '');
    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);
    $stmt = $db->prepare("UPDATE projects SET description = :desc WHERE id = :id");
    $stmt->execute([':desc' => $desc, ':id' => $id]);
    jsonResponse(['success' => true]);
}

/* ── POST — full edit (name, type, status, payment/origin/country, description) ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'update') {
    $id             = intval($_POST['id'] ?? 0);
    $name           = trim($_POST['name']           ?? '');
    $type           = trim($_POST['type']           ?? '');
    $status         = trim($_POST['status']         ?? 'active');
    $payment_type   = trim($_POST['payment_type']   ?? 'paid');
    $project_origin = trim($_POST['project_origin'] ?? 'client');
    $country        = trim($_POST['country']        ?? '');
    $client_email   = trim($_POST['client_email']   ?? '');
    $description    = trim($_POST['description']    ?? '');

    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);
    if (!$name) jsonResponse(['success' => false, 'error' => 'Project name is required'], 422);
    if (!$type) jsonResponse(['success' => false, 'error' => 'Project type is required'], 422);
    if ($client_email && !filter_var($client_email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['success' => false, 'error' => 'Client email is not a valid email address'], 422);
    }

    $allowed_statuses = ['active', 'on-hold', 'draft'];
    if (!in_array($status, $allowed_statuses)) $status = 'active';

    $stmt = $db->prepare("
        UPDATE projects
        SET name = :name, type = :type, status = :status, payment_type = :payment_type,
            project_origin = :project_origin, country = :country, client_email = :client_email,
            description = :description
        WHERE id = :id
    ");
    $stmt->execute([
        ':name'           => $name,
        ':type'           => $type,
        ':status'         => $status,
        ':payment_type'   => $payment_type,
        ':project_origin' => $project_origin,
        ':country'        => $country,
        ':client_email'   => $client_email ?: null,
        ':description'    => $description,
        ':id'             => $id,
    ]);

    jsonResponse(['success' => true]);
}

/* ── POST — advance/set project lifecycle phase ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'setPhase') {
    $id    = intval($_POST['id'] ?? 0);
    $phase = $_POST['phase'] ?? '';
    $allowed_phases = ['initiation', 'planning', 'execution', 'review', 'closure', 'post_sale'];
    if (!$id || !in_array($phase, $allowed_phases, true)) {
        jsonResponse(['success' => false, 'error' => 'Valid id and phase required'], 400);
    }
    $db->prepare("UPDATE projects SET phase = ? WHERE id = ?")->execute([$phase, $id]);
    jsonResponse(['success' => true]);
}

/* ── POST — issue (or return existing) a read-only Client Portal link ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'getShareLink') {
    $id = intval($_POST['id'] ?? 0);
    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);

    $stmt = $db->prepare("SELECT share_token FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $token = $stmt->fetchColumn();

    if (!$token) {
        $token = bin2hex(random_bytes(16));
        $db->prepare("UPDATE projects SET share_token = ? WHERE id = ?")->execute([$token, $id]);
    }

    jsonResponse(['success' => true, 'token' => $token]);
}

/* ── POST — save closure notes (Project Closure sub-page) ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'setClosureNotes') {
    $id    = intval($_POST['id'] ?? 0);
    $notes = trim($_POST['closure_notes'] ?? '');
    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);
    $db->prepare("UPDATE projects SET closure_notes = ? WHERE id = ?")->execute([$notes ?: null, $id]);
    jsonResponse(['success' => true]);
}

/**
 * Case Study "Generator": fills a template from the project's *real* data
 * (name, client, phase, duration, real commit/task counts) — not an AI
 * writer. The admin can then edit the generated draft before saving it.
 */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'generateCaseStudy') {
    $id = intval($_POST['id'] ?? 0);
    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);

    $stmt = $db->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $p = $stmt->fetch();
    if (!$p) jsonResponse(['success' => false, 'error' => 'Project not found'], 404);

    $commitStmt = $db->prepare("SELECT COALESCE(SUM(commits_count),0) FROM project_daily_log WHERE project_id = ?");
    $commitStmt->execute([$id]);
    $commits = (int) $commitStmt->fetchColumn();

    $taskStmt = $db->prepare("SELECT COUNT(*), SUM(status='done') FROM tasks WHERE project_id = ? AND parent_task_id IS NULL");
    $taskStmt->execute([$id]);
    [$totalTasks, $doneTasks] = $taskStmt->fetch(PDO::FETCH_NUM);

    $days = $p['started_at'] ? (int) ((strtotime($p['completed_at'] ?: 'now') - strtotime($p['started_at'])) / 86400) : null;

    $draft = "{$p['name']}\n\n"
        . ($p['description'] ? $p['description'] . "\n\n" : '')
        . "Delivered {$doneTasks} of {$totalTasks} tracked tasks"
        . ($days !== null ? " over {$days} days" : '')
        . ($commits > 0 ? ", with {$commits} commits tracked via PM Connect." : '.')
        . "\n\nProject type: {$p['type']}. Status: {$p['status']}.";

    jsonResponse(['success' => true, 'draft' => $draft]);
}

/* ── POST — save the (possibly edited) case study draft ── */
if ($method === 'POST' && ($_POST['action'] ?? '') === 'setCaseStudy') {
    $id = intval($_POST['id'] ?? 0);
    $text = trim($_POST['case_study'] ?? '');
    if (!$id) jsonResponse(['success' => false, 'error' => 'Project ID required'], 400);
    $db->prepare("UPDATE projects SET case_study = ? WHERE id = ?")->execute([$text ?: null, $id]);
    jsonResponse(['success' => true]);
}

/* ── POST — create project + upload files ── */
if ($method === 'POST') {
    $name           = trim($_POST['name']           ?? '');
    $type           = trim($_POST['type']           ?? '');
    $status         = trim($_POST['status']         ?? 'active');
    $payment_type   = trim($_POST['payment_type']   ?? 'paid');
    $project_origin = trim($_POST['project_origin'] ?? 'client');
    $country        = trim($_POST['country']        ?? '');
    $client_email   = trim($_POST['client_email']   ?? '');
    $description    = trim($_POST['description']    ?? '');
    $created_by     = $_SESSION['name'] ?? $_SESSION['email'] ?? 'Admin';

    if (!$name) jsonResponse(['success' => false, 'error' => 'Project name is required'], 422);
    if (!$type) jsonResponse(['success' => false, 'error' => 'Project type is required'], 422);
    if ($client_email && !filter_var($client_email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['success' => false, 'error' => 'Client email is not a valid email address'], 422);
    }

    $allowed_statuses = ['active', 'on-hold', 'draft'];
    if (!in_array($status, $allowed_statuses)) $status = 'active';

    $stmt = $db->prepare("
        INSERT INTO projects (name, type, status, payment_type, project_origin, country, client_email, description, created_by)
        VALUES (:name, :type, :status, :payment_type, :project_origin, :country, :client_email, :description, :created_by)
    ");
    $stmt->execute([
        ':name'           => $name,
        ':type'           => $type,
        ':status'         => $status,
        ':payment_type'   => $payment_type,
        ':project_origin' => $project_origin,
        ':country'        => $country,
        ':client_email'   => $client_email ?: null,
        ':description'    => $description,
        ':created_by'     => $created_by,
    ]);
    $projectId = $db->lastInsertId();

    /* The file uploads are now handled separately via api/files.php */

    jsonResponse(['success' => true, 'id' => $projectId]);
}

/* ── DELETE — remove a project and its files ── */
if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);
    if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid ID'], 400);

    /* Delete stored files from disk */
    $stmt = $db->prepare("SELECT stored_name FROM project_files WHERE project_id = :id");
    $stmt->execute([':id' => $id]);
    foreach ($stmt->fetchAll() as $row) {
        $path = __DIR__ . '/../uploads/' . $row['stored_name'];
        if (file_exists($path)) unlink($path);
    }

    $db->prepare("DELETE FROM project_files WHERE project_id = :id")->execute([':id' => $id]);
    // tasks has no FK to projects (only to itself for subtasks), so delete
    // its tasks explicitly — task_comments/task_attachments cascade from tasks.
    $db->prepare("DELETE FROM tasks WHERE project_id = :id")->execute([':id' => $id]);
    $db->prepare("DELETE FROM projects WHERE id = :id")->execute([':id' => $id]);

    jsonResponse(['success' => true]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
