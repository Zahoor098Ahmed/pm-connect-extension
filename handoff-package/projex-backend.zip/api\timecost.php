<?php
require_once __DIR__ . '/config.php';

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Real time data from two existing sources: VS Code active-coding
    // seconds (project_daily_log, written by the extension) and manual
    // task time logs (task_time_logs). No estimates, no fabricated cost —
    // cost only appears once a project has an hourly rate set via billing.
    $tracked = $pdo->query("
        SELECT p.id AS project_id, p.name AS project_name,
               COALESCE(SUM(l.active_seconds), 0) AS active_seconds,
               COALESCE(SUM(l.commits_count), 0) AS commits
        FROM projects p
        LEFT JOIN project_daily_log l ON l.project_id = p.id
        GROUP BY p.id
        HAVING active_seconds > 0 OR commits > 0
        ORDER BY active_seconds DESC
    ")->fetchAll();

    $manual = $pdo->query("
        SELECT tl.employee, t.title AS task_title, p.name AS project_name,
               SUM(tl.minutes) AS minutes
        FROM task_time_logs tl
        JOIN tasks t ON t.id = tl.task_id
        JOIN projects p ON p.id = t.project_id
        GROUP BY tl.employee, tl.task_id
        ORDER BY minutes DESC
        LIMIT 20
    ")->fetchAll();

    if (($_GET['action'] ?? '') === 'approvals') {
        $rows = $pdo->query("
            SELECT tl.id, tl.employee, tl.minutes, tl.note, tl.approved,
                   DATE_FORMAT(tl.logged_at, '%d %b %Y') AS logged_at,
                   t.title AS task_title, p.name AS project_name
            FROM task_time_logs tl
            JOIN tasks t ON t.id = tl.task_id
            JOIN projects p ON p.id = t.project_id
            ORDER BY tl.approved ASC, tl.logged_at DESC
        ")->fetchAll();
        jsonResponse(['success' => true, 'logs' => $rows]);
    }

    if (($_GET['action'] ?? '') === 'orgCost') {
        // Organisation-wide totals — real hours only, no fabricated $ cost
        // unless a project has real invoiced amounts to compare against.
        $totalActiveSeconds = (int) $pdo->query("SELECT COALESCE(SUM(active_seconds),0) FROM project_daily_log")->fetchColumn();
        $totalManualMinutes = (int) $pdo->query("SELECT COALESCE(SUM(minutes),0) FROM task_time_logs")->fetchColumn();
        $totalInvoiced      = (float) $pdo->query("SELECT COALESCE(SUM(amount),0) FROM invoices")->fetchColumn();
        jsonResponse(['success' => true, 'totalActiveSeconds' => $totalActiveSeconds, 'totalManualMinutes' => $totalManualMinutes, 'totalInvoiced' => $totalInvoiced]);
    }

    jsonResponse(['success' => true, 'tracked' => $tracked, 'manual' => $manual]);
}

if ($method === 'POST' && ($_POST['action'] ?? '') === 'approve') {
    $id = intval($_POST['id'] ?? 0);
    if (!$id) jsonResponse(['success' => false, 'error' => 'id required'], 400);
    $pdo->prepare("UPDATE task_time_logs SET approved = 1 WHERE id = ?")->execute([$id]);
    jsonResponse(['success' => true]);
}

jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
