-- Run once against projex_db. Adds automatic project start/end/daily-tracking
-- support for PM Connect's zero-interaction reporting.

-- 1. activity_log previously existed only live in the DB (no migration file
--    tracked it) — add it here now, matching pmconnect.php's logActivity().
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `employee` VARCHAR(255) NOT NULL,
  `action` VARCHAR(50) NOT NULL,
  `task_id` INT NULL,
  `task_title` VARCHAR(255) NULL,
  `detail` VARCHAR(500) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Project lifecycle timestamps.
ALTER TABLE `projects`
  ADD COLUMN `started_at` TIMESTAMP NULL DEFAULT NULL AFTER `created_at`,
  ADD COLUMN `completed_at` TIMESTAMP NULL DEFAULT NULL AFTER `started_at`;
-- started_at: set idempotently the first time the extension activates for
--   this project's projectId (see api/pmconnect.php action=projectstart).
-- completed_at: set only via the admin "Mark Project Complete" button.
-- total days taken = DATEDIFF(COALESCE(completed_at, NOW()), started_at).

-- 3. Daily rollup of commits + active coding seconds, one row per
--    (project_id, employee, log_date), upserted incrementally by every heartbeat.
CREATE TABLE IF NOT EXISTS `project_daily_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT UNSIGNED NOT NULL,
  `employee` VARCHAR(255) NOT NULL,
  `log_date` DATE NOT NULL,
  `commits_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `active_seconds` INT UNSIGNED NOT NULL DEFAULT 0,
  `first_activity_at` TIMESTAMP NULL DEFAULT NULL,
  `last_activity_at` TIMESTAMP NULL DEFAULT NULL,
  `last_commit_sha` VARCHAR(40) NULL,
  `last_commit_message` VARCHAR(255) NULL,
  UNIQUE KEY `uniq_project_employee_date` (`project_id`, `employee`, `log_date`),
  CONSTRAINT `fk_daily_log_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Dedup table for commit SHAs already counted — prevents the interval
--    fallback poll and the vscode.git event handler from double-counting
--    the same commit if both fire for it.
CREATE TABLE IF NOT EXISTS `project_commit_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT UNSIGNED NOT NULL,
  `employee` VARCHAR(255) NOT NULL,
  `commit_sha` VARCHAR(40) NOT NULL,
  `commit_message` VARCHAR(255) NULL,
  `files_changed` TEXT NULL,
  `committed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_project_sha` (`project_id`, `commit_sha`),
  CONSTRAINT `fk_commit_log_project` FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- files_changed: JSON array of file paths touched by this commit (from
-- `git show --name-only`), e.g. ["src/home.php","css/home.css"]. Combined
-- with commit_message, this is what auto-generates the daily work summary
-- ("Aug 1: worked on Home Page — home.php, home.css") without the developer
-- typing anything beyond their normal commit message.
